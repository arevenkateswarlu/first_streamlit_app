import logging
import datetime
import os


class LogGenerate:
    """Class definition for creating the logger object with required configuration"""
    def logger(self, logModule):
        today_date = str(datetime.date.today())
        log_path = "/home/ybloadusr/PYTHON_VENV/python_scripts/"
        if not os.path.exists(log_path):
            os.mkdir(log_path)
        log_file_name = log_path + "Automation-" + today_date + ".log"
        log_level = "DEBUG"
        logger = logging.getLogger(logModule)
        logger.setLevel(log_level)
        lF = logging.FileHandler(log_file_name)
        formatter = logging.Formatter(
            '%(asctime)s - %(module)s - %(funcName)s - %(thread)s - %(lineno)s - %(levelname)s - %(message)s')
        lF.setFormatter(formatter)
        lF.setLevel(log_level)
        logger.addHandler(lF)
        return logger
        # logger.debug('debug message')
        # logger.info('info message')
        # logger.warning('warn message')
        # logger.error('error message')
        # logger.critical('critical message')
