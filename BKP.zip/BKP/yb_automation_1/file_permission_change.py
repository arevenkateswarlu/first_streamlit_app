import os
import pandas as pd


def check_files_in_csv(input_path, csv_file):
    # Check if the input path is a file or a directory
    if os.path.isfile(input_path):
        files_to_check = [input_path]
    elif os.path.isdir(input_path):
        files_to_check = [os.path.join(input_path, file) for file in os.listdir(input_path)]
    else:
        print("Invalid input path.")
        return
     # Read the CSV file using pandas
    try:
        df = pd.read_csv(csv_file,sep="|",skipinitialspace = True)
    except FileNotFoundError:
        print(f"{csv_file} CSV file not found.")
        return

     # Extract the column name from the CSV that contains the file or directory names
    column_name = "filename"

     # Check if each file or directory exists in the CSV
    for file_or_dir in files_to_check:
        if os.path.exists(file_or_dir):
            # Check if the file or directory name exists in the specified column of the CSV
            if file_or_dir in df[column_name].values:
                print(f"{file_or_dir} exists in the CSV with permission {df.loc[df[column_name] == file_or_dir]['permission'].to_string(header=False,index=False)}.")
                #print(df.loc[df[column_name] == file_or_dir])
                change_directory_permissions(df.loc[df[column_name] == file_or_dir])
            else:
                print(f"{file_or_dir} does not exist in the CSV.")
        else:
            print(f"{file_or_dir} does not exist.")


def change_directory_permissions(file_permission_details):
    file_df = file_permission_details
    print(file_df)
    permissions = int(file_df['permission'].to_string(header=False,index=False),8)
    file_name = file_df['filename'].to_string(header=False,index=False).strip()
    username = file_df['username'].to_string(header=False,index=False)
    group = file_df['group'].to_string(header=False,index=False)
    print(file_name)
    print(permissions)
    try:
        os.chmod(file_name, permissions)
        #os.chown(file_name,username,group)
        print(f"Successfully changed permissions for {file_name}")
#    except FileNotFoundError:
#        print(f"File not found: {file_name}")
    except PermissionError:
        print(f"Permission denied for {file_name}")
    except Exception as e:
        print(f"Error occurred for {file_name}: {e}")


if __name__ == "__main__":
    input_path = input("Enter the file or directory path to check: ")
    csv_file = "/home/ybloadusr/PYTHON_VENV/python_scripts/file_permissions.csv"
    print(input_path)
    check_files_in_csv(input_path, csv_file)
