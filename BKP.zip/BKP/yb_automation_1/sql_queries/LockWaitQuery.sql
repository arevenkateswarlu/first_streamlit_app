with lock_sessions as (
select session_id,blocked_by_session_id,database_id,table_id from sys.lock where blocked_by_session_id is not null
)
, locked_query as (
select q.state_time,locked.session_id,locked.blocked_by_session_id,q.query_id,q.state,q.username,d.name as database,t.name as table_name,q.query_text as query_text from lock_sessions locked,sys.query q,sys.database d,sys.table t where locked.session_id=q.session_id and locked.database_id=d.database_id and locked.table_id=t.table_id
)
,locked_by_query as ( select q.state_time,l.session_id,l.blocked_by_session_id,q.query_id,q.state,q.username,q.query_text as query_text from lock_sessions l ,sys.query q where l.blocked_by_session_id=q.session_id
) 
select 
locked_query.state_time,
--datediff(minutes,current_timestamp,locked_query.state_time) as lock_wait_minutes,
current_timestamp-locked_query.state_time as lock_wait_minutes,
locked_query.session_id as locked_session,
locked_query.query_id as locked_query,
locked_query.state as locked_session_state,
locked_query.username as locked_session_user,
locked_query.database as Database,
locked_query.table_name as table_name,
locked_by_query.blocked_by_session_id as locked_by_session,
locked_by_query.query_id as locked_by_query,
locked_by_query.state locked_by_query_state,
locked_by_query.username as locked_by_user
--,REGEXP_REPLACE(REGEXP_REPLACE(locked_query.query_text,'\r',''),'\n','') as locked_query_text,
--REGEXP_REPLACE(REGEXP_REPLACE(locked_by_query.query_text,'\r',''),'\n','') as locked_by_query_text
 from locked_query locked_query,locked_by_query locked_by_query 
 where 
 locked_query.session_id=locked_by_query.session_id and 
 locked_query.blocked_by_session_id=locked_by_query.blocked_by_session_id and 
 locked_query.username not in ('yellowbrick','sys_ybd_analyze','sys_ybd_gc') and 
 ( locked_query.state_time!=locked_by_query.state_time and  locked_query.username!=locked_by_query.username )
 filter_condition 
 order by lock_wait_minutes desc
 ;
