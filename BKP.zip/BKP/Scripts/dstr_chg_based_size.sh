if [ $# -ne 3 ]
  then
    echo "Please check the usage description of the script and run again"
    echo "$0 <Tables_list_file_which_are_lessthan_1GB> <Input_ddl_file> <NZ_DB_NAME>"
    exit
fi
tab_list_file=$1
ddl_file=$2
nzdbname=$3
if [ ! -f ${tab_list_file} ] || [ ! -f ${ddl_file} ]
then
echo "any one of input file provided file not existed, so exiting the script"
exit 1
fi


cat ${tab_list_file}|grep -iw ${nzdbname}|while read DBNAME TABLE SIZE
do
export START_PATTERN="CREATE TABLE ${TABLE}"
export END_PATTERN="DISTRIBUTE "
export LINE_NUMBER=`cat -n ${ddl_file}|awk "/\<${START_PATTERN}\>/,/${END_PATTERN}/"|grep -iw distribute|grep -iv grep|awk '{print $1}'`
if [ "${LINE_NUMBER}X" == "X"  ] || [ ! -n "${LINE_NUMBER}" ]
then
echo "${DBNAME} ${TABLE} ${SIZE} not found"
else
export LINE_CONTENT_OLD=`sed -n ${LINE_NUMBER}p ${ddl_file}`
export LINE_CONTENT_NEW="DISTRIBUTE REPLICATE "
#echo "${TABLE} ${LINE_NUMBER} ${LINE_CONTENT_OLD} ${LINE_CONTENT_NEW}"
sed  "${LINE_NUMBER}s/${LINE_CONTENT_OLD}/${LINE_CONTENT_NEW}/" ${ddl_file} > temp.ddl
cat temp.ddl > ${ddl_file}
fi
done
rm -rf temp.ddl
