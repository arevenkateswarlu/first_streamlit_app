export YBHOST=10.159.196.17
export YBPORT=5432
export YBUSER=venkatesh
export YBPASSWORD=MkxbD9Fb

#------------------------------------------------------------------------------
# Validating the number of input variables
#
if [ ! $# -eq 3 ]
  then
    echo "Please check the usage description of the script and run again"
    echo "$0 <dbname> <tab_name> <bkp_path>"
    exit
else
dbname=$1
tabname=$2
bkp_path=$3
db_count=`ybsql -d yellowbrick -tqc  "select count(*) from sys.database where upper(name)='${dbname}' or lower(name)='${dbname}'"`
if [ ${db_count} -ne 1 ]
then
echo "Provided database ${dbname} is not existed."
exit 1
fi
if [ ! -d ${bkp_path} ]
then
echo "Provided backup path is not existed."
exit 1
fi
tab_count=`ybsql -d ${dbname} -tqc "select count(*) from sys.table t,sys.database d where (upper(t.name)='${tabname}' or lower(t.name)='${tabname}') and (upper(d.name)='${dbname}' or lower(d.name)='${dbname}') and t.database_id=d.database_id "`
if [ ${tab_count} -ne 1 ]
then
echo "Table ${tabname} is not existed,so existing the script"
exit 1
fi
fi
ybsql -d znawuserdb -c "update znawuserdb.dbaall.ybload_status_${dbname} set state='STARTED',start_time=(select current_timestamp) where dbname=lower('${dbname}') and tablename=lower('${tabname}')"
tab_files=
ybload -d ${dbname} --username venkatesh -t dbaall.${tabname} --trim-white -q --nullmarker '^%0' --max-bad-rows 10 --read-sources-concurrently ALWAYS --num-readers 30 --format text ${bkp_path}/${dbname}/${tabname^^}.* --delimiter '|' --bad-row-file ${bkp_path}/${dbname}/LOAD_LOG/${tabname}.bad --logfile ${bkp_path}/${dbname}/LOAD_LOG/${tabname}.log
if [ $? -eq 0 ]
then
start_time=`ybsql -d znawuserdb -tqc "select start_time from znawuserdb.dbaall.ybload_status_${dbname} where dbname=lower('${dbname}') and tablename=lower('${tabname}') "`
tab_load_count=`ybsql -d znawuserdb -tqc "select count(*) from sys.log_load where database_name=lower('${dbname}') and table_name=lower('${tabname}') and start_time >=
'${start_time}'   group by start_time  order by start_time desc limit 1"`
if [ "${tab_load_count}X" == "X" ] || [ ${tab_load_count} -eq 0 ]
then
src_file_row_count=`cat ${bkp_path}/${dbname}/LOAD_LOG/${tabname}.log|grep -i 'All source files are empty'|wc -l`
if [ ${src_file_row_count} -eq 1 ]
then
ybsql -d znawuserdb -c "update znawuserdb.dbaall.ybload_status_${dbname} set state='DONE',end_time=(select current_timestamp),parsed_rows=0,inserted_rows=0,error_rows=0 where dbname=lower('${dbname}') and tablename=lower('${tabname}')"
exit
fi
ybsql -d znawuserdb -c "update znawuserdb.dbaall.ybload_status_${dbname} set state='FAILED',end_time=(select current_timestamp) where dbname=lower('${dbname}') and tablename=lower('${tabname}')"
exit
fi
start_time=`ybsql -d znawuserdb -tqc "select start_time from znawuserdb.dbaall.ybload_status_${dbname} where dbname=lower('${dbname}') and tablename=lower('${tabname}') "`
state=`ybsql -d znawuserdb -tqc "select state from sys.log_load where database_name='${dbname}' and table_name='${tabname}' and start_time >='${start_time}' order by start_time desc limit 1"`
parsed_rows=`ybsql -d znawuserdb -tqc "select parsed_rows from sys.log_load where database_name='${dbname}' and table_name='${tabname}' and start_time >='${start_time}' order by start_time desc limit 1"`
inserted_rows=`ybsql -d znawuserdb -tqc "select inserted_rows from sys.log_load where database_name='${dbname}' and table_name='${tabname}' and start_time >='${start_time}' order by start_time desc limit 1"`
error_rows=`ybsql -d znawuserdb -tqc "select error_rows from sys.log_load where database_name='${dbname}' and table_name='${tabname}' and start_time >='${start_time}' order by start_time desc limit 1"`
ybsql -d znawuserdb -c "update znawuserdb.dbaall.ybload_status_${dbname} set (state,end_time,parsed_rows,inserted_rows,error_rows)=('${state}',(select current_timestamp),${parsed_rows},${inserted_rows},${error_rows}) where dbname=lower('${dbname}') and tablename=lower('${tabname}')"
#ybsql -d znawuserdb -c "update znawuserdb.dbaall.ybload_status_${dbname} set (state,start_time,end_time,parsed_rows,inserted_rows,error_rows)=(select state,start_time,end_time,parsed_rows,inserted_rows,error_rows from sys.log_load where database_name='${dbname}' and table_name='${tabname}' order by start_time desc limit 1) where dbname='${dbname}' and tablename='${tabname}' "

else
start_time=`ybsql -d znawuserdb -tqc "select start_time from znawuserdb.dbaall.ybload_status_${dbname} where dbname=lower('${dbname}') and tablename=lower('${tabname}') "`
tab_load_count=`ybsql -d znawuserdb -tqc "select count(*) from sys.log_load where database_name=lower('${dbname}') and table_name=lower('${tabname}') and start_time >= '${start_time}'   group by start_time  order by start_time desc limit 1"`
if [ "${tab_load_count}X" == "X" ] || [ ${tab_load_count} -eq 0 ]
then
src_file_row_count=`cat ${bkp_path}/${dbname}/LOAD_LOG/${tabname}.log|grep -i 'All source files are empty'|wc -l`
if [ ${src_file_row_count} -eq 1 ]
then
ybsql -d znawuserdb -c "update znawuserdb.dbaall.ybload_status_${dbname} set state='DONE',end_time=(select current_timestamp),parsed_rows=0,inserted_rows=0,error_rows=0 where dbname=lower('${dbname}') and tablename=lower('${tabname}')"
exit
fi
ybsql -d znawuserdb -c "update znawuserdb.dbaall.ybload_status_${dbname} set state='FAILED',end_time=(select current_timestamp) where dbname=lower('${dbname}') and tablename=lower('${tabname}')"
exit 
fi
state=`ybsql -d znawuserdb -tqc "select state from sys.log_load where database_name='${dbname}' and table_name='${tabname}' and start_time >='${start_time}' order by start_time desc limit 1"`
parsed_rows=`ybsql -d znawuserdb -tqc "select parsed_rows from sys.log_load where database_name='${dbname}' and table_name='${tabname}' and start_time >='${start_time}' order by start_time desc limit 1"`
inserted_rows=`ybsql -d znawuserdb -tqc "select inserted_rows from sys.log_load where database_name='${dbname}' and table_name='${tabname}' and start_time >='${start_time}' order by start_time desc limit 1"`
error_rows=`ybsql -d znawuserdb -tqc "select error_rows from sys.log_load where database_name='${dbname}' and table_name='${tabname}' and start_time >='${start_time}' order by start_time desc limit 1"`
ybsql -d znawuserdb -c "update znawuserdb.dbaall.ybload_status_${dbname} set (state,end_time,parsed_rows,inserted_rows,error_rows)=('${state}',(select current_timestamp),${parsed_rows},${inserted_rows},${error_rows}) where dbname=lower('${dbname}') and tablename=lower('${tabname}')"
##(select 'ERROR' as state,start_time,end_time,parsed_rows,inserted_rows,error_rows from sys.log_load where database_name='${dbname}' and table_name='${tabname}' order by start_time desc limit 1) where dbname='${dbname}' and tablename='${tabname}' "
fi
