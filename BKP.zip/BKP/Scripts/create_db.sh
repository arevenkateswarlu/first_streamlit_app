
cat db_list|while read dbname
do
echo "create database ${dbname,,}_mako10 encoding utf8 ;"
echo "\\c ${dbname,,}_mako10 "
echo "create schema dbaall;"
done

