export YBHOST=10.159.196.17
export YBPORT=5432
export YBUSER=venkatesh
export YBPASSWORD=MkxbD9Fb

#------------------------------------------------------------------------------
# Validating the number of input variables
#
if [ ! $# -eq 3 ]
  then
    echo "Please check the usage description of the script and run again"
    echo "$0 <dbname> <bkp_path> <tab_list_file>"
    exit
else
dbname=$1
bkp_path=$2
tab_list=" "
if [ $# -eq 3 ]
then
tab_list_file=$3
if [ ! -f ${tab_list_file} ]
then
echo "Provided table list file ${tab_list_file} not existed, so exiting the script"
exit 1
fi
tab_list_temp=`cat ${tab_list_file}|sed ':a;N;$!ba;s/\n/,/g'|sed "s/,/\',\'/g"`
tab_list=" and TABLENAME in ('${tab_list_temp}')"
fi
db_count=`ybsql -d yellowbrick -tqc  "select count(*) from sys.database where upper(name)='${dbname}' or lower(name)='${dbname}' "`
if [ ${db_count} -ne 1 ]
then
echo "Provided database ${dbname} is not existed."
exit 1
fi
if [ ! -d ${bkp_path} ]
then
echo "Provided backup path is not existed."
exit 1
fi
mkdir -p ${bkp_path}/${dbname}/LOAD_LOG
if [ $? -ne 0 ]
then
echo "Unable to create the load directory,so exiting the script"
exit 1
fi
fi

ybsql -d znawuserdb -c "create table znawuserdb.dbaall.ybload_status_${dbname} (dbname varchar(30),tablename varchar(120),start_time timestamp,end_time timestamp,state varchar(30),parsed_rows bigint,inserted_rows bigint,error_rows bigint) " 
if [ $? -ne 0 ]
then
echo "Load status table creation is failed,so exiting the script."
exit 1
fi

for tabname in `cat ${tab_list_file}`
do
back_end_script_count=`ps -ef|grep -iw yb_data_load_child.sh|grep -iw ${dbname}|grep -iv grep|wc -l`
while [ ${back_end_script_count} -ge 5 ]
do
sleep 5
back_end_script_count=`ps -ef|grep -iw yb_data_load_child.sh|grep -iw ${dbname}|grep -iv grep|wc -l`
done
ybsql -d znawuserdb -c "insert into znawuserdb.dbaall.ybload_status_${dbname}(dbname,tablename) values('${dbname}','${tabname}')"
sh `pwd`/yb_data_load_child.sh ${dbname} ${tabname} ${bkp_path} &
done
