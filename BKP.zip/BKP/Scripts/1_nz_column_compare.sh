
src_dbname=$1

## ddl for column compare table
## create table znawuserdb.dbaall.nz_to_yb_column_compare(src_dbname varchar(50),src_table varchar(128),src_column_name varchar(128),src_datatype varchar(100),src_nullable char(10),trt_dbname varchar(50),trt_table varchar(128),trt_column_name varchar(128),trt_datatype varchar(100),trt_nullable char(10)) ;

##nzsql -d znawuserdb -tqc "delete from znawuserdb.dbaall.nz_to_yb_column_compare where src_dbname=upper('${src_dbname}') "
##nzsql -d znawuserdb -c "insert into znawuserdb.dbaall.nz_to_yb_column_compare(select TABLE_CATALOG,TABLE_NAME,COLUMN_NAME,DATA_TYPE,IS_NULLABLE from ${src_dbname}.INFORMATION_SCHEMA.columns where TABLE_SCHEMA in ('DBAALL','ADMIN') )"
nzsql -d ${src_dbname} -A -tqc "select c.TABLE_CATALOG,c.TABLE_NAME,c.COLUMN_NAME,c.DATA_TYPE,c.IS_NULLABLE from ${src_dbname}.INFORMATION_SCHEMA.columns c,${src_dbname}.INFORMATION_SCHEMA._v_table t where c.TABLE_SCHEMA in ('DBAALL','ADMIN') and c.TABLE_CATALOG=upper('${src_dbname}') and c.TABLE_NAME=t.TABLENAME and c.TABLE_CATALOG=t.DATABASE and t.OBJTYPE in ('TABLE')" -o /bkp_nfs_mount/bkp_test/ddl_compare/yb_ddl_columns/nz_${src_dbname,,}.txt
