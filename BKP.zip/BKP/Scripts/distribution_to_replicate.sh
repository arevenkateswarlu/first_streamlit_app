if [ $# -ne 1 ]
then
echo "$0 <tab_list>"
exit
fi
tab_list=$1
i=0
cat ${tab_list}|while read dbname schema tabname
do
i=`ps -ef|grep -i distribution_to_replicate_child.sh|grep -iv grep|wc -l`
while [ ${i} -ge 10 ]
do
sleep 5
i=`ps -ef|grep -i distribution_to_replicate_child.sh|grep -iv grep|wc -l`
done
sh distribution_to_replicate_child.sh ${dbname} ${schema} ${tabname} &
done
