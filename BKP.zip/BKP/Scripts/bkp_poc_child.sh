#!/bin/ksh
#------------------------------------------------------------------------------
# Initialyzing the Netezza environment
#
#. ${HOME}/.bashrc
# For NPS
export NZ_USER=admin        # Default NZ username
export NZ_PASSWORD=password # Default NZ password
export NZ_DATABASE=system   # Default NZ database
PATH=/nz/kit/bin:/nz/kit/bin/adm:/nz/kit/sbin:/sbin:/usr/sbin:/bin:/usr/bin:/export/home/nz/bin:/usr/local/bin
export PATH

#------------------------------------------------------------------------------
# Validating the number of input variables
#
if [ ! $# -eq 3 ]
  then
    echo "Please check the usage description of the script and run again"
    echo "$0 <dbname> <tab_name> <bkp_path>"
    exit
else
dbname=$1
tabname=$2
bkp_path=$3
db_count=`nzsql -tqc  "select count(*) from _v_database where upper(database)='${dbname}' or lower(database)='${dbname}' "`
if [ ${db_count} -ne 1 ]
then
echo "Provided database ${dbname} is not existed."
exit 1
fi
if [ ! -d ${bkp_path} ]
then
echo "Provided backup path is not existed."
exit 1
fi
tab_count=`nzsql -d ${dbname} -tqc "select count(*) from _v_table where (upper(tablename)='${tabname}' or lower(tablename)='${tabname}') and (upper(DATABASE)='${dbname}' or lower(DATABASE)='${dbname}')"`
if [ ${tab_count} -ne 1 ]
then
echo "Table ${tabname} is not existed,so existing the script"
exit 1
fi
fi
nzsql -d table_backups -c "update table_backups.dbaall.bkp_status_${dbname} set start_time=(select current_timestamp),status='IN_PROGRESS' where (upper(tablename)='${tabname}' or lower(tablename)='${tabname}') and (upper(dbname)='${dbname}' or lower(dbname)='${dbname}')"
/nz/support/bin/nz_backup -db ${dbname} -dir ${bkp_path}/${dbname}  -format GZIP -t ${tabname} -threads 8 > ${bkp_path}/${dbname}/LOG/${tabname}.log
if [ $? -eq 0 ]
then
row_count=""
row_count=`cat ${bkp_path}/${dbname}/LOG/${tabname}.log|grep -i 'Total # of records unloaded'|awk '{print $6}'|sed  's/,//g'`
if [ "${row_count}X" == "X" ]
then
row_count=-1
fi
nzsql -d table_backups -c "update table_backups.dbaall.bkp_status_${dbname} set status='SUCCESS',end_time=(select current_timestamp),row_count=${row_count} where (upper(tablename)='${tabname}' or lower(tablename)='${tabname}') and (upper(dbname)='${dbname}' or lower(dbname)='${dbname}')"

else
nzsql -d table_backups -c "update table_backups.dbaall.bkp_status_${dbname} set status='FAILED',end_time=(select current_timestamp) where (upper(tablename)='${tabname}' or lower(tablename)='${tabname}') and (upper(dbname)='${dbname}' or lower(dbname)='${dbname}')"

fi



