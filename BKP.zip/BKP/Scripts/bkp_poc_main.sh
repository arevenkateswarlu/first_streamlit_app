#!/bin/ksh
#------------------------------------------------------------------------------
# Initialyzing the Netezza environment
#
#. ${HOME}/.bashrc
# For NPS
export NZ_USER=admin        # Default NZ username
export NZ_PASSWORD=password # Default NZ password
export NZ_DATABASE=system   # Default NZ database
PATH=/nz/kit/bin:/nz/kit/bin/adm:/nz/kit/sbin:/sbin:/usr/sbin:/bin:/usr/bin:/export/home/nz/bin:/usr/local/bin
export PATH

#------------------------------------------------------------------------------
# Validating the number of input variables
#
if [ $# -lt 2 ] || [ $# -gt 3 ]
  then
    echo "Please check the usage description of the script and run again"
    echo "$0 <dbname> <bkp_path> <tab_list_file>"
    exit
else
dbname=$1
bkp_path=$2
tab_list=" "
if [ $# -eq 3 ]
then
tab_list_file=$3
if [ ! -f ${tab_list_file} ]
then
echo "Provided table list file ${tab_list_file} not existed, so exiting the script"
exit 1 
fi
tab_list_temp=`cat ${tab_list_file}|sed ':a;N;$!ba;s/\n/,/g'|sed "s/,/\',\'/g"`
tab_list=" and TABLENAME in ('${tab_list_temp}')"
fi
db_count=`nzsql -tqc  "select count(*) from _v_database where upper(database)='${dbname}' or lower(database)='${dbname}' "`
if [ ${db_count} -ne 1 ]
then
echo "Provided database ${dbname} is not existed."
exit 1
fi
if [ ! -d ${bkp_path} ]
then
echo "Provided backup path is not existed."
exit 1
fi
mkdir -p ${bkp_path}/${dbname}/LOG
fi
nzsql -d table_backups -c "create table table_backups.dbaall.bkp_status_${dbname}(dbname varchar(40),tablename varchar(120),size_gb numeric(9,3),status varchar(20),start_time timestamp,end_time timestamp,row_count bigint) "
if [ $? -ne 0 ]
then
echo "Backup status table creation is failed,so exiting the script."
exit 1
fi
echo "create table dbaall.bkp_status_${dbname} as (select '${dbname}' as dbname,TABLENAME,round(USED_BYTES/(1024.0*1024.0*1024.0)) as size_gb,'YET_TO_START' as status from _v_table_storage_stat where schema not in ('DEFINITION_SCHEMA') ${tab_list} order by TABLENAME asc )"
nzsql -d ${dbname} -c "create table dbaall.bkp_status_${dbname} as (select '${dbname}' as dbname,TABLENAME,round(USED_BYTES/(1024.0*1024.0*1024.0)) as size_gb,'YET_TO_START' as status from _v_table_storage_stat where schema not in ('DEFINITION_SCHEMA') ${tab_list} order by TABLENAME asc )"
nzsql -d table_backups -c "insert into table_backups.dbaall.bkp_status_${dbname} (select * from ${dbname}.dbaall.bkp_status_${dbname} ) "
nzsql -d ${dbname} -c "drop table ${dbname}.dbaall.bkp_status_${dbname} "
##nzsql -d table_backups -c "insert into table_backups.dbaall.bkp_status_${dbname}  (select '${dbname}',TABLENAME,round(USED_BYTES/(1024.0*1024.0)) as USED_MB from _v_table_storage_stat where schema not in ('DEFINITION_SCHEMA') order by TABLENAME asc )"
for tabname in `nzsql -d table_backups -tqc "select tablename from table_backups.dbaall.bkp_status_${dbname} where STATUS='YET_TO_START' or STATUS='FAILED' order by tablename asc"`
do
back_end_script_count=`ps -ef|grep -iw bkp_poc_child.sh|grep -iv grep|wc -l`
while [ ${back_end_script_count} -ge 10 ]
do
sleep 5
back_end_script_count=`ps -ef|grep -iw bkp_poc_child.sh|grep -iv grep|wc -l`
done
sh `pwd`/bkp_poc_child.sh ${dbname} ${tabname} ${bkp_path} &
done
