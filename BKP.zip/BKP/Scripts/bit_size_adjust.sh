if [ $# -ne 3 ] 
  then
    echo "Please check the usage description of the script and run again"
    echo "$0 <bit_size_list_file> <Input_ddl_file> <NZ_DB_NAME>"
    exit
fi
bit_file=$1
ddl_file=$2
nzdbname=$3
if [ ! -f ${bit_file} ] || [ ! -f ${ddl_file} ]
then
echo "any one of input file provided file not existed, so exiting the script"
exit 1
fi

cat ${bit_file}|grep -iw ${nzdbname}|while read DBNAME TABLE COL_NAME COL_SIZE BYTE_SIZE
do
export START_PATTERN="CREATE TABLE ${TABLE^^}"
export END_PATTERN="DISTRIBUTE "
export LINE_NUMBER=`cat -n ${ddl_file}|awk "/\<${START_PATTERN}\>/,/${END_PATTERN}/"|grep -iw "${COL_NAME^^}"|grep -iwv distribute|grep -iv grep|awk '{print $1}'`
if [ "${LINE_NUMBER}X" != "X" ]
then
export LINE_CONTENT_OLD=`echo ${COL_SIZE}`
export LINE_CONTENT_NEW=`echo ${BYTE_SIZE}`
##echo "${TABLE} ${COL_NAME} ${LINE_CONTENT_OLD} ${LINE_CONTENT_NEW} ${LINE_NUMBER}"
sed  "${LINE_NUMBER}s/${LINE_CONTENT_OLD}/${LINE_CONTENT_NEW}/" ${ddl_file} > temp.ddl
cat temp.ddl > ${ddl_file}
else
echo "${TABLE} ${COL_NAME} ${LINE_CONTENT_OLD} ${LINE_CONTENT_NEW} ${LINE_NUMBER} not existed"
fi
done
rm -rf temp.ddl
sed -i "1s/^/set schema 'dbaall' ;\n/" ${ddl_file}
