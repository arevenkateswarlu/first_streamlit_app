if [ $# -ne 3 ]
  then
    echo "Please check the usage description of the script and run again"
    echo "$0 <bit_size_list_file> <Input_ddl_file> <NZ DB_NAME>"
    exit
fi
tab_list_file=$1
ddl_file=$2
nzdbname=$3
if [ ! -f ${tab_list_file} ] || [ ! -f ${ddl_file} ]
then
echo "any one of input file provided file not existed, so exiting the script"
exit 1
fi


cat ${tab_list_file}|grep -iw ${nzdbname}|while read DBNAME TABLE COLUMN
do
export START_PATTERN="CREATE TABLE ${TABLE}"
export END_PATTERN="DISTRIBUTE "
##echo "${TABLE} ${COLUMN}"
export LINE_NUMBER=`cat -n ${ddl_file}|awk "/\<${START_PATTERN}\>/,/${END_PATTERN}/"|grep -iw "${COLUMN}"|grep -iwv distribute|grep -iv grep|awk '{print $1}'`
if [ "${LINE_NUMBER}X" == "X"  ] || [ ! -n "${LINE_NUMBER}" ]
then
echo "${DBNAME} ${TABLE} ${COLUMN} not found"
else
export LINE_CONTENT_OLD=`sed -n ${LINE_NUMBER}p ${ddl_file}`
export LINE_CONTENT_NEW=`echo ${LINE_CONTENT_OLD}|sed 's/INTEGER/BIGINT/'`
sed  "${LINE_NUMBER}s/${LINE_CONTENT_OLD}/${LINE_CONTENT_NEW}/" ${ddl_file} > temp.ddl
cat temp.ddl > ${ddl_file}
fi
done

rm -rf temp.ddl
