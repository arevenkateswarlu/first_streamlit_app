num_arg=$#
if [ ${num_arg} -ne 3 ]
then
echo "Usage $0 <dbname> <schema> <tabname>"
exit 1
else
dbname=$1
schema=$2
tabname=$3
fi
tab_count=`ybsql -d ${dbname} -tqAc "select count(table_name) from information_schema.tables where table_catalog='${dbname}' and table_schema='${schema}' and table_name='${tabname}'"`
if [ ${tab_count} -eq 0 ]
then
echo "${dbname}.${schema}.${tabname} table is not existed, failed"
exit
elif [ ${tab_count} -ne 1 ]
then
echo "${dbname}.${schema}.${tabname} table has multiple entries, failed"
exit
fi
ybsql -d ${dbname} -tqc "describe ${schema}.${tabname} only ddl " > ddl_bkp/${dbname}.${schema}.${tabname}.ddl
ybsql -d ${dbname} -tqc "describe ${schema}.${tabname} only ddl " > ${dbname}.${schema}.${tabname}.ddl
if [ $? -ne 0 ]
then
echo "${dbname}.${schema}.${tabname} DDL extraction is failed"
exit
fi
ybsql -d ${dbname} -tqc "alter table ${schema}.${tabname} rename to ${tabname}_09072021_not_rep "
if [ $? -ne 0 ]
then
echo "${dbname}.${schema}.${tabname} table rename is failed"
exit
fi
export LINE_NUMBER=`cat -n ${dbname}.${schema}.${tabname}.ddl|grep -iw 'distribute'|grep -iv grep|awk '{print $1}'`
if [ "${LINE_NUMBER}X" == "X"  ] || [ ! -n "${LINE_NUMBER}" ]
then
echo "${dbname}.${schema}.${tabname} table distribution key change failed"
else
export LINE_CONTENT_OLD=`sed -n ${LINE_NUMBER}p ${dbname}.${schema}.${tabname}.ddl`
export LINE_CONTENT_NEW="DISTRIBUTE REPLICATE "
#echo "${TABLE} ${LINE_NUMBER} ${LINE_CONTENT_OLD} ${LINE_CONTENT_NEW}"
sed  "${LINE_NUMBER}s/${LINE_CONTENT_OLD}/${LINE_CONTENT_NEW}/" ${dbname}.${schema}.${tabname}.ddl > ${dbname}.${schema}.${tabname}_1.ddl
fi
export tab_constraint=`ybsql -d ${dbname} -tqc "select constraint_name from information_schema.table_constraints where table_name='${tabname}_09072021_not_rep' and table_schema='${schema}' and table_catalog='${dbname}' and constraint_type='PRIMARY KEY'"`
if [ "${tab_constraint}" != "X" ]
then
ybsql -d ${dbname} -tqc "alter table ${schema}.${tabname}_09072021_not_rep drop constraint if exists ${tab_constraint} restrict"
if [ $? -ne 0 ]
then
echo "${dbname}.${schema}.${tabname} drop constraint failed"
exit
fi

fi
ybsql -d ${dbname} -f ${dbname}.${schema}.${tabname}_1.ddl -o ${dbname}.${schema}.${tabname}_1.ddl.out
if [ $? -ne 0 ]
then
echo "${dbname}.${schema}.${tabname} table distribution key change failed"
else
ybsql -d ${dbname} -tqc "insert into ${dbname}.${schema}.${tabname}(select * from ${dbname}.${schema}.${tabname}_09072021_not_rep)"
if [ $? -ne 0 ]
then
echo "${dbname}.${schema}.${tabname} table data copy is failed while changing distribution key"
else
echo "${dbname}.${schema}.${tabname} table distribution key change completed successfully"
rm ${dbname}.${schema}.${tabname}_1.ddl ${dbname}.${schema}.${tabname}.ddl ${dbname}.${schema}.${tabname}_1.ddl.out
fi
fi
