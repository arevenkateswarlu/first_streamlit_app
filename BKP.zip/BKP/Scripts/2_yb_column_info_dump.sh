export YBHOST=10.159.196.17
export YBPORT=5432
export YBUSER=venkatesh
export YBPASSWORD=MkxbD9Fb

src_dbname=$1
tgt_dbname=$2

## create table znawuserdb.dbaall.nz_to_yb_column_compare(src_dbname varchar(50),src_table varchar(128),src_column_name varchar(128),src_datatype varchar(100),src_nullable char(10),trt_dbname varchar(50),trt_table varchar(128),trt_column_name varchar(128),trt_datatype varchar(100),trt_nullable char(10)) ;
##create table znawuserdb.dbaall.nz_src_columns(src_dbname varchar(50),src_table varchar(128),src_column_name varchar(128),src_datatype varchar(100),src_nullable char(10));
##create table znawuserdb.dbaall.yb_trt_columns(trt_dbname varchar(50),trt_table varchar(128),trt_column_name varchar(128),trt_datatype varchar(100),trt_nullable char(10));

ybsql -d ${tgt_dbname,,} -A -tqc "select d.name as dbname,t.name as table_name,c.name as column_name,c.type as data_type,case c.nullable  when 't' then 'YES' when 'f' then 'NO' else 'UNKNOWN' end as nullable from sys.column c,sys.table t,sys.database d where c.table_id=t.table_id and t.database_id=d.database_id and d.name='${tgt_dbname,,}' " -o /bkp_nfs_mount/bkp_test/ddl_compare/yb_ddl_columns/${tgt_dbname,,}.txt

##sed -e '/^$/d' /bkp_nfs_mount/bkp_test/ddl_compare/yb_ddl_columns/${dbname,,}.txt 
ybsql -d znawuserdb -tqc "delete from znawuserdb.dbaall.nz_src_columns "
ybsql -d znawuserdb -tqc "delete from znawuserdb.dbaall.yb_trt_columns "
ybsql -d znawuserdb -tqc "delete from znawuserdb.dbaall.nz_to_yb_column_compare where lower(src_dbname)=lower('${src_dbname}')"
ybsql -d znawuserdb -tqc "\copy nz_src_columns from '/bkp_nfs_mount/bkp_test/ddl_compare/yb_ddl_columns/nz_${src_dbname,,}.txt' with (format text,delimiter '|',header 'false')"
ybsql -d znawuserdb -tqc "\copy yb_trt_columns from '/bkp_nfs_mount/bkp_test/ddl_compare/yb_ddl_columns/${tgt_dbname,,}.txt' with (format text,delimiter '|',header 'false')"
ybsql -d znawuserdb -tqc "insert into znawuserdb.dbaall.nz_to_yb_column_compare(select * from znawuserdb.dbaall.nz_src_columns)"
ybsql -d znawuserdb -tqc "update nz_to_yb_column_compare t set trt_dbname=upper(s.trt_dbname),trt_table=upper(s.trt_table),trt_column_name=upper(s.trt_column_name),trt_datatype=upper(s.trt_datatype),trt_nullable=upper(s.trt_nullable) from yb_trt_columns s where t.src_table=upper(s.trt_table) and t.src_column_name=upper(s.trt_column_name)"
