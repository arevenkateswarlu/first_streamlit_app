#!/bin/bash
#------------------------------------------------------------------------------
# Initialyzing the Netezza environment
#
#. ${HOME}/.bashrc
# For NPS
export NZ_USER=admin        # Default NZ username
export NZ_PASSWORD=password # Default NZ password
export NZ_DATABASE=system   # Default NZ database
PATH=/nz/kit/bin:/nz/kit/bin/adm:/nz/kit/sbin:/sbin:/usr/sbin:/bin:/usr/bin:/export/home/nz/bin:/usr/local/bin
export PATH
EMAIL_TO="USZ_ZNA_NZ_DBA@zurichna.com,gurudutt.ramamurthy@zurichna.com,mark.e.smith@zurichna.com,joe.adams@zurichna.com"
LOG_FILE=/tmp/daily_health_check.log
/nz/kit/bin/adm/nzhealthcheck > /tmp/nz_health_check.log
detailed_report=`cat /tmp/nz_health_check.log|grep -i 'Report stored in'|awk '{print $4}'`
#cat /tmp/nz_health_check.log
start_line=`cat -n /tmp/nz_health_check.log|grep -i 'System Health Check Report'|awk '{print $1}'`
start_line=$((start_line-2))
sed -i -e 1,"${start_line}d" /tmp/nz_health_check.log
echo "<html>" > ${LOG_FILE}
echo "<body>" >> ${LOG_FILE}
echo '<pre style="font: monospace">' >> ${LOG_FILE}
echo "Hi Team" >>  ${LOG_FILE}
echo "" >> ${LOG_FILE}
echo "Netezza healthcheck report on `hostname` server:" >> ${LOG_FILE}
echo "" >> ${LOG_FILE}
cat /tmp/nz_health_check.log|sed -r "s/\x1B\[([0-9]{1,3}(;[0-9]{1,2})?)?[mGK]//g"  >> ${LOG_FILE}
echo "" >> ${LOG_FILE}
echo "Thanks," >> ${LOG_FILE}
echo "Netezza DBA Team." >> ${LOG_FILE}
echo "</pre>" >> ${LOG_FILE}
echo "</body>" >> ${LOG_FILE}
echo "</html>" >> ${LOG_FILE}

SUBJECT="Healthcheck report for server `hostname` on `date '+%a %b %d %H:%M:%S %Z %Y'`"
BODY=`cat ${LOG_FILE}`
(
 echo "To: ${EMAIL_TO}"
 echo "Subject: ${SUBJECT}"
 echo "MIME-Version: 1.0"
 echo 'Content-Type: multipart/mixed; boundary="-q1w2e3r4t5"'
 echo 
 echo '---q1w2e3r4t5'
 echo "Content-Type: text/html"
 echo "Content-Disposition: inline"
 echo "${BODY}"
 echo '---q1w2e3r4t5'
 echo 'Content-Type: application; name="'$(basename $detailed_report)'"'
## echo "Content-Transfer-Encoding: base64"
 echo 'Content-Disposition: attachment; filename="'$(basename $detailed_report)'"' 
 cat $detailed_report
 echo '---q1w2e3r4t5'
) | /usr/lib/sendmail ${EMAIL_TO} 

