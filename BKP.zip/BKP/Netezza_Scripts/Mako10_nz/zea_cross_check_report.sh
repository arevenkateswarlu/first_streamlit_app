
#------------------------------------------------------------------------------
# Initialyzing the Netezza environment
#
#. ${HOME}/.bashrc
# For NPS
export NZ_USER=admin        # Default NZ username
export NZ_PASSWORD=password # Default NZ password
export NZ_DATABASE=system   # Default NZ database
PATH=/nz/kit/bin:/nz/kit/bin/adm:/nz/kit/sbin:/sbin:/usr/sbin:/bin:/usr/bin:/export/home/nz/bin:/usr/local/bin
export PATH

cd /nzscratch/autosys/scripts/logs/
rm /nzscratch/autosys/scripts/logs/ba_factls_sync.csv
nzsql -db zeadimdb -F "," -A -r -o /nzscratch/autosys/scripts/logs/ba_factls_sync.csv -c "select factls.CNVT_POL_NBR, factls.SRC_POL_EFF_DT, ENTPRS_ID,DUNS_NBR,ORGL_CONTR_ID as src_pol_nbr,POL_EXPI_DT  from factls_ins_pol_and_rlup factls, dim_cust cust, dim_ins_pol_and_rlup pol where factls.LATE_ACTV_REC_IND = 'Y' and factls.BUSN_ACTV_REC_IND = 'Y' and factls.POL_HLDR_CUST_ALT_BUSN_KEY = cust.cust_alt_busn_key and factls.INS_POL_AND_RLUP_ALT_BUSN_KEY = pol.INS_POL_AND_RLUP_ALT_BUSN_KEY and cust.late_actv_rec_ind = 'Y' and pol.late_actv_rec_ind= 'Y' and pol.busn_actv_rec_ind= 'Y' and POL_HLDR_CUST_ALT_BUSN_KEY not in (select cust_alt_busn_key from DIM_CUST WHERE LATE_ACTV_REC_IND = 'Y' and BUSN_ACTV_REC_IND = 'Y')  "
status=$?
if [ ${status} -eq 0 ]
then
echo -e "Hi Team, \n
Please find the attached report for the ZEA cross check. \n
Thanks,
Netezza Team." | mailx -s "ZEA cross check reports `date`" -a "/nzscratch/autosys/scripts/logs/ba_factls_sync.csv" "v.are-c@zurichna.com,USZ_Data_Stewardship@zurichna.com,USZ_ZNAW_Support@zurichna.com,USZ.ZNA.MDM@zurichna.com"
else
echo "ZEA Cross check reports generation was failed."|mailx -s "ZEA cross check reports generation failed `date`" "v.are-c@zurichna.com,USZ_Data_Stewardship@zurichna.com,USZ_ZNAW_Support@zurichna.com,USZ.ZNA.MDM@zurichna.com"
fi
