#!/bin/bash
date;

#Performing groom for CBT table DIM database
for table in `nzsql -db ZEADIMDB -qtc "select TABLENAME from _V_TABLE_ORGANIZE_COLUMN"`
do
/nz/support/bin/nz_groom -records all ZEADIMDB ${table}
done

## Performs Groom and Stats 
/nz/support/bin/nz_genstats -full ZEADIMDB ;
/nz/support/bin/nz_genstats -full EDW ;
