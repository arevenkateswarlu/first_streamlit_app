#!/bin/bash
. ~nz/.bashrc 2>/dev/null
#set -vx
current_date=`date '+%Y-%m-%d'`
db_name=ZNAWFDSDB
email_list="r.kazhankodath@zurichna.com,mark.e.smith@zurichna.com,jagadeesh.ramalingam-c@zurichna.com,vishwa.1.gunna-c@zurichna.com"
export LOG=/export/home/nz/log/tsm_backup.log
hst_name=`hostname`
/nz/kit/bin/nzbackup -db ${db_name}  -u dbaall -connector tivoli -connectorArgs "TSM_PASSWD=zurnetcdcp10-fea" -streams 4 -pw 'dbaadm16@'
##echo "{$db_name} TSM backup status " | mailx -s " ${db_name} TSM backup from  ${hst_name} on $current_date is completed" -c USZ_ZNA_NZ_DBA@zurichna.com  < $LOG  ${email_list}
