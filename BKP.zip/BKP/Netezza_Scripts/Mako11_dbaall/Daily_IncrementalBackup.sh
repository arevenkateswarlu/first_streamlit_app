#!/bin/bash
date;

## Daily Incremental backups

/nz/kit/bin/nzbackup -db ACCSLNDPRD -connector tivoli -differential -connectorArgs "TSM_PASSWD=zurnetcdcp11-fea" -streams 4
/nz/kit/bin/nzbackup -db ZEACFLDB -connector tivoli -differential -connectorArgs "TSM_PASSWD=zurnetcdcp11-fea" -streams 4 -disableViewCheck
/nz/kit/bin/nzbackup -db ZEAMSTDB -connector tivoli -differential -connectorArgs "TSM_PASSWD=zurnetcdcp11-fea" -streams 4 -disableViewCheck
/nz/kit/bin/nzbackup -db ZNAWADSDB -connector tivoli -differential -connectorArgs "TSM_PASSWD=zurnetcdcp11-fea" -streams 4 -disableViewCheck
/nz/kit/bin/nzbackup -db ZNAWFDSDB -connector tivoli -differential -connectorArgs "TSM_PASSWD=zurnetcdcp11-fea" -streams 4 -disableViewCheck
/nz/kit/bin/nzbackup -db ZNAWSNPSHT -connector tivoli -differential -connectorArgs "TSM_PASSWD=zurnetcdcp11-fea" -streams 4
/nz/kit/bin/nzbackup -db ZNAWSTGDB -connector tivoli -differential -connectorArgs "TSM_PASSWD=zurnetcdcp11-fea" -streams 4
/nz/kit/bin/nzbackup -db QHIST -connector tivoli -differential -connectorArgs "TSM_PASSWD=zurnetcdcp11-fea" -streams 4
/nz/kit/bin/nzbackup -db NPS_MONITOR -connector tivoli -differential -connectorArgs "TSM_PASSWD=zurnetcdcp11-fea" -streams 4
##/nz/kit/bin/nzbackup -db ZNAWCDCDB -connector tivoli -differential -connectorArgs "TSM_PASSWD=zurnetcdcp11-fea" -streams 4
/nz/kit/sbin/sendMail -dst USZ_ZNA_NZ_DBA@zurichna.com  -msg "Mako 11 Daily Incremental Backups" -bodyText "\n Hi Team,\n\n Daily Incremental backups of  ACCSLNDPRD,ZEACFLDB,ZEAMSTDB,ZNAWADSDB,ZNAWFDSDB,ZNAWSNPSHT,ZNAWSTGDB,QHIST,ZNAWCDCDB & NPS_MONITOR were completed successfully \n\n\n Thank you!\n "

