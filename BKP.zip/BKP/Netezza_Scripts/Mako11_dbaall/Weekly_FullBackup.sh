#!/bin/bash
date;

## Weekly Full backups

/nz/kit/bin/nzbackup -db ACCSLNDPRD -connector tivoli -connectorArgs "TSM_PASSWD=zurnetcdcp11-fea" -streams 4
/nz/kit/bin/nzbackup -db ZEACFLDB -connector tivoli -connectorArgs "TSM_PASSWD=zurnetcdcp11-fea" -streams 4 -disableViewCheck
/nz/kit/bin/nzbackup -db ZEAMSTDB -connector tivoli -connectorArgs "TSM_PASSWD=zurnetcdcp11-fea" -streams 4 -disableViewCheck
/nz/kit/bin/nzbackup -db ZNAWADSDB -connector tivoli -connectorArgs "TSM_PASSWD=zurnetcdcp11-fea" -streams 4 -disableViewCheck
/nz/kit/bin/nzbackup -db ZNAWFDSDB -connector tivoli -connectorArgs "TSM_PASSWD=zurnetcdcp11-fea" -streams 4 -disableViewCheck
/nz/kit/bin/nzbackup -db ZNAWSNPSHT -connector tivoli -connectorArgs "TSM_PASSWD=zurnetcdcp11-fea" -streams 4
/nz/kit/bin/nzbackup -db ZNAWSTGDB -connector tivoli -connectorArgs "TSM_PASSWD=zurnetcdcp11-fea" -streams 4
/nz/kit/bin/nzbackup -db QHIST -connector tivoli -connectorArgs "TSM_PASSWD=zurnetcdcp11-fea" -streams 4
/nz/kit/bin/nzbackup -db NPS_MONITOR -connector tivoli -connectorArgs "TSM_PASSWD=zurnetcdcp11-fea" -streams 4
##/nz/kit/bin/nzbackup -db ZNAWCDCDB -connector tivoli -connectorArgs "TSM_PASSWD=zurnetcdcp11-fea" -streams 4
/nz/kit/sbin/sendMail -dst USZ_ZNA_NZ_DBA@zurichna.com  -msg "Mako 11 Full Backups" -bodyText "\n Hi Team,\n\n Weekly Full  backups of  ACCSLNDPRD,ZEACFLDB,ZEAMSTDB,ZNAWADSDB,ZNAWFDSDB,ZNAWSNPSHT,ZNAWSTGDB,QHIST,ZNAWCDCDB & NPS_MONITOR were completed successfully \n\n\n Thank you!\n "

