#!/bin/bash
. ~nz/.bashrc 2>/dev/null
#set -vx 
current_date=`date '+%Y-%m-%d'`
email_list="r.kazhankodath@zurichna.com,mark.e.smith@zurichna.com,jagadeesh.ramalingam-c@zurichna.com,vishwa.1.gunna-c@zurichna.com"
export LOG=/export/home/nz/log/audit.xlsx
hst_name=`hostname`
sql="select QH_USER, QH_CLIIPADDR, qh_database,QH_TSUBMIT, QH_SQL  from HIST_USR.NZ_QUERY_HISTORY where qh_user like '%INFA%' and qh_cliipaddr not in ('10.147.163.33','10.147.163.34') and qh_database <> 'ZNAWUSERDB' and qh_tsubmit between last_day(now() - interval '2 month') + interval '1 day' and last_day(now() - interval '1 month') order by 4 ;"
nzsql  HISTDB -c "$sql" > $LOG
echo "Audit report from ${hst_name} " | mailx -s " Audit report from ${hst_name} on $current_date " -c USZ_ZNA_NZ_DBA@zurichna.com  < $LOG  ${email_list}
\rm $LOG 2>/dev/null

