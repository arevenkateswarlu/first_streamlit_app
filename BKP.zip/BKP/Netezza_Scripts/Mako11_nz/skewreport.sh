#!/bin/bash
date;
/nz/support/bin/nz_skew 1024 -sort skew > /nzscratch/vishwa/skewreports.txt;
chmod 744 /nzscratch/vishwa/skewreports.txt;
tail -n+23 /nzscratch/vishwa/skewreports.txt > /nzscratch/vishwa/skewreport.txt;
chmod 744 /nzscratch/vishwa/skewreport.txt;
cut -f 1,2,3,8 -d "|" /nzscratch/vishwa/skewreport.txt > /nzscratch/vishwa/Mako11SkewReport.txt;
chmod 744 /nzscratch/vishwa/Mako11SkewReport.txt;
/nz/kit/sbin/sendMail -dst "USZ_ZNA_NZ_DBA@zurichna.com,gurudutt.ramamurthy@zurichna.com"  -msg "Mako 11 Skew report" -bodyText "\n Hi Team,\n\n Please find the skew report \n\n Thank you!\n" -attach /nzscratch/vishwa/Mako11SkewReport.txt 

