set -x
#!/bin/bash
date;

nzsql -u dbaall -pw dbaadm16@ -c "SELECT DBNAME,BACKUPSET,OPTYPE as Backup_Type,SEQNO,Status,STARTTIME,LASTUPDATE, USERNAME from _v_backup_history where date(starttime) like '2021-0%'" > /nzscratch/vishwa/dailybackup.log
chmod 744 /nzscratch/vishwa/dailybackup.log ;
/nz/kit/sbin/sendMail -dst usz_zna_nz_dba@zurichna.com  -msg "Mako 11 TSM Backup Status "  -bodyText "\n Hi,\n\n Please find the attached Daily TSM Backup Status\n\n Thank you!\n"  -attach  "/nzscratch/vishwa/dailybackup.log"

