#!/bin/bash
date;

/nz/kit/bin/nzbackup -db ZNAWFDSDB -u dbaall -connector tivoli -connectorArgs "TSM_PASSWD=zurnetcdcp10-fea" -streams 4
date=$(date "+%Y%m%d");

/nz/kit/sbin/sendMail -dst USZ_ZNA_NZ_DBA@zurichna.com  -msg "Mako 10 FDS   Full Backups" -bodyText "\n Hi Team,\n\n Full backup FDS  is  completed \n\n\n Thank you!\n "
