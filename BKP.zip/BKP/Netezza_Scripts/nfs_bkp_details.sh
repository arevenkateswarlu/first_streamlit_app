#!/bin/ksh

df -t nfs -Ph|sed 's/Mounted on/Filesystem/g'|awk '{print $2" "$3" "$4" "$5" "$6}' > /tmp/nfs_mount.out
echo "Filesystem Server Database Backupset Size_GB" > /tmp/nfs_bkp_details.out
cat /tmp/nfs_mount.out|awk '{print $5}'|grep -iv Filesystem|while read fs
do
du -m --max-depth=4 ${fs}/part1 | awk -F/ '{print $1" "$(NF-2)" "$(NF-1)" "$(NF)}' |while read size_mb server dbname backupset
do
if [[ ${backupset} =~ ^[0-9]+$ ]]
then
if [ ${size_mb} -gt 10 ]
then
size_gb=`echo "$(( 4 * size_mb / 1024))"`
echo "${fs} ${server} ${dbname} ${backupset} ${size_gb}" >> /tmp/nfs_bkp_details.out
fi
fi
done
done
cat /tmp/nfs_bkp_details.out|sed 's/_NPS//g' > /tmp/nfs_bkp_details_1.out
mv /tmp/nfs_bkp_details_1.out /tmp/nfs_bkp_details.out


format_output()
{
file_name=$1
NUM_COL=`cat ${file_name}|awk -F' ' '{print NF;exit}'`
rows=`cat ${file_name}|wc -l`
  j=1
  header=1
  echo "<table border=2>" >> ${LOG_FILE}
  for i in $(cat ${file_name})
  do
#    j=1
    if [ $j -eq 1 ]
    then
      if [ ${header} -eq 1 ]
      then
        echo "<tr style=font-weight:bold>" >> ${LOG_FILE}
        header=0
      else
        echo "<tr>" >> ${LOG_FILE}
      fi
    fi
    echo "<td>" >> ${LOG_FILE}
    echo $i  >> ${LOG_FILE}
    echo "</td>" >> ${LOG_FILE}
    if [ $j -eq $NUM_COL ]
    then
      j=0
      echo "</tr>" >> ${LOG_FILE}
    fi
#    ((j+=1))
    ((j+=1))
  done
  echo "</table>" >> ${LOG_FILE}

}

FSTAMP=`date +"%d%m%Y"`
LOG_FILE=${HOME}/MON_SCRIPTS/LOGS/nfs_bkp_details_${FSTAMP}.out
echo "Hi Team," > ${LOG_FILE}
echo "" >> ${LOG_FILE}
echo "Netezza databases Backup existed on NFS Filesystem:" >> ${LOG_FILE}
echo "" >> ${LOG_FILE}
format_output /tmp/nfs_mount.out
format_output /tmp/nfs_bkp_details.out
echo "" >> ${LOG_FILE}
echo "Thanks," >> ${LOG_FILE}
echo "Nettezza DBA team." >> ${LOG_FILE}
EMAIL_TO="USZ_ZNAW_Release_Dev_Team@zurichna.com,USZ.ZNAW.Release@zurichna.com,USZ_ZNAW_Support@zurichna.com,USZ_ZNA_NZ_DBA@zurichna.com,USZ.ACTWS.Capgemini.Dev@zurichna.com,USZ.ACTWS.Testing@zurichna.com,USZ.Apache.Testing@zurichna.com,gurudutt.ramamurthy@zurichna.com,USZ.ZNAW.Release.Testing@zurichna.com,r.kazhankodath@zurichna.com,joe.adams@zurichna.com,matthew.guidera@zurichna.com,USZ.ZNAW.CLH.DEV.Team@zurichna.com"
SUBJECT="Netezaa databases NFS backup  `date '+%a %b %d %H:%M:%S %Z %Y'`"
export BODY=`echo ${LOG_FILE}`
(
 echo "To: ${EMAIL_TO}"
 echo "Subject: $SUBJECT"
 echo "MIME-Version: 1.0"
 echo 'Content-Type: multipart/mixed; boundary="-q1w2e3r4t5"'
 echo '---q1w2e3r4t5'
 echo "Content-Type: text/html"
 echo "Content-Disposition: inline"
 echo "<html> "
 echo "<body> "
 echo '<pre style="font: monospace ">'
 cat ${BODY}
 echo "</pre> </body> </html>"
 echo '---q1w2e3r4t5--'
) | /usr/lib/sendmail ${EMAIL_TO}

