#!/bin/bash
date;

DAY_OF_WEEK=`date +"%u"`

if [ ${DAY_OF_WEEK} -eq 0 ] || [ ${DAY_OF_WEEK} -eq 7 ]
then
/nz/kit/bin/nzbackup -db TABLE_BACKUPS  -connector tivoli -connectorArgs "TSM_PASSWD=zurnetcdcp13-fea" -streams 4
else

/nz/kit/bin/nzbackup -db TABLE_BACKUPS -connector tivoli -differential -connectorArgs "TSM_PASSWD=zurnetcdcp13-fea" -streams 4
fi

