for group in $(db2 get dbm cfg |grep -i 'group name'|awk '{print $6}'|awk 'NF')
do
        instance_name=$(db2 get instance|grep -i 'database manager'|awk '{print $7}')
        host_name=${hostname}
        for username in $(cat /etc/group |grep -i "${group}:"|awk -F':' '{ print $4}' |tr ',' '\n'|awk 'NF' )
        do
                user_count=$(cat /etc/passwd |grep -i "${username}:"|wc -l)
                if [ ${user_count} -eq 1 ]
                then
                        echo "${host_name} ${instance_name} DBM ${username} ${group} LOCAL"
                else
                        ad_user_count=$(/opt/quest/bin/vastool user checkaccess ${username}|grep -i 'allow'|grep -iw "${username}"|wc -l )
                        if [ ${ad_user_count} -eq 1 ]
                        then
                                echo "${host_name} ${instance_name} DBM ${username} ${group} AD"
                        else
                                echo "${host_name} ${instance_name} DBM ${username} ${group} NOT_DETERMINE"
                        fi
                fi
        done
done
for dbname in $(db2 list db directory|awk -v RS= '/Indirect/'|grep -i 'Database name'|awk '{print $4}'|sort|uniq)
do
        instance_name=$(db2 get instance|grep -i 'database manager'|awk '{print $7}')
        host_name=${hostname}
        db2 connect to ${dbname} >> /dev/null
        #echo "Connecting to ${dbname} is failed "
        for username in $(db2 -x "Select rtrim(AUTHID) from SYSIBMADM.AUTHORIZATIONIDS where AUTHID not in ('PUBLIC') and AUTHIDTYPE in ('U')")
        do
                user_count=$(cat /etc/passwd |grep -i "${username}:"|wc -l)
                if [ ${user_count} -eq 1 ]
                then
                        echo "${host_name} ${instance_name} ${dbname} ${username} DIRECT_ACCESS LOCAL"
                else
                        ad_user_count=$(/opt/quest/bin/vastool user checkaccess ${username}|grep -i 'allow'|grep -iw "${username}"|wc -l )
                        if [ ${ad_user_count} -eq 1 ]
                        then
                                echo "${host_name} ${instance_name} ${dbname} ${username} DIRECT_ACCESS AD"
                        else
                                echo "${host_name} ${instance_name} ${dbname} ${username} DIRECT_ACCESS NOT_DETERMINE"
                        fi
                fi
        done
        for group in $(db2 -x "Select rtrim(AUTHID) from SYSIBMADM.AUTHORIZATIONIDS where AUTHID not in ('PUBLIC') and AUTHIDTYPE in ('G')")
        do
                instance_name=$(db2 get instance|grep -i 'database manager'|awk '{print $7}')
                host_name=${hostname}
                for username in $(cat /etc/group |grep -i "${group}:"|awk -F':' '{ print $4}' |tr ',' '\n'|awk 'NF' )
                do
                        user_count=$(cat /etc/passwd |grep -i "${username}:"|wc -l)
                        if [ ${user_count} -eq 1 ]
                        then
                                echo "${host_name} ${instance_name} ${dbname} ${username} ${group} LOCAL"
                        else
                                ad_user_count=$(/opt/quest/bin/vastool user checkaccess ${username}|grep -i 'allow'|grep -iw "${username}"|wc -l )
                                if [ ${ad_user_count} -eq 1 ]
                                then
                                        echo "${host_name} ${instance_name} ${dbname} ${username} ${group} AD"
                                else
                                        echo "${host_name} ${instance_name} ${dbname} ${username} ${group} NOT_DETERMINE"
                                fi
                        fi
                done
        done
done
