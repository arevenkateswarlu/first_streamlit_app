SELECT DISTINCT 
rwr.WORKFLOW_RUN_ID ,
rwr.WORKFLOW_NAME,
rwr.SERVER_NAME,
substr(rwr.SUBJECT_AREA,1,100) AS SUBJECT_AREA,
rwr.START_TIME WF_START_TIME,
rwr.END_TIME WF_END_TIME,
(rwr.END_TIME-rwr.START_TIME) AS execution_time_seconds,
rsl.SESSION_INSTANCE_NAME,
rsl.MAPPING_NAME,
rsl.SUCCESSFUL_SOURCE_ROWS ,
rsl.FAILED_SOURCE_ROWS,
rsl.SUCCESSFUL_ROWS,
rsl.FAILED_ROWS,
rsl.SESSION_TIMESTAMP,
CAST(rwr.RUN_ERR_MSG AS varchar(50)) AS RUN_ERR_MSG ,
CAST(rsl.LAST_ERROR AS varchar(50)) AS LAST_ERROR,
rwr.RUN_STATUS_CODE,
substr(osl.PARTITION_NAME,1,40) AS PARTITION_NAME,
CASE osl.WIDGET_TYPE when  1 then 'Source Definition' when  2 then 'Target Definition' when  3 then 'Source Qualifier' when  4 then 'Update Strategy' when  5 then 'Expression' when  6 then 'Stored Procedure' when  7 then 'Sequence' when  9 then 'Aggregator' when 10 then 'Filter' when 11 then 'Lookup Procedure' when 12 then 'Joiner' when 14 then 'Normalizer' when 15 then 'Router' when 44 then 'Mapplet' when 45 then 'Application Source Qualifier' when 46 then 'Input Transformation' when 47 then 'Output Transformation' when 55 then 'XML Source Qualifier' when 56 then 'MQ Source Qualifier' when 80 then 'Sorter' when 84 then 'App Multi-Group Source Qualifier' when 92 then 'Transaction Control' when 97 then 'Custom Transformation' ELSE CAST(osl.WIDGET_TYPE AS varchar(20)) END  AS WIDGET_TYPE_NAME, 
substr(osl.WIDGET_NAME,1,40) AS WIDGET_NAME,
substr(osl.GROUP_NAME,1,40) AS GROUP_NAME,
osl.APPLIED_ROWS,
osl.AFFECTED_ROWS,
osl.REJECTED_ROWS,
osl.START_TIME,
osl.END_TIME
FROM
INFNPADM.REP_WFLOW_RUN rwr 
JOIN INFNPADM.REP_SESS_LOG rsl ON rwr.WORKFLOW_ID = rsl.WORKFLOW_ID and rwr.WORKFLOW_RUN_ID=rsl.WORKFLOW_RUN_ID
JOIN INFNPADM.OPB_SWIDGINST_LOG osl ON rwr.WORKFLOW_ID = osl.WORKFLOW_ID and rwr.WORKFLOW_RUN_ID=osl.WORKFLOW_RUN_ID
WHERE 
rwr.START_TIME BETWEEN (to_char((current_date -4),'YYYY-MM-DD')||'-20.00.00.000000') AND (to_char(current_date,'YYYY-MM-DD')||'-08.00.00.000000') 
--AND (rwr.END_TIME-rwr.START_TIME) >= 300
--AND session_instance_name LIKE '%PQM_DUPLICATE_CHECK_UDI_AUTO%'
--ORDER BY rsl.SESSION_TIMESTAMP DESC
;




SELECT DISTINCT 
rwr.WORKFLOW_NAME,
rwr.START_TIME WF_START_TIME,
rwr.END_TIME WF_END_TIME,
rsl.SESSION_INSTANCE_NAME,
rsl.MAPPING_NAME,
rsl.SUCCESSFUL_SOURCE_ROWS ,
rsl.FAILED_SOURCE_ROWS,
rsl.SUCCESSFUL_ROWS,
rsl.FAILED_ROWS,
rsl.SESSION_TIMESTAMP,
CAST(rwr.RUN_ERR_MSG AS varchar(50)) AS RUN_ERR_MSG ,
CAST(rsl.LAST_ERROR AS varchar(50)) AS LAST_ERROR,
rwr.RUN_STATUS_CODE,
substr(osl.PARTITION_NAME,1,40) AS PARTITION_NAME,
CASE osl.WIDGET_TYPE when  1 then 'Source Definition' when  2 then 'Target Definition' when  3 then 'Source Qualifier' when  4 then 'Update Strategy' when  5 then 'Expression' when  6 then 'Stored Procedure' when  7 then 'Sequence' when  9 then 'Aggregator' when 10 then 'Filter' when 11 then 'Lookup Procedure' when 12 then 'Joiner' when 14 then 'Normalizer' when 15 then 'Router' when 44 then 'Mapplet' when 45 then 'Application Source Qualifier' when 46 then 'Input Transformation' when 47 then 'Output Transformation' when 55 then 'XML Source Qualifier' when 56 then 'MQ Source Qualifier' when 80 then 'Sorter' when 84 then 'App Multi-Group Source Qualifier' when 92 then 'Transaction Control' when 97 then 'Custom Transformation' ELSE CAST(osl.WIDGET_TYPE AS varchar(20)) END  AS WIDGET_TYPE_NAME, 
substr(osl.WIDGET_NAME,1,40) AS WIDGET_NAME,
substr(osl.GROUP_NAME,1,40) AS GROUP_NAME,
osl.APPLIED_ROWS,
osl.AFFECTED_ROWS,
osl.REJECTED_ROWS,
osl.START_TIME,
osl.END_TIME
FROM
INFNPADM.REP_WFLOW_RUN rwr 
JOIN INFNPADM.REP_SESS_LOG rsl ON rwr.WORKFLOW_ID = rsl.WORKFLOW_ID and rwr.WORKFLOW_RUN_ID=rsl.WORKFLOW_RUN_ID
JOIN INFNPADM.OPB_SWIDGINST_LOG osl ON rwr.WORKFLOW_ID = osl.WORKFLOW_ID and rwr.WORKFLOW_RUN_ID=osl.WORKFLOW_RUN_ID
WHERE 
rwr.WORKFLOW_NAME  LIKE 'wf_CLH_PRST_PROGRAM_LOB_SPLIT_PCT'
AND rsl.SESSION_TIMESTAMP >= '2023-03-20'
--AND session_instance_name LIKE '%PQM_DUPLICATE_CHECK_UDI_AUTO%'
--ORDER BY rsl.SESSION_TIMESTAMP DESC
;


