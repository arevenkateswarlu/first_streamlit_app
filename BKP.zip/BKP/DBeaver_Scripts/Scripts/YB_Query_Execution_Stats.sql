/*
set search_path to public; select db_name,rel_id,rel_type as rel_kind,schema_name as rel_schema,rel_name,col_id,col_name,col_type,nullable,encrypted,default_value,current_date as extracted_dt,'PROD' as region from sysviews.public.column_p() where schema_name='dbaall' and default_value is not null;


create table znawuserdb.dbaall.query_history as (select * from sys.log_query );

grant select on znawuserdb.dbaall.query_history to dbaall ;
commit;
*/




with query_hist_exec_stats as 
(
select 
extract(year from submit_time) as year,
extract(month from submit_time) as month,
DATENAME('month',submit_time) as month_text,
case 
		when lower(username) like 'usz%' or lower(username) like 'xcg%' then 'Adhoc' 
		else username 
	end as username,
	
state,
count(*) as queries_executed,
sum((run_ms - wait_run_cpu_ms - wait_run_io_ms)) as cpu_ms,
sum(parse_ms) as parse_ms,
sum(wait_parse_ms) as wait_parse_ms,
sum(wait_lock_ms) as wait_lock_ms,
sum(plan_ms) as plan_ms,
sum(wait_plan_ms) as wait_plan_ms,
sum(assemble_ms) as assemble_ms,
sum(wait_assemble_ms) as wait_assemble_ms,
sum(compile_ms) as compile_ms,
sum(wait_compile_ms) as wait_compile_ms,
sum(acquire_resources_ms) as acquire_resources_ms,
sum(run_ms) as run_ms,
sum(wait_run_cpu_ms) as wait_run_cpu_ms,
sum(wait_run_io_ms) as wait_run_io_ms,
sum(wait_run_spool_ms) as wait_run_spool_ms,
sum(client_ms) as client_ms,
sum(wait_client_ms) as wait_client_ms,
sum(total_ms) as total_ms,
sum(cancel_ms) as cancel_ms,
sum(restart_ms) as restart_ms,
sum(wlm_runtime_ms) as wlm_runtime_ms,
sum(spool_ms) as spool_ms,
sum(io_read_bytes) as io_read_bytes,
sum(io_write_bytes) as io_write_bytes,
sum(io_spill_read_bytes) as io_spill_read_bytes,
sum(io_spill_write_bytes) as io_spill_write_bytes,
sum(io_network_bytes) as io_network_bytes,
sum(io_client_read_bytes) as io_client_read_bytes,
sum(io_client_write_bytes) as io_client_write_bytes,
sum(io_spool_write_bytes) as io_spool_write_bytes,
sum(rows_inserted) as rows_inserted,
sum(rows_deleted) as rows_deleted,
sum(rows_returned) as rows_returned
--avg(memory_bytes) as memory_bytes,
--sum(io_spill_space_bytes) as io_spill_space_bytes

from 
znawuserdb.dbaall.query_history

where 
(upper(query_text) not like '%SELECT VERSION()%' AND
     UPPER(QUERY_TEXT) not like 'ANALYZE%'   and
     UPPER(QUERY_TEXT) not like 'DEALLOCATE%' and
     UPPER(QUERY_TEXT) not like 'SHOW%' and
     QUERY_TEXT not like 'select current_database()%' and
     QUERY_TEXT not like 'select current_schema()%' and
     QUERY_TEXT not like 'SELECT current_schema(),session_user%' and
     QUERY_TEXT not like 'select n.nspname, c.relname, a.attname, a.atttypid, t.typname, a.attnum, a.attlen, a.atttypmod, a.attnotnull,%'  and 
	 QUERY_TEXT not like 'SELECT db.oid,db.* FROM pg_catalog.pg_database%' and
	 QUERY_TEXT not like 'select * from pg_catalog.pg_settings%' and 
	 QUERY_TEXT not like 'select string_agg(word, %	 from pg_catalog%' and 
	 QUERY_TEXT not like 'SELECT typcategory FROM pg_catalog.pg_type%' and 
	 QUERY_TEXT not like 'SELECT t.oid,t.*,c.relkind,format_type%' and 
	 QUERY_TEXT not like 'SELECT * FROM VERSION%' and 
	 QUERY_TEXT not like 'SELECT oid, typname from pg_type%' and 
	 QUERY_TEXT not like 'SELECT n.oid,n.*,d.description FROM pg_catalog.pg_namespace%'
	 )

group by 
extract(year from submit_time),
extract(month from submit_time),
DATENAME('month',submit_time),
case 
		when lower(username) like 'usz%' or lower(username) like 'xcg%' then 'Adhoc' 
		else username 
	end ,
state
order by 
extract(year from submit_time) asc,
extract(month from submit_time) asc
)
select 
year,
month,
month_text,
username,
state,
queries_executed,
round(cpu_ms/1000,0) as cpu_s,
round(parse_ms/1000,0) as parse_s,
round(wait_parse_ms/1000,0) as wait_parse_s,
round(wait_lock_ms/1000,0) as wait_lock_s,
round(plan_ms/1000,0) as plan_s,
round(wait_plan_ms/1000,0) as wait_plan_s,
round(assemble_ms/1000,0) as assemble_s,
round(wait_assemble_ms/1000,0) as wait_assemble_s,
round(compile_ms/1000,0) as compile_s,
round(wait_compile_ms/1000,0) as wait_compile_s,
round(acquire_resources_ms/1000,0) as acquire_resources_s,
round(run_ms/1000,0) as run_s,
round(wait_run_cpu_ms/1000,0) as wait_run_cpu_s,
round(wait_run_io_ms/1000,0) as wait_run_io_s,
round(wait_run_spool_ms/1000,0) as wait_run_spool_s,
round(client_ms/1000,0) as client_s,
round(wait_client_ms/1000,0) as wait_client_s,
round(total_ms/1000,0) as total_s,
round(cancel_ms/1000,0) as cancel_s,
round(restart_ms/1000,0) as restart_s,
round(wlm_runtime_ms/1000,0) as wlm_runtime_s,
round(spool_ms/1000,0) as spool_s,
round(io_read_bytes/(1024.0*1024.0*1024.0),0) as io_read_gb,
round(io_write_bytes/(1024.0*1024.0*1024.0),0) as io_write_gb,
round(io_spill_read_bytes/(1024.0*1024.0*1024.0),0) as io_spill_read_gb,
round(io_spill_write_bytes/(1024.0*1024.0*1024.0),0) as io_spill_write_gb,
round(io_network_bytes/(1024.0*1024.0*1024.0),0) as io_network_gb,
round(io_client_read_bytes/(1024.0*1024.0*1024.0),0) as io_client_read_gb,
round(io_client_write_bytes/(1024.0*1024.0*1024.0),0) as io_client_write_gb,
round(io_spool_write_bytes/(1024.0*1024.0*1024.0),0) as io_spool_write_gb,
rows_inserted,
rows_deleted,
rows_returned
from 
query_hist_exec_stats

order by 
year asc,
month asc
;