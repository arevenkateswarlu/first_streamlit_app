--select count(*) from sys.log_query limit 100;
--select datname,usename,client_addr,backend_start,xact_start,query_start,state_change,waiting,state,backend_xid,backend_xmin,session_id,query_id,last_statement,tx_readonly from pg_stat_activity where backend_xid is not null or backend_xmin is not null ;


select * 
from pg_stat_activity
where (state = 'idle in transaction')
    and xact_start is not null;
	



 select submit_time,done_time,total_ms,client_ms,run_ms,wait_lock_ms,acquire_resources_ms,query_id,username,state,type,tags,database_name,substr(query_text,position('/* ' in query_text)+3, position(' */' in query_text)-position('/* ' in query_text)) as report_name from sys.log_query where username='yb_boeusr_wl' and database_name='zeadimdb' and lower(query_text) like '%fact_pol_comb_mm_snpsht %' and lower(application_name) not like '%dbeaver%' /*and date(submit_time) >='2023-04-01'  and submit_time >= '2023-05-24 11:00:00' */ and submit_time >= '2023-06-05 06:00:00' order by submit_time desc ;
 
 select submit_time,done_time,total_ms,client_ms,run_ms,wait_lock_ms,acquire_resources_ms,query_id,username,state,type,tags,database_name,substr(query_text,position('/* ' in query_text)+3, position(' */' in query_text)-position('/* ' in query_text)) as report_name from sys.log_query where username='yb_boeusr_wl' and tags is not null and database_name='znawsnpsht' and lower(query_text) like '%fact_mm_pol_comb_mm_snpsht %' and lower(application_name) not like '%dbeaver%'  and date(submit_time) >='2023-04-01'  order by submit_time desc ;
 

select submit_time,query_id,username,database_name,state,type,done_time,total_ms,client_ms,run_ms,wait_lock_ms,(io_network_bytes/(1024.0*1024.0*1024.)) as io_network_gb,(io_spill_space_bytes/(1024.0*1024.0*1024.0)) as io_spill_space_gb,rows_returned from sys.log_query where username in ('InfaDaily','InfaMonthly') and date(submit_time) between '2023-03-31' and '2023-04-04' order by submit_time desc ;



select name,replace(replace(cast(memberof as char(1000)),'{',''),'}','') as memberof from sys.user order by name ;


select * from znaw_term.dbaall.myaccess_users_hist order by process_dt desc;




--select submit_time,query_id,database_name,username,tags,done_time,total_ms,acquire_resources_ms from sys.log_query where username='yb_boeusr_wl' and submit_time between '2023-07-07 15:00:00' and '2023-07-07 15:25:00' and pool_id is not null order by submit_time desc ;



select submit_time,query_id,username,state,done_time,total_ms,wait_lock_ms,acquire_resources_ms,run_ms,wait_run_cpu_ms,wait_run_io_ms,client_ms,io_read_bytes,io_write_bytes,io_spill_read_bytes,io_spill_write_bytes,io_network_bytes,io_client_read_bytes,io_client_write_bytes,io_spool_write_bytes,rows_inserted,rows_deleted,rows_returned from sys.log_query where ((submit_time <='2023-07-08 03:00:00' and done_time >='2023-07-08 07:00:00') or (submit_time <='2023-07-08 03:00:00' and done_time <='2023-07-08 07:00:00' and done_time >='2023-07-08 03:00:00') or (submit_time >='2023-07-08 03:00:00' and done_time>='2023-07-08 07:00:00' and submit_time <= '2023-07-08 07:00:00') or (submit_time >='2023-07-08 03:00:00' and  done_time <='2023-07-08 07:00:00')  ) and pool_id is not null order by submit_time desc ;



select u.name,max(date(a.start_time)) as last_login from sys.user u left join sys.log_authentication a on u.name=a.username group by u.name order by u.name asc






create table znawuserdb.dbaall.query_history as 
select 
*
from sys.log_query 
where 
--submit_time >= '2022-03-01'
date(submit_time) in ('2023-09-30','2023-10-01','2023-10-02','2023-11-01','2023-11-02')
--and username='yb_boeusr_wl'
and (upper(query_text) not like '%SELECT VERSION()%' AND
     UPPER(QUERY_TEXT) not like 'ANALYZE%'   and
     UPPER(QUERY_TEXT) not like 'DEALLOCATE%' and
     UPPER(QUERY_TEXT) not like 'SHOW%' and
     QUERY_TEXT not like 'select current_database()%' and
     QUERY_TEXT not like 'select current_schema()%' and
     QUERY_TEXT not like 'SELECT current_schema(),session_user%' and
     QUERY_TEXT not like 'select n.nspname, c.relname, a.attname, a.atttypid, t.typname, a.attnum, a.attlen, a.atttypmod, a.attnotnull,%' ) and 
	 QUERY_TEXT not like 'SELECT db.oid,db.* FROM pg_catalog.pg_database%' and
	 QUERY_TEXT not like 'select * from pg_catalog.pg_settings%' and 
	 QUERY_TEXT not like 'select string_agg(word, %	 from pg_catalog%' and 
	 QUERY_TEXT not like 'SELECT typcategory FROM pg_catalog.pg_type%' and 
	 QUERY_TEXT not like 'SELECT t.oid,t.*,c.relkind,format_type%' and 
	 QUERY_TEXT not like 'SELECT * FROM VERSION%' and 
	 QUERY_TEXT not like 'SELECT oid, typname from pg_type%'  

--group by pool_id
;

commit ;
select query_text from sys.log_query where query_id=8652754338;



select 
--extract(year from submit_time) as submit_year,
--extract(month from submit_time) as submit_month,
date(submit_time),
--database_name,
username,
count(*) as queries_executed,
sum(wait_lock_ms)/1000 as sum_wait_lock_s,
avg(wait_lock_ms)/1000 as avg_wait_lock_s,
sum(acquire_resources_ms)/1000 as sum_acquire_resources_s,
avg(acquire_resources_ms)/1000 as avg_acquire_resources_s,
sum(run_ms)/1000 as sum_run_s,
avg(run_ms)/1000 as avg_run_s,
sum(wait_run_cpu_ms)/1000 as sum_wait_run_cpu_s,
avg(wait_run_cpu_ms)/1000 as avg_wait_run_cpu_s,
sum(wait_run_io_ms)/1000 as sum_wait_run_io_s,
avg(wait_run_io_ms)/1000 as avg_wait_run_io_s,
sum((run_ms - wait_run_cpu_ms - wait_run_io_ms))/1000 as sum_cpu_usage_s,
avg((run_ms - wait_run_cpu_ms - wait_run_io_ms))/1000 as avg_cpu_usage_s,
sum(io_read_bytes)/(1024*1024.0*1024.0*1024.0) as io_read_tb,
sum(io_write_bytes)/(1024*1024.0*1024.0*1024.0) as io_write_tb , 
sum(io_spill_read_bytes)/(1024*1024.0*1024.0*1024.0) as io_spill_read_tb,
sum(io_spill_write_bytes)/(1024*1024.0*1024.0*1024.0) as io_spill_write_tb,
sum(rows_inserted) as rows_inserted,
sum(rows_deleted) as rows_deleted,
sum(rows_returned) as rows_returned

from znawuserdb.dbaall.query_history
--where 
--state='done'
--and username not in ('sys_ybd_analyze','sys_ybd_dcs','sys_ybd_gc','sys_ybd_lime','sys_ybd_parity_rebuild','sys_ybd_replicator','ybdadmin','yellowbrick')

group by 
--extract(year from submit_time),
--extract(month from submit_time),
date(submit_time),
--database_name,
username
order by
date(submit_time),
--submit_year desc,
--submit_month desc,
--database_name,
username
;




select submit_time,date(submit_time) as submit_date,extract(hr from submit_time) as submitted_hr,query_id,username,database_name,type,state,done_time,total_ms,wait_lock_ms,acquire_resources_ms,run_ms,wait_run_cpu_ms,(run_ms - wait_run_cpu_ms - wait_run_io_ms) as cpu_usage_ms,wait_run_io_ms,client_ms,io_read_bytes,io_write_bytes,io_spill_read_bytes,io_spill_write_bytes,io_network_bytes,io_client_read_bytes,io_client_write_bytes,io_spool_write_bytes,rows_inserted,rows_deleted,rows_returned,REGEXP_REPLACE(REGEXP_REPLACE(query_text,'\r',''),'\n','')  from sys.log_query 
where (username='usz2mx0' or (username='yb_boeusr_wl' and upper(tags)='YOLANDA.HARRIS'))  
and pool_id is not null 
and submit_time >'2023-10-01 00:00:00'
and (upper(query_text) not like '%SELECT VERSION()%' AND
     UPPER(QUERY_TEXT) not like 'ANALYZE%'   and
     UPPER(QUERY_TEXT) not like 'DEALLOCATE%' and
     UPPER(QUERY_TEXT) not like 'SHOW%' and
     QUERY_TEXT not like 'select current_database()%' and
     QUERY_TEXT not like 'select current_schema()%' and
     QUERY_TEXT not like 'SELECT current_schema(),session_user%' and
     QUERY_TEXT not like 'select n.nspname, c.relname, a.attname, a.atttypid, t.typname, a.attnum, a.attlen, a.atttypmod, a.attnotnull,%' ) and 
	 QUERY_TEXT not like 'SELECT db.oid,db.* FROM pg_catalog.pg_database%' and
	 QUERY_TEXT not like 'select * from pg_catalog.pg_settings%' and 
	 QUERY_TEXT not like 'select string_agg(word, %	 from pg_catalog%' and 
	 QUERY_TEXT not like 'SELECT typcategory FROM pg_catalog.pg_type%' and 
	 QUERY_TEXT not like 'SELECT t.oid,t.*,c.relkind,format_type%' and 
	 QUERY_TEXT not like 'SELECT * FROM VERSION%' and 
	 QUERY_TEXT not like 'SELECT oid, typname from pg_type%' and
	 QUERY_TEXT not like '%select current_database();'
order by submit_time;






select 
distinct 
lq.submit_time,
lq.username,
lqa.query_id, 
lq.database_name ,
lq.type ,
lq.io_network_bytes/1024^4 as io_network_tb,
lq.io_read_bytes/1024^3 as io_read_gb,
lq.rows_inserted,
lq.rows_returned ,
lq.io_spill_write_bytes/1024^4 as io_spill_write_tb,
lq.run_ms/1000 as run_s,
case 
when ( lqa.skew > 0.5 and lqa.rows_actual > 10000000 )  then 'SKEW'  
when ( lqa.io_network_bytes/1024^4 >= 10 and (lqa.io_read_bytes/1024^3 < 100 or lq.rows_inserted < 1000000000 or lq.rows_returned > 0) )  then 'Network_IO'   
when (lq.io_spill_write_bytes/1024^4 >= 10 ) then 'SPILL_WRITE'
when (lq.run_ms/1000 >= 3600 ) then 'RUN_TIME'
else 'None' end as Threshold_breached
from 
sys.log_query_analyze lqa 
inner join sys.log_query lq on lqa.query_id = lq.query_id 
where 
lq.submit_time >= (current_date - 30  ) and 
lq.username in ('zna_infa1','Infa_NP_Monthly') and lq.state='done' and 
( ( lqa.skew > 0.5 and lqa.rows_actual > 10000000 )  or  
( lqa.io_network_bytes/1024^4 >= 10 and (lqa.io_read_bytes/1024^3 < 100 or lq.rows_inserted < 1000000000 or lq.rows_returned > 0) ) or  
(lq.io_spill_write_bytes/1024^4 >= 10 ) or 
(lq.run_ms/1000 >= 3600 ) 
)
order by lq.submit_time desc 
limit 1000;






	