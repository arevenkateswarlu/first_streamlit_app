select username,a.session_id , client_ip_address , database_name ,submit_time , substring(query_text from 1 for 100)
from sys.log_session a,
sys.log_query b
where a.session_id = b.session_id
and b.error_message not like '%Can not log on with informatica ID%'
and lower(username) like '%infa%'
and client_ip_address not in ('10.147.68.60','10.157.53.58','10.147.163.33','10.147.163.34','10.148.47.49','10.202.76.3','10.148.47.230','10.147.168.173','10.147.68.240','10.147.68.251','10.147.68.252','10.147.68.61','10.147.69.2','10.147.69.49','10.147.163.25')
and lower(database_name) <> 'znawuserdb'
and submit_time between last_day(now() - interval '2 month') + interval '1 day' and last_day(now() - interval '1 month')
and (upper(query_text) not like '%SELECT VERSION()%' AND
     UPPER(QUERY_TEXT) not like 'ANALYZE%'   and
     UPPER(QUERY_TEXT) not like 'DEALLOCATE%' and
     UPPER(QUERY_TEXT) not like 'SHOW%' and
     QUERY_TEXT not like 'select current_database()%' and
     QUERY_TEXT not like 'select current_schema()%' and
     QUERY_TEXT not like 'SELECT current_schema(),session_user%' and
     QUERY_TEXT not like 'select n.nspname, c.relname, a.attname, a.atttypid, t.typname, a.attnum, a.attlen, a.atttypmod, a.attnotnull,%' ) and 
	 QUERY_TEXT not like 'SELECT db.oid,db.* FROM pg_catalog.pg_database%' and
	 QUERY_TEXT not like 'select * from pg_catalog.pg_settings%' and 
	 QUERY_TEXT not like 'select string_agg(word, %	 from pg_catalog%' and 
	 QUERY_TEXT not like 'SELECT typcategory FROM pg_catalog.pg_type%' and 
	 QUERY_TEXT not like 'SELECT t.oid,t.*,c.relkind,format_type%' and 
	 QUERY_TEXT not like 'SELECT * FROM VERSION%' and 
	 QUERY_TEXT not like 'SELECT oid, typname from pg_type%' and 
	 QUERY_TEXT not like 'SELECT n.oid,n.*,d.description FROM pg_catalog.pg_namespace%'
order by 5