from LogGenerate import LogGenerate
from GetConnection import GetConnection
from SqlToDataFrame import SqlToDataFrame
from ReadInputParameters import ReadInputParameters
from tabulate import tabulate


class show_lock_waits:
    def __init__(self,input_parameters):
        self.hostname = input_parameters.host
        self.port = input_parameters.port
        self.username = input_parameters.user
        self.password = input_parameters.password
        if input_parameters.dbname is None:
            self.connect_database = "znawuserdb"
            self.filter_condition = " "
        else:
            self.connect_database = input_parameters.dbname
            self.database = input_parameters.dbname
            self.filter_condition = " and locked_query.database = '" + self.database + "' "
        if input_parameters.table_name is not None:
            if input_parameters.dbname is None:
                print("database name must be provided when tablename is given as input")
                exit(5)
            self.table_name = input_parameters.table_name
            self.filter_condition = self.filter_condition + " and locked_query.table_name = '" + self.table_name + "'"
        if input_parameters.wait_time is not None:
            self.wait_time = input_parameters.wait_time
            self.filter_condition = self.filter_condition + " and lock_wait_minutes >= make_time(0, " + self.wait_time + ", 0) "
            if int(input_parameters.wait_time) >= 60:
                print("Lock wait time monitoring should not exceed 60 minutes")
                exit(6)



    def show_lock_waits(self):
        logging = LogGenerate()
        logger = logging.logger(__name__)
        logger.debug(('Enetered into Show lock waits Method'))
        LockWaitQuery = open(r"sql_queries\LockWaitQuery.sql","r+")
        sqlQuery = LockWaitQuery.read().replace('filter_condition',self.filter_condition)
        connect = GetConnection()
        connection = connect.get_connection(logger,self.hostname, self.port, self.username, self.password, self.connect_database)
        dataFrame = SqlToDataFrame()
        dbSizeDataFrame = dataFrame.load_data_frame(logger,connection,sqlQuery)
        connection.close()
        return dbSizeDataFrame
        #print(tabulate(dbSizeDataFrame, headers = 'keys', tablefmt = 'psql' , showindex= False))


def main():
    """
        Enters here when we call this class"""
    getInputParameters = ReadInputParameters()
    inputParameters = getInputParameters.show_lock_waits_parameters()
    #print(inputParameters)
    lock_waits = show_lock_waits(inputParameters)
    lockWaitDataFrame = lock_waits.show_lock_waits()
    print(tabulate(lockWaitDataFrame, headers='keys', tablefmt='psql', showindex=False))


if __name__ == "__main__":
    main()