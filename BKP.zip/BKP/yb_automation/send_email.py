import smtplib
from email.message import EmailMessage
from email.mime.multipart import MIMEMultipart
from smtplib import SMTPException
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders


class send_email_alert:
    def send_alert(**kwargs):
        for key,value in kwargs.items():
            if key == "sender":
                sender = value
            elif key == "receivers":
                receivers = value
            elif key == "body":
                body = value
            elif key == "subject":
                subject = value
            elif key == "ContentTable":
                data_df = value
            elif key == "Attachment":
                attach_file = value
        msg = MIMEMultipart()
        msg['Subject'] = subject
        msg['To'] = receivers
        msg['From'] = sender
        email_body = """\
                    <html>
                    <head></head>
                    <body>
                    %s
                    """ %(body)
        if 'data_df' in locals():
            email_body = email_body + """
					<br /> 
                    {0}
                    """.format(data_df.to_html(index=False))
        email_body = email_body + """<br /> <br /> Thanks,<br />YB DBA Team."""
        email_body = email_body + """</body> <html>"""
        email_body_html = MIMEText(email_body, 'html')
        #msg.set_content(body)
        msg.attach(email_body_html)
        if 'attach_file' in locals():
            part = MIMEBase('application', "octet-stream")
            part.set_payload(open(attach_file, "rb").read())
            encoders.encode_base64(part)
#            print(attach_file)
            part.add_header('Content-Disposition', "attachment; filename=%s" % attach_file)
            #part.add_header('Content-Disposition', 'attachment; filename="/tmp/userdb_tab_size.xlsx"')
            msg.attach(part)
        try:
            smtpObj = smtplib.SMTP('smtp.zurichna.com',25)
            #smtpObj.send_message(msg.as_string())
            smtpObj.sendmail(msg['From'],msg['To'],msg.as_string())
            print("Successfully sent email")
        except SMTPException:
            print("Error: unable to send email")


# def main():
#     """This class methods should call from other methods by providing the required input parameters"""
#     print("This class should call from other methods by providing input parameter")
#     exit(1)
#
#
# if __name__ == "__main__":
#         main()
