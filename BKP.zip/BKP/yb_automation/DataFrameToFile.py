class DataFrameToFile:
    """Class definition for writing the
        DataFrame data into Excel file"""
    def write_to_file(self,logger,dataFrameObj,fileName):
        try:
            logger.debug('Entered into writeToFile Method with Parameters :')
            #logger.debug('Output Path : %s', outputPath)
            logger.debug('FileName : %s', fileName)
            #dataFrameObj.to_csv("E:\Folder_Share\yb_Automation\output.csv", index=False)
            dataFrameObj.to_excel(fileName, index=False)
        except Exception:
            logger.error('Couldn\'t able to write the Table Size Information to File')
            logger.error('File : %s', fileName)
            print('Couldn\'t able to write the Table Size Information to File')
            print('File : %s', fileName)
            logger.exception('Got an Exception')
            exit(3)

