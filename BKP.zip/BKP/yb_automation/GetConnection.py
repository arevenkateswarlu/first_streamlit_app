import psycopg2 as psycopg2


class GetConnection:
    """Class definition for creating the
        connection to the database by using
        the provided connection parameters"""
    def get_connection(self,logger, hostname, port, username, password, dbname):
        logger.debug('Enetered the getConnection Function with parameters hostname : %s ,port : %s , Database : %s, '
                     'Username : %s, Password : ********', hostname, port, dbname, username)
        try:
            connection = psycopg2.connect(
                host=hostname,
                database=dbname,
                user=username,
                password=password,
                port=port)
            return connection
        except Exception:
            logger.error('connection establishment is failed with below values')
            logger.error('Hostname : ', hostname)
            logger.error('Port :', port)
            logger.error('Database :', dbname)
            logger.error('Username :', username)
            print("connection establishment is failed with below values")
            print('Hostname : ', hostname)
            print('Port :', port)
            print('Database :', dbname)
            print('Username :', username)
            # logger.error(traceback.format_exc())
            logger.exception("Got an Exception")
            exit(1)
