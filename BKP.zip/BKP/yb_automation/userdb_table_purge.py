from DataFrameToFile import DataFrameToFile
from send_email import send_email_alert as send_email
from LogGenerate import LogGenerate
from GetConnection import GetConnection
from SqlToDataFrame import SqlToDataFrame
from get_db_size import Get_DB_Size
from ReadInputParameters import ReadInputParameters
from tabulate import tabulate


class userdb_table_purge:
    def __init__(self,input_parameters):
        self.hostname = input_parameters.host
        self.port = input_parameters.port
        self.username = input_parameters.user
        self.password = input_parameters.password
        self.connect_database = "znawuserdb"
        if input_parameters.retain_interval is not None:
            self.retain_interval = int(input_parameters.retain_interval)
        else:
            self.retain_interval = 60
        self.retain_interval=self.retain_interval+5
        self.filter_condition = " and t.creation_time <= (current_date - " + str(self.retain_interval) + " )"


    def get_userdb_table_list(self):
        logging = LogGenerate()
        logger = logging.logger(__name__)
        logger.debug('Enetered into get_userdb_table_list')
        connect = GetConnection()
        connection = connect.get_connection(logger,self.hostname, self.port, self.username, self.password, self.connect_database)
        #userdb_tab_list_query = open(r"/home/ybloadusr/PYTHON_VENV/python_scripts/sql_queries/UserdbTabList.sql", "r+")
        userdb_tab_list_query = open(r"sql_queries\UserdbTabList.sql", "r+")
        sqlQuery = userdb_tab_list_query.read().replace('filter_condition', self.filter_condition)
        # print(sqlQuery)
        dataFrame = SqlToDataFrame()
        userdb_tab_list_df = dataFrame.load_data_frame(logger,connection,sqlQuery)
        connection.close()
        return userdb_tab_list_df


    def drop_userdb_tables(self,UserdbTabDropListDF):
        logging = LogGenerate()
        logger = logging.logger(__name__)
        logger.debug('Enetered into drop_userdb_tables')
        connect = GetConnection()
        connection = connect.get_connection(logger,self.hostname, self.port, self.username, self.password, self.connect_database)
        connection.autocommit = True
        cursor = connection.cursor()
        droppedTableCount=0
        #print(UserdbTabDropListDF)
        for index,table_info in UserdbTabDropListDF.iterrows():
            drop_command="drop table znawuserdb.dbaall.\"" + table_info['table_name'] + "\";"
            print(drop_command)
            droppedTableCount=droppedTableCount+1
            #cursor.execute(drop_command)
            #print("drop table table_info['table_name'],table_info['creation_time'])
            #print(dbname,tabname,creation_date)
        return droppedTableCount


def main():
    """
        Enters here when we call this class"""
    getInputParameters = ReadInputParameters()
    inputParameters = getInputParameters.userdb_table_purge_parameters()
    #print(inputParameters)
    userdb_tabList = userdb_table_purge(inputParameters)
    UserdbTabListDF = userdb_tabList.get_userdb_table_list()
    droppedTableCount=userdb_tabList.drop_userdb_tables(UserdbTabListDF)
    dropTableCount=len(UserdbTabListDF)
    #print(dropTableCount)
    #print(droppedTableCount)
    if droppedTableCount == dropTableCount:
        email_body="Hi Team,<br /> <br /> ZNAWUSERDB tables created earlier than %s days were dropped succesfully on server %s" % (inputParameters.retain_interval,inputParameters.host)
        email_subject="Dropping of ZNAWUSERDB tables created earlier than %s days on server %s" % (inputParameters.retain_interval,inputParameters.host)
        send_email.send_alert(sender="USZ_ZNA_NZ_DBA@zurichna.com", receivers="v.are-c@zurichna.com", body=email_body,subject=email_subject, ContentTable=UserdbTabListDF)
    else:
        print(UserdbTabListDF)
        email_body="Hi Team,<br /> <br /> Dropping of ZNAWUSERDB tables created earlier than %s days is failed on server %s" % (inputParameters.retain_interval,inputParameters.host)
        email_subject="Dropping of ZNAWUSERDB tables created earlier than %s days on server %s" % (inputParameters.retain_interval,inputParameters.host)
        send_email.send_alert(sender="USZ_ZNA_NZ_DBA@zurichna.com", receivers="v.are-c@zurichna.com", body=email_body,subject=email_subject)
    print(email_body)
    #print(email_subject)
    #print(UserdbTabListDF)
    #email_body = "Hi Team,<br /> <br />ZNAWUSERDB on server %s is consuming more than %s TB." % (inputParameters.host, userdb_size_TB)
    #email_subject = "ZNAWUSERDB on server %s is consuming more than %s TB." % (inputParameters.host, userdb_size_TB)



if __name__ == "__main__":
    main()
