#!/home/ybloadusr/PYTHON_VENV/scripts/python
from LogGenerate import LogGenerate
from GetConnection import GetConnection
from SqlToDataFrame import SqlToDataFrame
from ReadInputParameters import ReadInputParameters
from tabulate import tabulate
import os
import psycopg2.extras as extras
from DataFrameToFile import DataFrameToFile
import pandas as pd


class yb_table_ddl_compare:
    def __init__(self, input_parameters):
        self.src_hostname = input_parameters.shost
        self.port = input_parameters.port
        self.username = input_parameters.user
        self.password = input_parameters.password
        self.tgt_hostname = input_parameters.thost
        self.execution_path = os.getcwd()
        if input_parameters.src_diff_only == "YES":
            self.src_diff_only = "YES"
        else:
            self.src_diff_only = "NO"
        if input_parameters.src_db is None:
            print("Please provide the Source database name")
            exit(1)
        else:
            self.src_database = input_parameters.src_db
        if input_parameters.tgt_db is None:
            print("Please provide the Target database name")
            exit(2)
        else:
            self.tgt_database = input_parameters.tgt_db
        if input_parameters.table_name is None:
            self.src_filter_condition = "  where table_catalog='" + input_parameters.src_db + "' and table_schema='dbaall' "
            self.tgt_filter_condition = "  where table_catalog='" + input_parameters.tgt_db + "' and table_schema='dbaall' "
        else:
            self.table_name = input_parameters.table_name
            self.src_filter_condition = "  where table_catalog='" + input_parameters.src_db + "' and table_schema='dbaall' and table_name ='" + input_parameters.table_name + "' "
            self.tgt_filter_condition = "  where table_catalog='" + input_parameters.tgt_db + "' and table_schema='dbaall' and table_name ='" + input_parameters.table_name + "' "


    def RetrieveColumnDetails(self):
        logging = LogGenerate()
        logger = logging.logger(__name__)
        logger.debug('Enetered into RetrieveColumnDetails Method')
        try:
            connect = GetConnection()
            self.src_connection = connect.get_connection(logger, self.src_hostname, self.port, self.username, self.password,self.src_database)
            self.tgt_connection = connect.get_connection(logger, self.tgt_hostname, self.port, self.username, self.password,self.tgt_database)
            dataFrame = SqlToDataFrame()
            #columnDetailsQuery = "select table_catalog,table_schema,table_name,column_name,data_type,character_maximum_length,numeric_precision,numeric_scale,datetime_precision,is_nullable,case when data_type like 'character%' or data_type like 'timestamp%' then replace(regexp_replace(replace(replace(replace(column_default,'::timestamp without time zone',''),'::character varying(256)',''),'::character varying',''),'(\d)',''),'()','') else column_default end as column_default from information_schema.columns "
            #columnDetailsQuery = "select table_catalog,table_schema,table_name,column_name,data_type,character_maximum_length,numeric_precision,numeric_scale,datetime_precision,is_nullable,case when column_default is null then 'NO' else 'YES' end as column_default from information_schema.columns "
            #columnDetailsQuery = "select table_catalog,table_schema,table_name,column_name,data_type,character_maximum_length,numeric_precision,numeric_scale,datetime_precision,is_nullable,case when data_type='character' and trim(replace(column_default,'''',''))='null' then 'null' when (position('::' in column_default))=0 or column_default is null then column_default else substr(column_default,2,(position('::' in column_default))-3) end as column_default from information_schema.columns "
            columnDetailsQuery = "with first_column_details as (select table_catalog,table_schema,table_name,column_name,data_type,character_maximum_length,numeric_precision,numeric_scale,datetime_precision,is_nullable,case when data_type='character' and trim(replace(column_default,'''',''))='null' then 'null' when (position('::' in column_default))=0 or column_default is null then column_default else substr(column_default,2,(position('::' in column_default))-3) end as column_default,is_updatable from information_schema.columns) select table_catalog,table_schema,table_name,column_name,data_type,character_maximum_length,numeric_precision,numeric_scale,datetime_precision,is_nullable, case when substr(column_default,1,1)='''' and substr(column_default,length(column_default),1)=''''  then trim(substr(column_default,2,length(column_default)-2)) else column_default end as column_default from first_column_details "
            constraintDetailsQuery = "select table_catalog,table_schema,table_name,column_name from information_schema.constraint_column_usage "
            distributionDetailsQuery = "with table_details as (select d.name as table_catalog,s.name as table_schema,t.name as table_name,u.name as owner,t.distribution,t.sort_key,t.distribution_key,t.cluster_keys,t.partition_keys from sys.table t,sys.schema s,sys.database d,sys.user u where t.schema_id=s.schema_id and t.database_id=d.database_id and t.owner_id=u.user_id ) select * from table_details "
            # TableStructureDataFrame = dataFrame.load_data_frame(logger, connection, sqlQuery)
            #src_cursor = self.src_connection.cursor()
            tgt_cursor = self.tgt_connection.cursor()
            srcColumnDetailsDF = dataFrame.load_data_frame(logger,self.src_connection,columnDetailsQuery + self.src_filter_condition + " and is_updatable='YES'")
            tgtColumnDetailsDF = dataFrame.load_data_frame(logger,self.tgt_connection,columnDetailsQuery + self.tgt_filter_condition + " and is_updatable='YES'")
            srcConstraintDetailsDF = dataFrame.load_data_frame(logger,self.src_connection,constraintDetailsQuery + self.src_filter_condition )
            tgtConstraintDetailsDF = dataFrame.load_data_frame(logger,self.tgt_connection,constraintDetailsQuery + self.tgt_filter_condition )
            srcDistributionDetailsDF = dataFrame.load_data_frame(logger,self.src_connection,distributionDetailsQuery + self.src_filter_condition)
            tgtDistributionDetailsDF = dataFrame.load_data_frame(logger,self.tgt_connection,distributionDetailsQuery + self.tgt_filter_condition)
            TemptableColumnDetails = "create temp table src_table_column_details (table_catalog varchar(100),table_schema varchar(20),table_name varchar(128),column_name varchar(128),data_type varchar(50),character_maximum_length varchar(10),numeric_precision varchar(10),numeric_scale varchar(10),datetime_precision varchar(10),is_nullable varchar(10),column_default varchar(500));create temp table tgt_table_column_details (table_catalog varchar(100),table_schema varchar(20),table_name varchar(128),column_name varchar(128),data_type varchar(50),character_maximum_length varchar(10),numeric_precision varchar(10),numeric_scale varchar(10),datetime_precision varchar(10),is_nullable varchar(10),column_default varchar(500));create temp table src_table_constraint_details( table_catalog varchar(100),table_schema varchar(20),table_name varchar(128),column_name varchar(128));create temp table tgt_table_constraint_details( table_catalog varchar(100),table_schema varchar(20),table_name varchar(128),column_name varchar(128));create temp table src_table_distribution_details (table_catalog varchar(100),table_schema varchar(20),table_name varchar(128),owner varchar(30),distribution varchar(50),sort_key varchar(100),distribution_key varchar(100),cluster_keys varchar(256),partition_keys varchar(512));create temp table tgt_table_distribution_details (table_catalog varchar(100),table_schema varchar(20),table_name varchar(128),owner varchar(30),distribution varchar(50),sort_key varchar(100),distribution_key varchar(100),cluster_keys varchar(256),partition_keys varchar(512));create temp table ddl_diff_tables(table_name varchar(128),column_diff varchar(1),constraint_diff varchar(1),distribution_diff varchar(1));"
            tgt_cursor.execute(TemptableColumnDetails)
            records = [tuple(x) for x in srcColumnDetailsDF.to_numpy()]
            columnNames = ','.join(list(srcColumnDetailsDF.columns))
            insertQuery = "INSERT INTO src_table_column_details(%s) VALUES %%s" % (columnNames)
            extras.execute_values(tgt_cursor, insertQuery, records)
            records = [tuple(x) for x in tgtColumnDetailsDF.to_numpy()]
            columnNames = ','.join(list(tgtColumnDetailsDF.columns))
            insertQuery = "INSERT INTO tgt_table_column_details(%s) VALUES %%s" % (columnNames)
            extras.execute_values(tgt_cursor, insertQuery, records)
            records = [tuple(x) for x in srcConstraintDetailsDF.to_numpy()]
            columnNames = ','.join(list(srcConstraintDetailsDF.columns))
            insertQuery = "INSERT INTO src_table_constraint_details(%s) VALUES %%s" % (columnNames)
            extras.execute_values(tgt_cursor, insertQuery, records)
            records = [tuple(x) for x in tgtConstraintDetailsDF.to_numpy()]
            columnNames = ','.join(list(tgtConstraintDetailsDF.columns))
            insertQuery = "INSERT INTO tgt_table_constraint_details(%s) VALUES %%s" % (columnNames)
            extras.execute_values(tgt_cursor, insertQuery, records)
            records = [tuple(x) for x in srcDistributionDetailsDF.to_numpy()]
            columnNames = ','.join(list(srcDistributionDetailsDF.columns))
            insertQuery = "INSERT INTO src_table_distribution_details(%s) VALUES %%s" % (columnNames)
            extras.execute_values(tgt_cursor, insertQuery, records)
            records = [tuple(x) for x in tgtDistributionDetailsDF.to_numpy()]
            columnNames = ','.join(list(tgtDistributionDetailsDF.columns))
            insertQuery = "INSERT INTO tgt_table_distribution_details(%s) VALUES %%s" % (columnNames)
            extras.execute_values(tgt_cursor, insertQuery, records)
            self.tgt_connection.commit()
            if self.src_diff_only == "YES":
                columnDetailsDiffQuery = "with column_diff_details as (select table_name,column_name,data_type,character_maximum_length,numeric_precision,numeric_scale,datetime_precision,is_nullable,column_default,'" + self.src_database + "'  as server_detail  from src_table_column_details except all  select table_name,column_name,data_type,character_maximum_length,numeric_precision,numeric_scale,datetime_precision,is_nullable,column_default,'" + self.src_database + "' as server_detail   from tgt_table_column_details  union all select table_name,column_name,data_type,character_maximum_length,numeric_precision,numeric_scale,datetime_precision,is_nullable,column_default,'" + self.tgt_database + "'  as server_detail  from tgt_table_column_details except all  select table_name,column_name,data_type,character_maximum_length,numeric_precision,numeric_scale,datetime_precision,is_nullable,column_default,'" + self.tgt_database + "' as server_detail  from src_table_column_details  order by table_name,column_name), src_column_details as (select table_name,column_name from column_diff_details where  server_detail='" + self.src_database + "') select c.table_name,c.column_name,c.data_type,c.character_maximum_length,c.numeric_precision,c.numeric_scale,c.datetime_precision,c.is_nullable,c.column_default,c.server_detail from  column_diff_details  c where (c.table_name,c.column_name) in  (select table_name,column_name from src_column_details)  order by c.table_name,c.column_name,c.server_detail"
                constraintDetailsDiffQuery = "with constraint_diff_details as (select table_name,column_name,'" + self.src_database + "' as server_detail from src_table_constraint_details except all  select table_name,column_name,'" + self.src_database + "' as server_detail from tgt_table_constraint_details union all select table_name,column_name,'" + self.tgt_database + "' as server_detail from tgt_table_constraint_details except all  select table_name,column_name,'" + self.tgt_database + "' as server_detail from src_table_constraint_details order by table_name) , src_details as (select distinct table_name,column_name from constraint_diff_details where server_detail='" + self.src_database + "') select table_name,column_name,server_detail from constraint_diff_details where  (table_name,column_name) in (select table_name,column_name from src_details) order by table_name,column_name,server_detail"
                distributionDetailsDiffQuery = "with distribution_diff_details as (select table_name,distribution,sort_key,distribution_key,cluster_keys,partition_keys,'" + self.src_database + "' as server_detail from src_table_distribution_details except all select table_name,distribution,sort_key,distribution_key,cluster_keys,partition_keys,'" + self.src_database + "' as server_detail from tgt_table_distribution_details union all select table_name,distribution,sort_key,distribution_key,cluster_keys,partition_keys,'" + self.tgt_database + "' as server_detail from tgt_table_distribution_details except all select table_name,distribution,sort_key,distribution_key,cluster_keys,partition_keys,'" + self.tgt_database + "' as server_detail from src_table_distribution_details  order by table_name), src_details as (select distinct table_name from distribution_diff_details where server_detail='" + self.src_database + "') select  table_name,distribution,sort_key,distribution_key,cluster_keys,partition_keys,server_detail from distribution_diff_details where  table_name in (select table_name from src_details) order by table_name,server_detail"
                columnDiffPopulateQuery = "insert into ddl_diff_tables(with column_diff_details as (select table_name,column_name,data_type,character_maximum_length,numeric_precision,numeric_scale,datetime_precision,is_nullable,column_default,'" + self.src_database + "'  as server_detail  from src_table_column_details except all  select table_name,column_name,data_type,character_maximum_length,numeric_precision,numeric_scale,datetime_precision,is_nullable,column_default,'" + self.src_database + "' as server_detail   from tgt_table_column_details  union all select table_name,column_name,data_type,character_maximum_length,numeric_precision,numeric_scale,datetime_precision,is_nullable,column_default,'" + self.tgt_database + "'  as server_detail  from tgt_table_column_details except all  select table_name,column_name,data_type,character_maximum_length,numeric_precision,numeric_scale,datetime_precision,is_nullable,column_default,'" + self.tgt_database + "' as server_detail  from src_table_column_details  order by table_name,column_name), src_column_details as (select table_name,column_name from column_diff_details where  server_detail='" + self.src_database + "'), column_details as ( select c.table_name,c.column_name,c.data_type,c.character_maximum_length,c.numeric_precision,c.numeric_scale,c.datetime_precision,c.is_nullable,c.column_default,c.server_detail from  column_diff_details  c where (c.table_name,c.column_name) in  (select table_name,column_name from src_column_details)) select distinct table_name,'Y','N','N' from column_details)"
                constraintDiffPopulateQuery = "insert into ddl_diff_tables(with constraint_diff_details as (select table_name,column_name,'" + self.src_database + "' as server_detail from src_table_constraint_details except all  select table_name,column_name,'" + self.src_database + "' as server_detail from tgt_table_constraint_details union all select table_name,column_name,'" + self.tgt_database + "' as server_detail from tgt_table_constraint_details except all  select table_name,column_name,'" + self.tgt_database + "' as server_detail from src_table_constraint_details order by table_name) , src_details as (select distinct table_name,column_name from constraint_diff_details where server_detail='" + self.src_database + "'), constraint_details as ( select table_name,column_name,server_detail from constraint_diff_details where  (table_name,column_name) in (select table_name,column_name from src_details) ) select distinct table_name,'N','Y','N' from constraint_details )"
                distributionDiffPopulateQuery = "insert into ddl_diff_tables(with distribution_diff_details as (select table_name,distribution,sort_key,distribution_key,cluster_keys,partition_keys,'" + self.src_database + "' as server_detail from src_table_distribution_details except all select table_name,distribution,sort_key,distribution_key,cluster_keys,partition_keys,'" + self.src_database + "' as server_detail from tgt_table_distribution_details union all select table_name,distribution,sort_key,distribution_key,cluster_keys,partition_keys,'" + self.tgt_database + "' as server_detail from tgt_table_distribution_details except all select table_name,distribution,sort_key,distribution_key,cluster_keys,partition_keys,'" + self.tgt_database + "' as server_detail from src_table_distribution_details  order by table_name), src_details as (select distinct table_name from distribution_diff_details where server_detail='" + self.src_database + "'), distribution_details as ( select  table_name,distribution,sort_key,distribution_key,cluster_keys,partition_keys,server_detail from distribution_diff_details where  table_name in (select table_name from src_details) ) select distinct table_name,'N','N','Y' from distribution_details )"
            else:
                columnDetailsDiffQuery = "select table_name,column_name,data_type,character_maximum_length,numeric_precision,numeric_scale,datetime_precision,is_nullable,column_default,'" + self.src_database + "'  as server_detail  from src_table_column_details except all  select table_name,column_name,data_type,character_maximum_length,numeric_precision,numeric_scale,datetime_precision,is_nullable,column_default,'" + self.src_database + "'   as server_detail   from tgt_table_column_details  union all select table_name,column_name,data_type,character_maximum_length,numeric_precision,numeric_scale,datetime_precision,is_nullable,column_default,'" + self.tgt_database + "'  as server_detail  from tgt_table_column_details except all  select table_name,column_name,data_type,character_maximum_length,numeric_precision,numeric_scale,datetime_precision,is_nullable,column_default,'" + self.tgt_database + "' as server_detail  from src_table_column_details  order by table_name,column_name,server_detail "
            ####constraintDetailsDiffQuery = "select table_name,constraint_type,constraint_name,'src_db' as server_detail from src_table_constraint_details except all  select table_name,constraint_type,constraint_name,'src_db' as server_detail from tgt_table_constraint_details union all select table_name,constraint_type,constraint_name,'tgt_db' as server_detail from tgt_table_constraint_details except all  select table_name,constraint_type,constraint_name,'tgt_db' as server_detail from src_table_constraint_details order by table_name,constraint_type"
                constraintDetailsDiffQuery = "select table_name,column_name,'" + self.src_database + "' as server_detail from src_table_constraint_details except all  select table_name,column_name,'" + self.src_database + "' as server_detail from tgt_table_constraint_details union all select table_name,column_name,'" + self.tgt_database + "' as server_detail from tgt_table_constraint_details except all  select table_name,column_name,'" + self.tgt_database + "' as server_detail from src_table_constraint_details order by table_name,server_detail"
                distributionDetailsDiffQuery = "select table_name,distribution,sort_key,distribution_key,cluster_keys,partition_keys,'" + self.src_database + "' as server_detail from src_table_distribution_details except all select table_name,distribution,sort_key,distribution_key,cluster_keys,partition_keys,'" + self.src_database + "' as server_detail from tgt_table_distribution_details union all select table_name,distribution,sort_key,distribution_key,cluster_keys,partition_keys,'" + self.tgt_database + "' as server_detail from tgt_table_distribution_details except all select table_name,distribution,sort_key,distribution_key,cluster_keys,partition_keys,'" + self.tgt_database + "' as server_detail from src_table_distribution_details  order by table_name,server_detail"
                columnDiffPopulateQuery = "insert into ddl_diff_tables(with column_details as (select table_name,column_name,data_type,character_maximum_length,numeric_precision,numeric_scale,datetime_precision,is_nullable,column_default,'" + self.src_database + "'  as server_detail  from src_table_column_details except all  select table_name,column_name,data_type,character_maximum_length,numeric_precision,numeric_scale,datetime_precision,is_nullable,column_default,'" + self.src_database + "' as server_detail   from tgt_table_column_details  union all select table_name,column_name,data_type,character_maximum_length,numeric_precision,numeric_scale,datetime_precision,is_nullable,column_default,'" + self.tgt_database + "'  as server_detail  from tgt_table_column_details except all  select table_name,column_name,data_type,character_maximum_length,numeric_precision,numeric_scale,datetime_precision,is_nullable,column_default,'" + self.tgt_database + "' as server_detail  from src_table_column_details  order by table_name,column_name) select distinct table_name,'Y','N','N' from column_details)"
                constraintDiffPopulateQuery = "insert into ddl_diff_tables(with constraint_details as (select table_name,column_name,'" + self.src_database + "' as server_detail from src_table_constraint_details except all  select table_name,column_name,'" + self.src_database + "' as server_detail from tgt_table_constraint_details union all select table_name,column_name,'" + self.tgt_database + "' as server_detail from tgt_table_constraint_details except all  select table_name,column_name,'" + self.tgt_database + "' as server_detail from src_table_constraint_details order by table_name) select distinct table_name,'N','Y','N' from constraint_details )"
                distributionDiffPopulateQuery = "insert into ddl_diff_tables(with distribution_details as (select table_name,distribution,sort_key,distribution_key,cluster_keys,partition_keys,'" + self.src_database + "' as server_detail from src_table_distribution_details except all select table_name,distribution,sort_key,distribution_key,cluster_keys,partition_keys,'" + self.src_database + "' as server_detail from tgt_table_distribution_details union all select table_name,distribution,sort_key,distribution_key,cluster_keys,partition_keys,'" + self.tgt_database + "' as server_detail from tgt_table_distribution_details except all select table_name,distribution,sort_key,distribution_key,cluster_keys,partition_keys,'" + self.tgt_database + "' as server_detail from src_table_distribution_details  order by table_name) select distinct table_name,'N','N','Y' from distribution_details )"
            tgt_cursor.execute(columnDiffPopulateQuery)
            tgt_cursor.execute(constraintDiffPopulateQuery)
            tgt_cursor.execute(distributionDiffPopulateQuery)
            columnDetailsDiffDF = dataFrame.load_data_frame(logger, self.tgt_connection,columnDetailsDiffQuery)
            constraintDetailsDifDF = dataFrame.load_data_frame(logger, self.tgt_connection,constraintDetailsDiffQuery)
            distributionDetailsDF = dataFrame.load_data_frame(logger, self.tgt_connection,distributionDetailsDiffQuery)
            ddlDiffTablesDF = dataFrame.load_data_frame(logger, self.tgt_connection,"select table_name,max(column_diff) as column_diff,max(constraint_diff) as constraint_diff,max(distribution_diff) as distribution_diff from ddl_diff_tables group by table_name order by table_name asc")
            tableMatchQuery = "select distinct src.table_catalog,src.table_schema,src.table_name,tgt.table_catalog,tgt.table_schema,tgt.table_name,case when src.table_name=tgt.table_name then 'MATCHED' else 'NOT_MATCHED' end as table_diff from src_table_column_details src full outer join tgt_table_column_details tgt on src.table_name = tgt.table_name "
            columnMatchQuery = "select distinct *,case when (src.table_name=tgt.table_name and src.table_schema=tgt.table_schema and src.column_name=tgt.column_name and src.data_type=tgt.data_type and nvl(src.character_maximum_length::varchar(20),'NULL')=nvl(tgt.character_maximum_length::varchar(20),'NULL') and nvl(src.numeric_precision::varchar(20),'NULL')=nvl(tgt.numeric_precision::varchar(20),'NULL') and nvl(src.numeric_scale::varchar(20),'NULL')=nvl(tgt.numeric_scale::varchar(20),'NULL') and nvl(src.datetime_precision::varchar(20),'NULL')=nvl(tgt.datetime_precision::varchar(20),'NULL') and nvl(src.is_nullable::varchar(20),'NULL')=nvl(tgt.is_nullable::varchar(20),'NULL') and nvl(src.column_default,'NULL')=nvl(tgt.column_default,'NULL')) then 'MATCHED' else 'NOT_MATCHED' end as column_diff from src_table_column_details src full outer join tgt_table_column_details tgt on src.table_name = tgt.table_name and src.table_schema=tgt.table_schema and src.column_name=tgt.column_name  where src.table_name not in ( select table_name from src_table_column_details minus select table_name from tgt_table_column_details ) and tgt.table_name not in (select table_name from tgt_table_column_details minus select table_name from src_table_column_details)"
            constraintMatchQuery = "select *,case when (src.table_name=tgt.table_name and src.table_schema=tgt.table_schema and nvl(src.column_name,'NULL')=nvl(tgt.column_name,'NULL') ) then 'MATCHED' else 'NOT_MATCHED' end as constraint_diff from src_table_constraint_details src full outer join tgt_table_constraint_details tgt on src.table_name = tgt.table_name and src.table_schema=tgt.table_schema and src.column_name=tgt.column_name where src.table_name not in ( select table_name from src_table_column_details minus select table_name from tgt_table_column_details ) and tgt.table_name not in (select table_name from tgt_table_column_details minus select table_name from src_table_column_details)"
            distributionMatchQuery = "select *,case when (src.table_name=tgt.table_name and src.table_schema=tgt.table_schema and nvl(src.distribution,'NULL')=nvl(tgt.distribution,'NULL') and  nvl(src.sort_key,'NULL')=nvl(tgt.sort_key,'NULL') and nvl(src.distribution_key,'NULL')=nvl(tgt.distribution_key,'NULL') and nvl(src.cluster_keys,'NULL')=nvl(tgt.cluster_keys,'NULL') and nvl(src.partition_keys,'NULL')=nvl(tgt.partition_keys,'NULL')) then 'MATCHED' else 'NOT_MATCHED' end as distribution_diff from src_table_distribution_details src full outer join tgt_table_distribution_details tgt on src.table_name = tgt.table_name and src.table_schema=tgt.table_schema where src.table_name not in ( select table_name from src_table_column_details minus select table_name from tgt_table_column_details ) and tgt.table_name not in ( select table_name from tgt_table_column_details minus select table_name from src_table_column_details)"
            tableMatchDetailsDF = dataFrame.load_data_frame(logger, self.tgt_connection, tableMatchQuery)
            columnMatchDetailsDF = dataFrame.load_data_frame(logger, self.tgt_connection, columnMatchQuery)
            constraintMatchDetailsDF = dataFrame.load_data_frame(logger, self.tgt_connection, constraintMatchQuery)
            distributionMatchDetailsDF = dataFrame.load_data_frame(logger, self.tgt_connection, distributionMatchQuery)
            with pd.ExcelWriter("E:\Folder_Share\yb_Automation\\" + self.tgt_database + "_table_ddl_compare.xlsx") as writer:
                ddlDiffTablesDF.to_excel(writer, index=False, sheet_name='ddl_diff_tables')
                tableMatchDetailsDF.to_excel(writer, index=False, sheet_name='tables_compare')
                columnMatchDetailsDF.to_excel(writer, index=False, sheet_name='Columns_Compare')
                constraintMatchDetailsDF.to_excel(writer, index=False, sheet_name='Constraints_Compare')
                distributionMatchDetailsDF.to_excel(writer, index=False, sheet_name='Distribution_Compare')
            if len(columnDetailsDiffDF) == 0 and len(constraintDetailsDifDF) == 0 and len(distributionDetailsDF) == 0:
                print("there is no DDL mismatch for the provided input Source and Target objects")
            else:
                #print(tabulate(columnDetailsDiffDF, headers='keys', tablefmt='psql', showindex=False))
                #print(tabulate(constraintDetailsDifDF, headers='keys', tablefmt='psql', showindex=False))
                #print(tabulate(distributionDetailsDF, headers='keys', tablefmt='psql', showindex=False))
                print(tabulate(ddlDiffTablesDF, headers='keys', tablefmt='psql', showindex=False))
               #dataFramToFile = DataFrameToFile()
                #dataFramToFile.write_to_file(logger, columnDetailsDiffDF, self.tgt_database + "_table_columns.xlsx")
                #dataFramToFile.write_to_file(logger, constraintDetailsDifDF, self.tgt_database + "_Constraint_details.xlsx")
                #dataFramToFile.write_to_file(logger, distributionDetailsDF, self.tgt_database + "_Distribution_Column_details.xlsx")
        except Exception:
            self.tgt_connection.close()
            self.src_connection.close()
            tgt_cursor.close()
            logger.exception("Got exception in RetrieveColumnDetails of yb_table_ddl_compare class")
            print("Caught exception while RetrieveColumnDetails of yb_table_ddl_compare class")
            print(Exception.with_traceback())
            exit(1)


def main():
    # print("Header or default or direct run of the script TablesSize")
    getInputParameters = ReadInputParameters()
    inputParameters = getInputParameters.get_Table_ddl_compare_parameters()
    TableDDLCompareObj = yb_table_ddl_compare(inputParameters)
    TableDDLCompareObj.RetrieveColumnDetails()


if __name__ == "__main__":
    main()
