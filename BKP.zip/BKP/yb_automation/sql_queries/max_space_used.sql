set enable_alternative_round to off;
select round(max((used_bytes*100.00)/total_bytes),2) as max_used from sys.storage ;