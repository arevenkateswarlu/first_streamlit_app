with today as (
select 
table_catalog as db_name,
table_name,
distribution,
case when sort_key is null then ' ' else sort_key end as sort_key,
case when distribution_key is null then ' ' else distribution_key end as distribution_key,
case when cluster_keys is null then ' ' else cluster_keys end as cluster_keys,
case when partition_keys is null then ' ' else partition_keys end as partition_keys,
region
--,extracted_dt 
from znaw_term.dbaall.tab_distr_details 
where extracted_dt=(select max(extracted_dt) from znaw_term.dbaall.tab_distr_details ) and db_name not in ('znawuserdb') and (table_name not like 'attrep_change%' and table_name not like 'pm_v%' )
),
yesterday as (
select 
table_catalog as db_name,
table_name,
distribution,
case when sort_key is null then ' ' else sort_key end as sort_key,
case when distribution_key is null then ' ' else distribution_key end as distribution_key,
case when cluster_keys is null then ' ' else cluster_keys end as cluster_keys,
case when partition_keys is null then ' ' else partition_keys end as partition_keys,
region
--,extracted_dt 
from znaw_term.dbaall.tab_distr_details 
where extracted_dt=(select max(extracted_dt) from znaw_term.dbaall.tab_distr_details where extracted_dt<(select max(extracted_dt) from znaw_term.dbaall.tab_distr_details)) and db_name not in ('znawuserdb') and (table_name not like 'attrep_change%' and table_name not like 'pm_v%' ) 
)
,dropped_distr as (
select 
yesterday.* ,'DROPPED' as change
from 
yesterday left outer join today on yesterday.db_name=today.db_name and yesterday.table_name=today.table_name and yesterday.distribution=today.distribution and yesterday.sort_key=today.sort_key and yesterday.distribution_key=today.distribution_key and yesterday.cluster_keys=today.cluster_keys and yesterday.partition_keys=today.partition_keys and yesterday.region=today.region
where 
(yesterday.db_name,yesterday.table_name,yesterday.region)  not in  (select today.db_name,today.table_name,today.region from today) and 
  (today.db_name is null  or today.table_name is null or today.distribution is null or today.sort_key is null or today.distribution_key is null or today.cluster_keys is null or today.partition_keys is null or today.region is null)
)
,added_distr as (
select 
today.* ,'ADDED' as change
from 
yesterday right outer join today on yesterday.db_name=today.db_name and yesterday.table_name=today.table_name and yesterday.distribution=today.distribution and yesterday.sort_key=today.sort_key and yesterday.distribution_key=today.distribution_key and yesterday.cluster_keys=today.cluster_keys and yesterday.partition_keys=today.partition_keys and yesterday.region=today.region
where 
 (today.db_name,today.table_name,today.region) not in  (select yesterday.db_name,yesterday.table_name,yesterday.region from yesterday) and 
  (yesterday.db_name is null  or yesterday.table_name is null or yesterday.distribution is null or yesterday.sort_key is null or yesterday.distribution_key is null or yesterday.cluster_keys is null or yesterday.partition_keys is null or yesterday.region is null)
)
,modified_distr as (
select 
today.* ,'MODIFIED' as change
from 
yesterday right outer join today on yesterday.db_name=today.db_name and yesterday.table_name=today.table_name and yesterday.distribution=today.distribution and yesterday.sort_key=today.sort_key and yesterday.distribution_key=today.distribution_key and yesterday.cluster_keys=today.cluster_keys and yesterday.partition_keys=today.partition_keys and yesterday.region=today.region
where 
 (today.db_name,today.table_name,today.region)  in  (select yesterday.db_name,yesterday.table_name,yesterday.region from yesterday) and 
  (yesterday.db_name is null  or yesterday.table_name is null or yesterday.distribution is null or yesterday.sort_key is null or yesterday.distribution_key is null or yesterday.cluster_keys is null or yesterday.partition_keys is null or yesterday.region is null)
--union 
--select 
--yesterday.* ,'MODIFIED'
--from 
--yesterday left outer join today on yesterday.db_name=today.db_name and yesterday.table_name=today.table_name and yesterday.distribution=today.distribution and yesterday.sort_key=today.sort_key and yesterday.distribution_key=today.distribution_key and yesterday.cluster_keys=today.cluster_keys and yesterday.partition_keys=today.partition_keys and yesterday.region=today.region
--where 
--(yesterday.db_name,yesterday.table_name,yesterday.region) in  (select today.db_name,today.table_name,today.region from today) and 
--  (today.db_name is null  or today.table_name is null or today.distribution is null or today.sort_key is null or today.distribution_key is null or today.cluster_keys is null or today.partition_keys is null or today.region is null)
--  
  )
select * from (
select * from modified_distr
union 
select * from dropped_distr
union 
select * from added_distr
)A 
where region='PROD' 
order by db_name,table_name
--limit 100
;