with temp as (SELECT distinct
tbl.name AS table_name
, (SELECT description FROM pg_description WHERE objoid = tbl.table_id AND  objsubid = 0  AND  classoid = 1259)  AS  table_comment
 FROM  sys.database  db
 INNER   JOIN  sys.table  tbl  ON  db.database_id = tbl.database_id
 INNER   JOIN  sys.column  col  ON  col.table_id = tbl.table_id
 WHERE
 db.name not in ('yellowbrick')
--## db.name = '${dbname}'
---## AND  tbl.name  = '${tabname}'
filter_condition
)
select table_name,table_comment from temp where table_comment is not null 
;