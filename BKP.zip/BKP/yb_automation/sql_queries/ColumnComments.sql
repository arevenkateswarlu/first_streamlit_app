with temp as (SELECT
tbl.name AS table_name,col.name  AS  column_name
, ( SELECT  description  FROM  pg_description  WHERE  objoid = tbl.table_id  AND  objsubid = col.column_id)  AS  column_comment
 FROM  sys. database  db
 INNER   JOIN  sys. table  tbl  ON  db.database_id = tbl.database_id
 INNER   JOIN  sys. column  col  ON  col.table_id = tbl.table_id
 WHERE
  db.name not in ('yellowbrick')
--## db.name = '${dbname}'
--## AND  tbl. name  = '${tabname}'
 filter_condition
 )
 select table_name,column_name,column_comment from temp  where column_comment is not null 
 ;