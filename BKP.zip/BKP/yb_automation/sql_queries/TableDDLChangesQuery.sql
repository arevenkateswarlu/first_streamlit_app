with today as (
select 
db_name,
rel_name,
col_name,
col_type,
nullable,
region
--,extracted_dt 
from znaw_term.dbaall.column_details 
where extracted_dt=(select max(extracted_dt) from znaw_term.dbaall.column_details ) and db_name not in ('znawuserdb') and (rel_name not like 'attrep_change%' and rel_name not like 'pm_v%' )
),
yesterday as (
select 
db_name,
rel_name,
col_name,
col_type,
nullable,
region
--,extracted_dt 
from znaw_term.dbaall.column_details 
where extracted_dt=(select max(extracted_dt) from znaw_term.dbaall.column_details where extracted_dt<(select max(extracted_dt) from znaw_term.dbaall.column_details)) and db_name not in ('znawuserdb') and (rel_name not like 'attrep_change%' and rel_name not like 'pm_v%' ) 
)
,dropped_columns as (
select 
yesterday.* ,'DROPPED' as change
from 
yesterday left outer join today on yesterday.db_name=today.db_name and yesterday.rel_name=today.rel_name and yesterday.col_name=today.col_name and yesterday.col_type=today.col_type and yesterday.nullable=today.nullable and yesterday.region=today.region
where 
(yesterday.db_name,yesterday.rel_name,yesterday.col_name,yesterday.region)  not in  (select today.db_name,today.rel_name,today.col_name,today.region from today) and 
  (today.db_name is null  or today.rel_name is null or today.col_name is null or today.col_type is null or today.nullable is null or today.region is null)
)
,added_columns as (
select 
today.* ,'ADDED' as change
from 
yesterday right outer join today on yesterday.db_name=today.db_name and yesterday.rel_name=today.rel_name and yesterday.col_name=today.col_name and yesterday.col_type=today.col_type and yesterday.nullable=today.nullable and yesterday.region=today.region
where 
 (today.db_name,today.rel_name,today.col_name,today.region) not in  (select yesterday.db_name,yesterday.rel_name,yesterday.col_name,yesterday.region from yesterday) and 
  (yesterday.db_name is null  or yesterday.rel_name is null or yesterday.col_name is null or yesterday.col_type is null or yesterday.nullable is null or yesterday.region is null)
)
,modified_columns as (
select 
today.* ,'MODIFIED' as change
from 
yesterday right outer join today on yesterday.db_name=today.db_name and yesterday.rel_name=today.rel_name and yesterday.col_name=today.col_name and yesterday.col_type=today.col_type and yesterday.nullable=today.nullable and yesterday.region=today.region
where 
 (today.db_name,today.rel_name,today.col_name,today.region)  in  (select yesterday.db_name,yesterday.rel_name,yesterday.col_name,yesterday.region from yesterday) and 
  (yesterday.db_name is null  or yesterday.rel_name is null or yesterday.col_name is null or yesterday.col_type is null or yesterday.nullable is null or yesterday.region is null)
--union 
--select 
--yesterday.* ,'MODIFIED'
--from 
--yesterday left outer join today on yesterday.db_name=today.db_name and yesterday.rel_name=today.rel_name and yesterday.col_name=today.col_name and yesterday.col_type=today.col_type and yesterday.nullable=today.nullable and yesterday.region=today.region
--where 
--(yesterday.db_name,yesterday.rel_name,yesterday.col_name,yesterday.region) in  (select today.db_name,today.rel_name,today.col_name,today.region from today) and 
--  (today.db_name is null  or today.rel_name is null or today.col_name is null or today.col_type is null or today.nullable is null or today.region is null)
  
  )
--select change,region,count(*) from (
select * from (
 select * from modified_columns
union 
select * from added_columns
union 
select * from dropped_columns
)A where region='PROD'
order by change asc,db_name,rel_name,col_name
--)A group by change,region
--limit 500
;