set search_path to public;
SELECT used_pct FROM sysviews.public.storage_p() ;