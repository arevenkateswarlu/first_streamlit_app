select d.name as database_name,s.name as schema_name,t.name as table_name, (avg(t.compressed_bytes)/(1024.0*1024.0*1024.0)) as Compressed_space_GB,u.name as owner,t.creation_time AT time ZONE 'GMT' as creation_time from sys.table t,sys.schema s,sys.database d,sys.user u 
where 
t.schema_id=s.schema_id 
and t.database_id=d.database_id 
and t.owner_id=u.user_id 
and d.name='znawuserdb' 
and s.name='dbaall'
 filter_condition 
  group by t.name,s.name,d.name,u.name,t.creation_time order by t.creation_time  asc;