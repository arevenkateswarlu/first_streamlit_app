import pandas
import psycopg2.extras as extras


class SqlToDataFrame:
    """Class for executing the provided SQL query
        and load the data into DataFrame"""
    def load_data_frame(self,logger,connection,sqlQuery):
        #logger = loggingModule().logger()
        logger.debug('Entered into loadDataFrame Method with parameters ')
        logger.debug('SQLQUERY :%s', sqlQuery)
        logger.debug('And connection <object>')
        try:
            #sql_query = "select * from dbaall.prst_fix limit 10"
            results = pandas.read_sql_query(sqlQuery, connection)
            # tuples = [tuple(x) for x in results.to_numpy()]
            # cols = ','.join(list(results.columns))
            # # # SQL query to execute
            # table="dbaall.table_size"
            # query  = "INSERT INTO %s(%s) VALUES %%s" % (table, cols)
            # cursor = connection.cursor()
            #
            # extras.execute_values(cursor, query, tuples)
            # connection.commit()
            return results
        except Exception:
            logger.error('Error while executing the query ')
            logger.error('SQL_Query : %s', sqlQuery)
            print('Error while executing the query ')
            print('SQL_Query : %s', sqlQuery)
            #logger.error(traceback.format_exc())
            logger.exception("Got an Exception")
            exit(2)
