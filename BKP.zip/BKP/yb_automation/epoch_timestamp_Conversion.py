from datetime import datetime,timedelta
from pytz import timezone
import pytz

format = "%Y-%m-%d %H:%M:%S %Z%z"

#print('the supported timezones by the pytz module:',pytz.all_timezones, '\n')
# Current time in UTC
#now_utc = datetime.now(timezone('US/Central'))
#print(now_utc.strftime(format))
#epoch = datetime(1601, 1, 1, tzinfo=timezone('US/Central'))
#cookie_datetime = epoch + timedelta(microseconds=16628605235754850)
#print(cookie_datetime)
epochtime = 1662860523575485
datetime1 = datetime.fromtimestamp(1662860523)
print(datetime1)