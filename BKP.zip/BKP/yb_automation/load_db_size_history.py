import pandas as pd
from GetConnection import GetConnection
from LogGenerate import LogGenerate
import psycopg2.extras as extras


logging = LogGenerate()
logger = logging.logger(__name__)
DF = pd.read_csv('C:\\Users\\v.are\\Downloads\\db_size_history.csv', index_col=None)
##print(DF)
#DF_Pivot = DF.pivot(index ='db_name',columns='cmpr_gb', values ='cmpr_gb')
DF_unpivot = DF.melt(id_vars=['db_name'], var_name='date', value_name='cmpr_gb').sort_values('date')
#print(DF_unpivot)
records = [tuple(x) for x in DF_unpivot.to_numpy()]
columnNames = ','.join(list(DF_unpivot.columns))
tabname = "znawuserdb.dbaall.db_size_history"
columns = "db_name,trackdate,cmpr_gb"
print(columnNames)
insertQuery = "INSERT INTO %s(%s) VALUES %%s" % (tabname,columns)
connect = GetConnection()
connection = connect.get_connection(logger, "10.154.24.10", 5432, "dbaall", "P@ssw0rd","znawuserdb")
cursor = connection.cursor()
print(insertQuery)
extras.execute_values(cursor, insertQuery, records)
connection.commit()
            #print(dbSizeDF.transpose())