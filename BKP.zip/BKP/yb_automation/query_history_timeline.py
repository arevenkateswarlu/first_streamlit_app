from GetConnection import GetConnection
from SqlToDataFrame import SqlToDataFrame
from LogGenerate import LogGenerate
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import matplotlib.ticker as ticker
import plotly.express as px

logging = LogGenerate()
logger = logging.logger(__name__)
connect = GetConnection()
sqlQuery="select query_id,type,state,username,submit_time,done_time,pool_id from sys.log_query " \
         "where pool_id is not null and  submit_time >= '2023-02-15 04:00:01' and submit_time <= '2023-02-15 05:00:00' order by query_id,username,type"
hostname="10.154.24.5"
port=5432
username="uszvya5"
password="P@ssw0rd_2021"
connection = connect.get_connection(logger, hostname, port, username, password, 'znawuserdb')
dataFrame = SqlToDataFrame()
query_history_df = dataFrame.load_data_frame(logger, connection, sqlQuery)
#print(query_history_df)


sns.set_style('darkgrid')
sns.set(rc={'figure.figsize':(14,8)})

ax = sns.lineplot(data=query_history_df, x ='submit_time', y = 'query_id',
                  legend='full', lw=3)

ax.xaxis.set_major_locator(ticker.MultipleLocator(4))
plt.legend(bbox_to_anchor=(1, 1))
plt.ylabel('query_id')
plt.xlabel('submit_time')
plt.show()

"""
source=query_history_df
source['start'] = pd.to_datetime(source['submit_time'])
source['end'] = pd.to_datetime(source['done_time'])

fig = px.timeline(source.sort_values('start_time'),
                  x_start="start_time",
                  x_end="done_time",
                  y="pool_id",
                  text="query_id",
                  color_discrete_sequence=["tan"])
fig.show()"""