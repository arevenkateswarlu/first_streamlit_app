from LogGenerate import LogGenerate
from GetConnection import GetConnection
from SqlToDataFrame import SqlToDataFrame
from ReadInputParameters import ReadInputParameters
from get_comments import get_comments
import os


class yb_table_backup_userdb:
    def __init__(self, input_parameters):
        self.hostname = input_parameters.host
        self.port = input_parameters.port
        self.username = input_parameters.user
        self.password = input_parameters.password
        self.execution_path = os.getcwd()
        self.SourceTableSizeGB = 1024
        if input_parameters.dbname is None:
            print("Please provide the database name")
            exit(1)
        else:
            self.connect_database = input_parameters.dbname
            self.database = input_parameters.dbname
        if input_parameters.table_name is None:
            print("provide the Table name along with tablename ", input_parameters.table_name)
            exit(3)
        else:
            self.tablename = input_parameters.table_name
        if input_parameters.dbname is not None:
            self.filter_condition = " and db.name = '" + self.database + "'"
            if input_parameters.table_name is not None:
                self.filter_condition = self.filter_condition + " and tbl.name = '" + self.tablename + "'"
                self.TableSizeFilter = " and d.name = '" + self.database + "' and t.name = '" + self.tablename + "'"
        else:
            self.filter_condition = ""
        if input_parameters.bkp_table_name is not None:
            self.target_database = 'znawuserdb'
            self.target_bkp_table = input_parameters.bkp_table_name
            self.TargetTableFiler = " and table_catalog = 'znawuserdb' and table_name ='" + self.target_bkp_table  + "' "
        else:
            print("Provide the target tablename for taking the backup in znawuserdb")
            exit(4)

    def RetrieveTableStructure(self):
        logging = LogGenerate()
        logger = logging.logger(__name__)
        logger.debug(('Enetered into Table Structure retrieval Method'))
        try:
            connect = GetConnection()
            connection = connect.get_connection(logger, self.hostname, self.port, self.username, self.password,
                                                self.connect_database)
            sqlQuery = "describe " + self.tablename + " only ddl "
            # TableStructureDataFrame = dataFrame.load_data_frame(logger, connection, sqlQuery)
            cursor = connection.cursor()
            cursor.execute(sqlQuery)
            target_table_ddl_file = open(os.path.join(self.execution_path, self.target_bkp_table + ".ddl" ), "w")
            for each_line in cursor.fetchall():
                if len(self.CostraintName) != 0:
                    target_table_ddl_file.writelines(str(each_line[0]).replace("CREATE TABLE " + self.tablename,"CREATE TABLE " + self.target_database + ".dbaall." + self.target_bkp_table).replace(self.CostraintName[0][0],self.NewConstraintName))
                else:
                    target_table_ddl_file.writelines(str(each_line[0]).replace("CREATE TABLE " + self.tablename,"CREATE TABLE " + self.target_database + ".dbaall." + self.target_bkp_table))
                target_table_ddl_file.write("\n")
            target_table_ddl_file.close()
            cursor.close()
            connection.close()
        except Exception:
            logger.exception("Got exception in RetrieveTableStructure of yb_table_backup_userdb class")
            print("Caught exception while extracting the table DDL,so exiting the backup process")
            print(Exception.with_traceback())
            exit(1)


    def RetrieveTablePrimaryKey(self):
        logging = LogGenerate()
        logger = logging.logger(__name__)
        logger.debug(('Enetered into RetrieveTablePrimaryKey retrieval Method'))
        try:
            connect = GetConnection()
            connection = connect.get_connection(logger, self.hostname, self.port, self.username, self.password,
                                                self.connect_database)
            ConstraintNameSql = "select constraint_name from information_schema.table_constraints where constraint_type='PRIMARY KEY' and table_schema='dbaall' and constraint_catalog='" + self.database + "' and table_name='" + self.tablename + "'"
            target_connection = connect.get_connection(logger, self.hostname, self.port, self.username, self.password,
                                                self.target_database)
            SelectUnique = "select nextval('znawuserdb.dbaall.table_primarykey_step_entry')"
            # TableStructureDataFrame = dataFrame.load_data_frame(logger, connection, sqlQuery)
            cursor = connection.cursor()
            cursor.execute(ConstraintNameSql)
            self.CostraintName = cursor.fetchall()
            if len(self.CostraintName)!=0:
                UniqueCursor = target_connection.cursor()
                UniqueCursor.execute(SelectUnique)
                UniqueValue = UniqueCursor.fetchall()
                #print(CostraintName[0][0])
                #print(UniqueValue[0][0])
                self.NewConstraintName = self.CostraintName[0][0] + str(UniqueValue[0][0])
                #print(self.NewConstraintName)
            cursor.close()
            connection.close()
        except Exception:
            logger.exception("Got exception in RetrieveTablePrimaryKey of yb_table_backup_userdb class")
            print("Caught exception while gathering Primary Key details,so exiting the backup process")
            print(Exception.with_traceback())
            exit(1)


    def GetComments(self,InputParameters):
        logging = LogGenerate()
        logger = logging.logger(__name__)
        logger.debug(('Enetered into GetComments retrieval Method'))
        object_comments = get_comments(InputParameters)
        CommentsList = object_comments.RetrieveComments()
        target_table_ddl_file = open(os.path.join(self.execution_path, self.target_bkp_table + ".ddl"), "a")
        for i in range(0, len(CommentsList)):
            target_table_ddl_file.writelines(CommentsList[i].replace("comment on table " + self.tablename,"comment on table " + self.target_bkp_table).replace("comment on column " + self.tablename,"comment on column " + self.target_bkp_table))
            target_table_ddl_file.write("\n")
            #print(CommentsList[i])


    def GetSourceTableSize(self):
        logging = LogGenerate()
        logger = logging.logger(__name__)
        logger.debug(('Enetered into tablesSize Method'))
        tableSizeQueryFile = open(r"sql_queries\TableSizeQuery.sql","r+")
        sqlQuery = tableSizeQueryFile.read().replace('filter_condition',self.TableSizeFilter)
        connect = GetConnection()
        connection = connect.get_connection(logger,self.hostname, self.port, self.username, self.password, self.connect_database)
        dataFrame = SqlToDataFrame()
        tableSizeDataFrame = dataFrame.load_data_frame(logger,connection,sqlQuery)
        if len(tableSizeDataFrame.index) == 0:
            print("Source Table " + self.database + ".dbaall." + self.tablename + " is not existed,so exiting the backup process")
            exit(5)
        else:
            self.SourceTableSizeGB=tableSizeDataFrame.compressed_space_gb[0]
            #print(SourceTableSizeGB)


    def CheckTargetTableStatus(self):
        logging = LogGenerate()
        logger = logging.logger(__name__)
        logger.debug(('Enetered into CheckTargetTableStatus Method'))
        try:
            tableSizeQueryFile = open(r"sql_queries\CheckTableStatus.sql", "r+")
            sqlQuery = tableSizeQueryFile.read().replace('filter_condition', self.TargetTableFiler)
            connect = GetConnection()
            connection = connect.get_connection(logger, self.hostname, self.port, self.username, self.password,
                                            self.target_database)
            dataFrame = SqlToDataFrame()
            tableSizeDataFrame = dataFrame.load_data_frame(logger, connection, sqlQuery)
            if len(tableSizeDataFrame.index) != 0:
                print(
                    "Target backup Table " + self.target_database + ".dbaall." + self.target_bkp_table + " is already existed,so exiting the backup process")
                exit(5)
        except Exception:
            logger.exception("Got exception in CheckTargetTableStatus of yb_table_backup_userdb class")
            print("Caught exception while checking the Target table ,so exiting the backup process")
            print(Exception.with_traceback())
            exit(1)


    def CreateTargetTable(self):
        logging = LogGenerate()
        logger = logging.logger(__name__)
        logger.debug(('Enetered into CheckTargetTableStatus Method'))
        try:
            target_table_ddl_file = os.path.join(self.execution_path, self.target_bkp_table + ".ddl")
            CreateTableQuery = open(target_table_ddl_file, 'r')
            connect = GetConnection()
            connection = connect.get_connection(logger, self.hostname, self.port, self.username, self.password,
                                                self.target_database)
            cursor = connection.cursor()
            #print(CreateTableQuery.read())
            #logger.info(CreateTableQuery.read())
            cursor.execute(CreateTableQuery.read())
            cursor.close()
            connection.commit()
            connection.close()
            CreateTableQuery.close()
            logger.info("Target Table " + self.target_database + ".dbaall." + self.target_bkp_table + " creation is completed succefully")
            target_table_out_file = open(os.path.join(self.execution_path, self.target_bkp_table + ".ddl.out"), "a")
            target_table_out_file.writelines("Target Table " + self.target_database + ".dbaall." + self.target_bkp_table + " creation is completed succefully \n")
            target_table_out_file.close()
        except Exception:
            logger.exception("Got exception in CreateTargetTable of yb_table_backup_userdb class")
            print("Caught exception while Creating the Target table ,so exiting the backup process")
            #print(Exception.with_traceback())
            exit(1)


    def LoadTargetTable(self):
        logging = LogGenerate()
        logger = logging.logger(__name__)
        logger.debug(('Enetered into LoadTargetTable Method'))
        try:
            LoadTargetTableCommand = "insert into " + self.target_database + ".dbaall." + self.target_bkp_table + " ( select * from " + self.database + ".dbaall." + self.tablename + " )"
            connect = GetConnection()
            connection = connect.get_connection(logger, self.hostname, self.port, self.username, self.password,
                                                self.target_database)
            cursor = connection.cursor()
            #print(CreateTableQuery.read())
            cursor.execute(LoadTargetTableCommand)
            logger.info("Loading Table " + self.target_database + ".dbaall." + self.target_bkp_table + " is completed ")
            cursor.close()
            connection.commit()
            connection.close()
        except Exception:
            logger.exception("Got exception in LoadTargetTable of yb_table_backup_userdb class")
            print("Caught exception while Loading the Target table ,so exiting the backup process")
            #print(Exception.with_traceback())
            exit(1)


    def CompareTargetTableCount(self):
        logging = LogGenerate()
        logger = logging.logger(__name__)
        logger.debug(('Enetered into CompareTargetTableCount Method'))
        try:
            SourceTableRowCountSql = "select count(*) from " + self.database + ".dbaall." + self.tablename
            TargetTableRowCountSql = "select count(*) from " + self.target_database + ".dbaall." + self.target_bkp_table
            connect = GetConnection()
            connection = connect.get_connection(logger, self.hostname, self.port, self.username, self.password,
                                                self.target_database)
            cursor = connection.cursor()
            cursor.execute(SourceTableRowCountSql)
            SourceTableRowCount = cursor.fetchall()
            cursor.execute(TargetTableRowCountSql)
            TargetTableRowCount = cursor.fetchall()
            target_table_out_file = open(os.path.join(self.execution_path, self.target_bkp_table + ".ddl.out"), "a")
            if SourceTableRowCount[0][0] == TargetTableRowCount[0][0]:
                print("Table backup " + self.target_database + ".dbaall." + self.target_bkp_table + " is completed successfully")
                target_table_out_file.writelines("Source_Table : " + self.database + ".dbaall." + self.tablename + " Source_Table_Row_Count: " + str(SourceTableRowCount[0][0]) + " \n")
                target_table_out_file.writelines("Target_Table : " + self.target_database + ".dbaall." + self.target_bkp_table + " Target_Table_Row_Count: " + str(TargetTableRowCount[0][0]) + " \n")
                target_table_out_file.writelines("Table backup " + self.target_database + ".dbaall." + self.target_bkp_table + " is completed successfully \n")
                logger.info("Table backup " + self.target_database + ".dbaall." + self.target_bkp_table + " is completed successfully")
                logger.info("Source_Table : " + self.database + ".dbaall." + self.tablename + " Source_Table_Row_Count: " + str(SourceTableRowCount[0][0]))
                logger.info("Target_Table : " + self.target_database + ".dbaall." + self.target_bkp_table + " Target_Table_Row_Count: " + str(TargetTableRowCount[0][0]))
            else:
                logger.info("Table backup " + self.target_database + ".dbaall." + self.target_bkp_table + " is Failed")
                target_table_out_file.writelines("Table backup " + self.target_database + ".dbaall." + self.target_bkp_table + " is Failed \n")
                print("Table backup " + self.target_database + ".dbaall." + self.target_bkp_table + " is Failed")
            target_table_out_file.close()
            cursor.close()
            connection.commit()
            connection.close()
        except Exception:
            logger.exception("Got exception in CompareTargetTableCount of yb_table_backup_userdb class")
            print("Caught exception while comparing the table row count,so exiting the backup process")
            #print(Exception.with_traceback())
            exit(1)


def main():
    # print("Header or default or direct run of the script TablesSize")
    getInputParameters = ReadInputParameters()
    inputParameters = getInputParameters.get_Table_bkp_userdb_parameters()
    TableStructureObj = yb_table_backup_userdb(inputParameters)
    TableStructureObj.CheckTargetTableStatus()
    TableStructureObj.GetSourceTableSize()
    TableStructureObj.RetrieveTablePrimaryKey()
    TableStructureObj.RetrieveTableStructure()
    TableStructureObj.GetComments(inputParameters)
    TableStructureObj.CreateTargetTable()
    TableStructureObj.LoadTargetTable()
    TableStructureObj.CompareTargetTableCount()


if __name__ == "__main__":
    main()
