import db_connect
import execute_query
import traceback
import send_alert


def get_table_hard_limit_sms(dbname,host,port,user,password):
    try:
        db_connection = db_connect.get_connection(dbname,host,port,user,password)
        tab_hard_limit_sms_query = "with temp as (SELECT SUBSTR(t.TABSCHEMA,1,18) TABSCHEMA, SUBSTR(t.TABNAME,1,30) TABNAME,t.DATA_PARTITION_ID, dec((SUM(t.DATA_OBJECT_P_SIZE)+SUM(t.INDEX_OBJECT_P_SIZE)+SUM(t.LONG_OBJECT_P_SIZE) +SUM(t.LOB_OBJECT_P_SIZE) +SUM(t.XML_OBJECT_P_SIZE))/(1024.0*1024.0),9,2)   TOTALSIZE,p.TBSPACEID,t.DBPARTITIONNUM  FROM SYSIBMADM.ADMINTABINFO t,SYSCAT.DATAPARTITIONS p where t.tabname=p.tabname and t.tabschema=p.tabschema and t.DATA_PARTITION_ID=p.DATAPARTITIONID GROUP BY t.TABSCHEMA, t.TABNAME,t.DATA_PARTITION_ID,t.DBPARTITIONNUM,p.TBSPACEID order by totalsize desc with ur) , temp1 as ( select t.TABSCHEMA,t.TABNAME,t.totalsize,t.DATA_PARTITION_ID,substr(ts.TBSP_NAME,1,20) as TBSP_NAME,substr(ts.TBSP_TYPE,1,10) as TBSP_TYPE,ts.TBSP_PAGE_SIZE,case ts.TBSP_PAGE_SIZE when 4096 then 64 when 8192 then 128 when 16384 then 256 when 32768 then 512 end as TAB_HARD_LIMIT,ts.DBPARTITIONNUM from temp t,sysibmadm.tbsp_utilization ts where t.TBSPACEID=ts.TBSP_ID and t.DBPARTITIONNUM=ts.DBPARTITIONNUM order by t.totalsize desc with ur) select t.TABSCHEMA,t.TABNAME,t.TOTALSIZE,t.DATA_PARTITION_ID,t.TBSP_NAME,t.TBSP_TYPE,t.TBSP_PAGE_SIZE,t.TAB_HARD_LIMIT,dec((t.TOTALSIZE*100)/t.TAB_HARD_LIMIT,5,2) as TAB_HARD_LMT_PER,t.DBPARTITIONNUM from temp1 t order by 9 desc with ur"
        resultset = execute_query.select_query(db_connection, tab_hard_limit_sms_query)
        tables_list = resultset.loc[resultset['TAB_HARD_LMT_PER'] >= hard_limit_percent]
        if len(tables_list.index) > 0:
            #print(resultset.query('TAB_HARD_LMT_PER > 20'))
            msg_body = "Hi , Tables which crossed hard limit are:"
            for row in tables_list.values:
                msg_body += str(row)
                print(row)
        else:
            print(f"There is no table which crossed {hard_limit_percent}% hard limit size under SMS tablespace in {dbname} database")
            msg_body = "There is no table which crossed {hard_limit_percent}% hard limit size under SMS tablespace in {dbname} database"
        send_alert.send_mail(mail_from, mail_to, "Table hard Limit notification", msg_body)
        print(db_connection)
        db_connection.close()
    except Exception as e:
        print(str(e))
        traceback.print_exc()
    finally:
        if db_connection is None:
            db_connection.close()


def read_input():
    """Reading provided input values"""
    global dbname,host,port,user,password,hard_limit_percent
    global mail_from,mail_to,subject,msg_body
    dbname = 'EIDMODSQ'
    host = 'shaqin01.mega.us.zurich.com'
    port = 60134
    user = 'dbaall'
    password = 'dbaadm01'
    hard_limit_percent = 10
    mail_from = "dbaall@shaqin01.zurich.com"
    mail_to = "v.are-c@zurichna.com"


read_input()
get_table_hard_limit_sms(dbname,host,port,user,password)