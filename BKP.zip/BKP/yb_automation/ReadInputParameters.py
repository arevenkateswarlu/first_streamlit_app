import os
import argparse


class ReadInputParameters:
    """Class definition for reading the input parameters for the command"""
    def get_tables_size_parameters(self):
        tabsize_description = "Retrieves the table's size for the provided database. It prints the tables size onto " \
                              "the console, if output path is provided then it stores the details into file. "
        parser = argparse.ArgumentParser(description = tabsize_description)
        parser.add_argument('--host', default=os.getenv("YBHOST") ,required= False, help='Server Hostname/IP Address, '
                                                                                         'if not provided takes the '
                                                                                         'YBHOST variable value')
        parser.add_argument('--port', default=os.getenv("YBPORT"),required= False, help='Port number of the database '
                                                                                        'server, if not provided '
                                                                                        'takes the YBPORT variable '
                                                                                        'value')
        parser.add_argument('--user', default=os.getenv("YBUSER"),required= False, help='Username for Autherization ,'
                                                                                        'if not provided takes the '
                                                                                        'YBUSER variable value')
        parser.add_argument('--password', default=os.getenv("YBPASSWORD"),required= False, help='Password for the '
                                                                                                'user ,'
                                                                                                'if not provided '
                                                                                                'takes the YBPASSWORD '
                                                                                                'variable value')
        parser.add_argument('--dbname', default=os.getenv("YBDATABASE"),required= False,  help='database name for '
                                                                                               'which tables size is '
                                                                                               'required, '
                                                                                               'if not provided takes '
                                                                                               'the YBDATABASE '
                                                                                               'variable value')
        parser.add_argument('--table_name', required= False, help='Table name for which table size is required')
        parser.add_argument('--output', required=False, help='Output directory to store the tables size information in Excel format')
        args = parser.parse_args()
        #print(args)
        #parser.print_help()
        return args


    def get_db_size_parameters(self):
        dbsize_description = "Retrieves the databases size for the provided database. It prints the databases size onto " \
                              "the console, if output path is provided then it stores the details into file. "
        parser = argparse.ArgumentParser(description = dbsize_description)
        parser.add_argument('--host', default=os.getenv("YBHOST") ,required= False, help='Server Hostname/IP Address, '
                                                                                         'if not provided takes the '
                                                                                         'YBHOST variable value')
        parser.add_argument('--port', default=os.getenv("YBPORT"),required= False, help='Port number of the database '
                                                                                        'server, if not provided '
                                                                                        'takes the YBPORT variable '
                                                                                        'value')
        parser.add_argument('--user', default=os.getenv("YBUSER"),required= False, help='Username for Autherization ,'
                                                                                        'if not provided takes the '
                                                                                        'YBUSER variable value')
        parser.add_argument('--password', default=os.getenv("YBPASSWORD"),required= False, help='Password for the '
                                                                                                'user ,'
                                                                                                'if not provided '
                                                                                                'takes the YBPASSWORD '
                                                                                                'variable value')
        parser.add_argument('--dbname', default=os.getenv("YBDATABASE"),required= False,  help='database name for '
                                                                                               'which tables size is '
                                                                                               'required, '
                                                                                               'if not provided takes '
                                                                                               'the YBDATABASE '
                                                                                               'variable value')
        parser.add_argument('--output', required=False, help='Output directory to store the tables size information in Excel format')
        args = parser.parse_args()
        #print(args)
        #parser.print_help()
        return args

    def show_lock_waits_parameters(self):
        lock_waits_description = "Shows the lock waits in the provided server, database and table  "
        parser = argparse.ArgumentParser(description = lock_waits_description)
        parser.add_argument('--host', default=os.getenv("YBHOST") ,required= False, help='Server Hostname/IP Address, '
                                                                                         'if not provided takes the '
                                                                                         'YBHOST variable value')
        parser.add_argument('--port', default=os.getenv("YBPORT"),required= False, help='Port number of the database '
                                                                                        'server, if not provided '
                                                                                        'takes the YBPORT variable '
                                                                                        'value')
        parser.add_argument('--user', default=os.getenv("YBUSER"),required= False, help='Username for Autherization ,'
                                                                                        'if not provided takes the '
                                                                                        'YBUSER variable value')
        parser.add_argument('--password', default=os.getenv("YBPASSWORD"),required= False, help='Password for the '
                                                                                                'user ,'
                                                                                                'if not provided '
                                                                                                'takes the YBPASSWORD '
                                                                                                'variable value')
        parser.add_argument('--dbname',required= False,  help='database name for '
                                                              'which lock waits need to display'
                                                              )
        parser.add_argument('--table_name', required=False, help='Table name for which lock waits need to display')
        parser.add_argument('--wait_time', required=False, help='Provide the lock waits time in Minutes')
        args = parser.parse_args()
        #print(args)
        #parser.print_help()
        return args


    def userdb_monitoring_parameters(self):
        userdb_monitoring_description = "Monitors the ZNAWUSERDB database size and sends the alerts  "
        parser = argparse.ArgumentParser(description = userdb_monitoring_description)
        parser.add_argument('--host', default=os.getenv("YBHOST") ,required= False, help='Server Hostname/IP Address, '
                                                                                         'if not provided takes the '
                                                                                         'YBHOST variable value')
        parser.add_argument('--port', default=os.getenv("YBPORT"),required= False, help='Port number of the database '
                                                                                        'server, if not provided '
                                                                                        'takes the YBPORT variable '
                                                                                        'value')
        parser.add_argument('--user', default=os.getenv("YBUSER"),required= False, help='Username for Autherization ,'
                                                                                        'if not provided takes the '
                                                                                        'YBUSER variable value')
        parser.add_argument('--password', default=os.getenv("YBPASSWORD"),required= False, help='Password for the '
                                                                                                'user ,'
                                                                                                'if not provided '
                                                                                                'takes the YBPASSWORD '
                                                                                                'variable value')
        parser.add_argument('--size', default=5,required=False, help='Size(TB) of the znawuserdb to monitor , default monitoring size is 2 TB')
        args = parser.parse_args()
        #print(args)
        #parser.print_help()
        return args


    def long_running_queries_parameters(self):
        long_running_queries_description = "Monitors the long running queries on the server and sends the alert  "
        parser = argparse.ArgumentParser(description = long_running_queries_description)
        parser.add_argument('--host', default=os.getenv("YBHOST") ,required= False, help='Server Hostname/IP Address, '
                                                                                         'if not provided takes the '
                                                                                         'YBHOST variable value')
        parser.add_argument('--port', default=os.getenv("YBPORT"),required= False, help='Port number of the database '
                                                                                        'server, if not provided '
                                                                                        'takes the YBPORT variable '
                                                                                        'value')
        parser.add_argument('--user', default=os.getenv("YBUSER"),required= False, help='Username for Autherization ,'
                                                                                        'if not provided takes the '
                                                                                        'YBUSER variable value')
        parser.add_argument('--password', default=os.getenv("YBPASSWORD"),required= False, help='Password for the '
                                                                                                'user ,'
                                                                                                'if not provided '
                                                                                                'takes the YBPASSWORD '
                                                                                                'variable value')
        parser.add_argument('--time', default=30,required=False, help='Time in Minutes to verify the long Running queries monitoring')
        args = parser.parse_args()
        #print(args)
        #parser.print_help()
        return args


    def userdb_table_purge_parameters(self):
        userdb_table_purge_description = "Drop the tables in znawuserdb database created prior to the given time interval"
        parser = argparse.ArgumentParser(description = userdb_table_purge_description)
        parser.add_argument('--host', default=os.getenv("YBHOST") ,required= False, help='Server Hostname/IP Address, '
                                                                                         'if not provided takes the '
                                                                                         'YBHOST variable value')
        parser.add_argument('--port', default=os.getenv("YBPORT"),required= False, help='Port number of the database '
                                                                                        'server, if not provided '
                                                                                        'takes the YBPORT variable '
                                                                                        'value')
        parser.add_argument('--user', default=os.getenv("YBUSER"),required= False, help='Username for Autherization ,'
                                                                                        'if not provided takes the '
                                                                                        'YBUSER variable value')
        parser.add_argument('--password', default=os.getenv("YBPASSWORD"),required= False, help='Password for the '
                                                                                                'user ,'
                                                                                                'if not provided '
                                                                                                'takes the YBPASSWORD '
                                                                                                'variable value')
        parser.add_argument('--retain_interval', default=60,required=False, help='Number of days to retain the tables in znawuserdb based on the creation date')
        args = parser.parse_args()
        #print(args)
        #parser.print_help()
        return args


    def get_comments_parameters(self):
        comments_description = "Retrieves the comments of tables and columns  "
        parser = argparse.ArgumentParser(description = comments_description)
        parser.add_argument('--host', default=os.getenv("YBHOST") ,required= False, help='Server Hostname/IP Address, '
                                                                                         'if not provided takes the '
                                                                                         'YBHOST variable value')
        parser.add_argument('--port', default=os.getenv("YBPORT"),required= False, help='Port number of the database '
                                                                                        'server, if not provided '
                                                                                        'takes the YBPORT variable '
                                                                                        'value')
        parser.add_argument('--user', default=os.getenv("YBUSER"),required= False, help='Username for Autherization ,'
                                                                                        'if not provided takes the '
                                                                                        'YBUSER variable value')
        parser.add_argument('--password', default=os.getenv("YBPASSWORD"),required= False, help='Password for the '
                                                                                                'user ,'
                                                                                                'if not provided '
                                                                                                'takes the YBPASSWORD '
                                                                                                'variable value')
        parser.add_argument('--dbname', default=os.getenv("YBDATABASE"),required= True,  help='database name for '
                                                                                               'which comments is '
                                                                                               'required, '
                                                                                               'if not provided takes '
                                                                                               'the YBDATABASE '
                                                                                               'variable value')
        parser.add_argument('--table_name', required= False, help='Table name for which table size is required')
        args = parser.parse_args()
        #print(args)
        #parser.print_help()
        return args


    def db_size_history_track_parameters(self):
        db_size_history_description = "Stores the Yellowbrick databases size   "
        parser = argparse.ArgumentParser(description = db_size_history_description)
        parser.add_argument('--host', default=os.getenv("YBHOST") ,required= False, help='Server Hostname/IP Address, '
                                                                                         'if not provided takes the '
                                                                                         'YBHOST variable value')
        parser.add_argument('--port', default=os.getenv("YBPORT"),required= False, help='Port number of the database '
                                                                                        'server, if not provided '
                                                                                        'takes the YBPORT variable '
                                                                                        'value')
        parser.add_argument('--user', default=os.getenv("YBUSER"),required= False, help='Username for Autherization ,'
                                                                                        'if not provided takes the '
                                                                                        'YBUSER variable value')
        parser.add_argument('--password', default=os.getenv("YBPASSWORD"),required= False, help='Password for the '
                                                                                                'user ,'
                                                                                                'if not provided '
                                                                                                'takes the YBPASSWORD '
                                                                                                'variable value')
        parser.add_argument('--dbname', default=os.getenv("YBDATABASE"),required= True,  help='database name for '
                                                                                               'in which history table'
                                                                                               'is existed')
        parser.add_argument('--table_name', required= True, help='Database Size history table name')
        args = parser.parse_args()
        #print(args)
        #parser.print_help()
        return args


    def space_usage_monitoring_parameters(self):
        space_usage_monitoring_description = "This script is used to monitor the space usage of Yellowbrick database server "
        parser = argparse.ArgumentParser(description = space_usage_monitoring_description)
        parser.add_argument('--host', default=os.getenv("YBHOST") ,required= False, help='Server Hostname/IP Address, '
                                                                                         'if not provided takes the '
                                                                                         'YBHOST variable value')
        parser.add_argument('--port', default=os.getenv("YBPORT"),required= False, help='Port number of the database '
                                                                                        'server, if not provided '
                                                                                        'takes the YBPORT variable '
                                                                                        'value')
        parser.add_argument('--user', default=os.getenv("YBUSER"),required= False, help='Username for Autherization ,'
                                                                                        'if not provided takes the '
                                                                                        'YBUSER variable value')
        parser.add_argument('--password', default=os.getenv("YBPASSWORD"),required= False, help='Password for the '
                                                                                                'user ,'
                                                                                                'if not provided '
                                                                                                'takes the YBPASSWORD '
                                                                                                'variable value')
        parser.add_argument('--avg_threshold', default=85,required= False,  help='Average space usage threshold acsross the data nodes')
        parser.add_argument('--max_threshold', default=90,required= False, help='Maximum space usage threshold on any data node')
        args = parser.parse_args()
        #print(args)
        #parser.print_help()
        return args


    def get_Table_Structure_parameters(self):
        comments_description = "Retrieves the Table DDL and comments , doesn't work for complete database  "
        parser = argparse.ArgumentParser(description = comments_description)
        parser.add_argument('--host', default=os.getenv("YBHOST") ,required= False, help='Server Hostname/IP Address, '
                                                                                         'if not provided takes the '
                                                                                         'YBHOST variable value')
        parser.add_argument('--port', default=os.getenv("YBPORT"),required= False, help='Port number of the database '
                                                                                        'server, if not provided '
                                                                                        'takes the YBPORT variable '
                                                                                        'value')
        parser.add_argument('--user', default=os.getenv("YBUSER"),required= False, help='Username for Autherization ,'
                                                                                        'if not provided takes the '
                                                                                        'YBUSER variable value')
        parser.add_argument('--password', default=os.getenv("YBPASSWORD"),required= False, help='Password for the '
                                                                                                'user ,'
                                                                                                'if not provided '
                                                                                                'takes the YBPASSWORD '
                                                                                                'variable value')
        parser.add_argument('--dbname', required= True,  help='database name for '
                                                                                               'which Table DDL is '
                                                                                               'required, '
                                                                                               )
        parser.add_argument('--table_name', required= True, help='Table name for which table structure is required')
        args = parser.parse_args()
        #print(args)
        #parser.print_help()
        return args


    def get_Table_bkp_userdb_parameters(self):
        comments_description = "Used to take the given table backup in znawuserdb database on the same server  "
        parser = argparse.ArgumentParser(description = comments_description)
        parser.add_argument('--host', default=os.getenv("YBHOST") ,required= False, help='Server Hostname/IP Address, '
                                                                                         'if not provided takes the '
                                                                                         'YBHOST variable value')
        parser.add_argument('--port', default=os.getenv("YBPORT"),required= False, help='Port number of the database '
                                                                                        'server, if not provided '
                                                                                        'takes the YBPORT variable '
                                                                                        'value')
        parser.add_argument('--user', default=os.getenv("YBUSER"),required= False, help='Username for Autherization ,'
                                                                                        'if not provided takes the '
                                                                                        'YBUSER variable value')
        parser.add_argument('--password', default=os.getenv("YBPASSWORD"),required= False, help='Password for the '
                                                                                                'user ,'
                                                                                                'if not provided '
                                                                                                'takes the YBPASSWORD '
                                                                                                'variable value')
##        parser.add_argument('--space_usage_threshold', required=False, default=90, help='Backup Table name in znawuserdb')
        parser.add_argument_group('required arguments')
        parser.add_argument('--dbname', required= True,  help='database name for '
                                                                                               'which Table backup is '
                                                                                               'required, '
                                                                                               )
        parser.add_argument('--table_name', required= True, help='Table name for which table backup is required in znawuserdb')
        parser.add_argument('--bkp_table_name', required=True, help='Backup Table name in znawuserdb')
        args = parser.parse_args()
        #print(args)
        #parser.print_help()
        return args


    def get_generate_insert_parameters(self):
        comments_description = "Generates the Insert command for the given Target table based on the Source Tables after columns addition to Target table "
        parser = argparse.ArgumentParser(description = comments_description)
        parser.add_argument('--host', default=os.getenv("YBHOST") ,required= False, help='Server Hostname/IP Address, '
                                                                                         'if not provided takes the '
                                                                                         'YBHOST variable value')
        parser.add_argument('--port', default=os.getenv("YBPORT"),required= False, help='Port number of the database '
                                                                                        'server, if not provided '
                                                                                        'takes the YBPORT variable '
                                                                                        'value')
        parser.add_argument('--user', default=os.getenv("YBUSER"),required= False, help='Username for Autherization ,'
                                                                                        'if not provided takes the '
                                                                                        'YBUSER variable value')
        parser.add_argument('--password', default=os.getenv("YBPASSWORD"),required= False, help='Password for the '
                                                                                                'user ,'
                                                                                                'if not provided '
                                                                                                'takes the YBPASSWORD '
                                                                                                'variable value')
        parser.add_argument('--out_path', required=False, default=os.getcwd(), help='Output path where Generated Insert statements need to be stored')
        parser.add_argument_group('required arguments')
        parser.add_argument('--src_db', required= True,  help='Source database name where backup table exists')
        parser.add_argument('--src_table', required= True, help='Backup Table name from which data need to be copied')
        parser.add_argument('--tgt_db', required=True, help='Target database name where Target table exists')
        parser.add_argument('--tgt_table', required=True, help='Target Table name into which data need to be copied from Backup Table')
        args = parser.parse_args()
        #print(args)
        #parser.print_help()
        return args


    def get_Table_ddl_compare_parameters(self):
        compare_description = "Compares the Source and Target database Tables DDL "
        parser = argparse.ArgumentParser(description = compare_description)
        parser.add_argument('--shost', default=os.getenv("YBHOST") ,required= False, help='Source Server Hostname/IP Address, '
                                                                                         'if not provided takes the '
                                                                                         'YBHOST variable value')
        parser.add_argument('--port', default=os.getenv("YBPORT"),required= False, help='Port number of the database '
                                                                                        'server, if not provided '
                                                                                        'takes the YBPORT variable '
                                                                                        'value')
        parser.add_argument('--user', default=os.getenv("YBUSER"),required= False, help='Username for Autherization ,'
                                                                                        'if not provided takes the '
                                                                                        'YBUSER variable value')
        parser.add_argument('--password', default=os.getenv("YBPASSWORD"),required= False, help='Password for the '
                                                                                                'user ,'
                                                                                                'if not provided '
                                                                                                'takes the YBPASSWORD '
                                                                                                'variable value')
        parser.add_argument('--thost', required=False, default=os.getenv("YBHOST"), help='Target Server Hostname/IP Address, '
                                                                                         'if not provided takes the '
                                                                                         'YBHOST variable value')
        parser.add_argument('--src_diff_only', required=False, default="No",help='Provide this option as "YES" to get only Source differenaces')
        parser.add_argument('--table_name', required= False, help='Table name for which DDL need to compare')
        parser.add_argument_group('required arguments')
        parser.add_argument('--src_db', required= True,  help='Source database name from where tables DDL need to compare')
        parser.add_argument('--tgt_db', required=True, help='Target database name where tables DDL need to compare')
        args = parser.parse_args()
        #print(args)
        #parser.print_help()
        return args



    def get_DailyDDLChanges_parameters(self):
        DDLChanges_description = "Prepares report for DDL changes for all databases"
        parser = argparse.ArgumentParser(description = DDLChanges_description)
        parser.add_argument('--host', default=os.getenv("YBHOST") ,required= False, help='Server Hostname/IP Address, '
                                                                                         'if not provided takes the '
                                                                                         'YBHOST variable value')
        parser.add_argument('--port', default=os.getenv("YBPORT"),required= False, help='Port number of the database '
                                                                                        'server, if not provided '
                                                                                        'takes the YBPORT variable '
                                                                                        'value')
        parser.add_argument('--user', default=os.getenv("YBUSER"),required= False, help='Username for Autherization ,'
                                                                                        'if not provided takes the '
                                                                                        'YBUSER variable value')
        parser.add_argument('--password', default=os.getenv("YBPASSWORD"),required= False, help='Password for the '
                                                                                                'user ,'
                                                                                                'if not provided '
                                                                                                'takes the YBPASSWORD '
                                                                                                'variable value')
        parser.add_argument('--meta_db', default=os.getenv("YBDATABASE"),required= False, help='Database name in which history table exists')
        parser.add_argument('--meta_table', required=True, help='Meta data table name to store the column information')
        args = parser.parse_args()
        #print(args)
        #parser.print_help()
        return args