from DataFrameToFile import DataFrameToFile
from send_email import send_email_alert as send_email
from LogGenerate import LogGenerate
from GetConnection import GetConnection
from SqlToDataFrame import SqlToDataFrame
from get_db_size import Get_DB_Size
from ReadInputParameters import ReadInputParameters
import psycopg2.extras as extras
from tabulate import tabulate


class db_size_history_track:
    def __init__(self, input_parameters):
        self.hostname = input_parameters.host
        self.port = input_parameters.port
        self.username = input_parameters.user
        self.password = input_parameters.password
        if input_parameters.dbname is None:
            print("Please provide the database name")
            exit(1)
        else:
            self.connect_database = input_parameters.dbname
        if input_parameters.table_name is None:
            print("Please provide the history table name")
            exit(1)
        else:
            self.table_name = input_parameters.table_name


    def get_dbsize_info(self):
        logging = LogGenerate()
        logger = logging.logger(__name__)
        logger.debug(('Enetered into get dbsize Method'))
        sqlQuery = open(r"sql_queries\db_size_hist.sql", "r+").read()
        connect = GetConnection()
        connection = connect.get_connection(logger, self.hostname, self.port, self.username, self.password,'sysviews')
        dataFrame = SqlToDataFrame()
        Db_Size_Gb_DF = dataFrame.load_data_frame(logger, connection, sqlQuery)
        #print(Db_Size_Gb_DF)
        return Db_Size_Gb_DF


    def store_db_size(self,dbSizeDF):
        logging = LogGenerate()
        logger = logging.logger(__name__)
        logger.debug(('Enetered into store db size Method'))
        records = [tuple(x) for x in dbSizeDF.to_numpy()]
        columnNames = ','.join(list(dbSizeDF.columns))
        insertQuery = "INSERT INTO %s(%s) VALUES %%s" % (self.table_name, columnNames)
        connect = GetConnection()
        connection = connect.get_connection(logger, self.hostname, self.port, self.username, self.password,
                                                self.connect_database)
        cursor = connection.cursor()
        try:
            extras.execute_values(cursor, insertQuery, records)
            connection.commit()
            #print(dbSizeDF.transpose())
        except (Exception) as error:
            print("Error: %s" % error)
            connection.rollback()
            cursor.close()
            return 1
        print("the dataframe is inserted")
        cursor.close()


    def get_dbsize_history(self):
        logging = LogGenerate()
        logger = logging.logger(__name__)
        logger.debug(('Enetered into get dbsize history Method'))
        sqlQuery = "select trackdate,db_name,cmpr_gb from db_size_history order by trackdate desc,cmpr_gb desc"
        connect = GetConnection()
        connection = connect.get_connection(logger, self.hostname, self.port, self.username, self.password, self.connect_database)
        dataFrame = SqlToDataFrame()
        Db_Size_History_DF = dataFrame.load_data_frame(logger, connection, sqlQuery)
        #print(Db_Size_History_DF.pivot(index ='db_name', columns ='trackdate', values ='cmpr_gb').sort_values('db_name'))
        Db_Size_History_DF_Pivot = Db_Size_History_DF.pivot(index ='db_name', columns ='trackdate', values ='cmpr_gb').sort_values('db_name')
        Db_Size_History_DF_Pivot.to_excel('E:\Folder_Share\yb_Automation\db_size_history.xlsx',index=True,sheet_name='db_size_history')
        email_body = "Hi Team,<br /> <br />Please find the attached databases size(GB) on server %s." % (self.hostname)
        email_subject = "Databases size(GB) growth on %s Server" + self.hostname
        #send_email.send_alert(sender="USZ_ZNA_NZ_DBA@zurichna.com",receivers="v.are-c@zurichna.com",body=email_body,subject=email_subject,Attachment='E:\Folder_Share\yb_Automation\db_size_history.xlsx')


def main():
    #print("Header or default or direct run of the script TablesSize")
    getInputParameters = ReadInputParameters()
    inputParameters = getInputParameters.db_size_history_track_parameters()
    dbHistTrackObj = db_size_history_track(inputParameters)
    dbHistTrackObj.store_db_size(dbHistTrackObj.get_dbsize_info())
    dbHistTrackObj.get_dbsize_history()


if __name__ == "__main__":
    main()

