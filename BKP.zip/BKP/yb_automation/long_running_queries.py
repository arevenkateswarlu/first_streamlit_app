from send_email import send_email_alert as send_email
from LogGenerate import LogGenerate
from GetConnection import GetConnection
from SqlToDataFrame import SqlToDataFrame
from ReadInputParameters import ReadInputParameters
from tabulate import tabulate


class long_running_queries:
    def __init__(self,input_parameters):
        self.hostname = input_parameters.host
        self.port = input_parameters.port
        self.username = input_parameters.user
        self.password = input_parameters.password
        self.connect_database = "znawuserdb"
        self.filter_condition = " "
        if input_parameters.time is not None:
            self.wait_time = input_parameters.time
            self.filter_condition = self.filter_condition + " and submit_time <= (current_timestamp - make_time(0, " + str(self.wait_time) + ", 0)) "
            if int(input_parameters.time) >= 60:
                print("Lock wait time monitoring should not exceed 60 minutes")
                exit(6)
        else:
            self.wait_time = 30
            self.filter_condition = self.filter_condition + " and submit_time <= (current_timestamp - make_time(0,30, 0)) "


    def get_long_running_queries(self):
        logging = LogGenerate()
        logger = logging.logger(__name__)
        logger.debug(('Enetered into Show Long Running Queries Method'))
        #LongRunningQuery = open(r"/home/ybloadusr/PYTHON_VENV/python_scripts/sql_queries/long_running_queries.sql","r+")
        LongRunningQuery = open(r"sql_queries\long_running_queries.sql", "r+")
        sqlQuery = LongRunningQuery.read().replace('filter_condition',self.filter_condition)
        connect = GetConnection()
        connection = connect.get_connection(logger,self.hostname, self.port, self.username, self.password, self.connect_database)
        dataFrame = SqlToDataFrame()
        LongRunningSqlDF = dataFrame.load_data_frame(logger,connection,sqlQuery)
        connection.close()
        return LongRunningSqlDF
        #print(tabulate(dbSizeDataFrame, headers = 'keys', tablefmt = 'psql' , showindex= False))


def main():
    """
        Enters here when we call this class"""
    getInputParameters = ReadInputParameters()
    inputParameters = getInputParameters.long_running_queries_parameters()
    #print(inputParameters)
    LongRunQueries = long_running_queries(inputParameters)
    LongRunQueriesDF = LongRunQueries.get_long_running_queries()
    if len(LongRunQueriesDF) == 0:
        print("There is no long running queries which submit before %d" % (inputParameters.time))
    else:
        #print(tabulate(lockWaitDataFrame, headers='keys', tablefmt='psql', showindex=False))
        email_body = "Hi Team,<br /> <br />There are Queries running longer than %d Minutes on the server %s " % (inputParameters.time,inputParameters.host)
        email_subject = "Long Running Queries on the server " + inputParameters.host
        send_email.send_alert(sender="USZ_ZNA_NZ_DBA@zurichna.com",receivers="v.are-c@zurichna.com",body=email_body,subject=email_subject,ContentTable=LongRunQueriesDF)


if __name__ == "__main__":
    main()
