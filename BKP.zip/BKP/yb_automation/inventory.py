import openpyxl
wb=openpyxl.load_workbook("C:\\Users\\v.are\\Downloads\\U2Z-SCS-PREM_inventory_latest_5.xlsx")
sh1=wb['U2Z-SCS-PREM']
row=sh1.max_row
col=sh1.max_column
for i in range(2,row+1):
        if sh1.cell(i,11).value !=None and sh1.cell(i,11).value !="#N/A":
            ans=""
            op=[]
            s=sh1.cell(i,11).value
            cur=s.find("$$DBOwnerWRK",0)
            #cm1=s.find("\n",cm+1)
            while cur!=-1:
                cur1= s.find("\n",cur+1)
                if cur1==-1:
                     cur1=len(s)
                if (s[cur:cur1] not in op):
                    op.append(s[cur:cur1])
                cur =s.find("$$DBOwnerWRK",cur1+1)
            if op==[]:
                ans="#N/A"
            else:
                for e in op:
                    ans+=e
                    ans+="\n"
            sh1.cell(row=i,column=15,value=ans)
            print(ans)
        else:
            sh1.cell(row=i,column=15,value="#N/A")
wb.save("C:\\Users\\v.are\\Downloads\\U2Z-SCS-PREM_inventory_latest_6.xlsx")