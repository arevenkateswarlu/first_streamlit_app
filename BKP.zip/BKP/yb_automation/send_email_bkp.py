import smtplib
from email.message import EmailMessage
from email.mime.multipart import MIMEMultipart
from smtplib import SMTPException
from email.mime.text import MIMEText


class send_email_alert:
    def send_alert(**kwargs):
        for key,value in kwargs.items():
            if key == "sender":
                sender = value
            elif key == "receivers":
                receivers = value
            elif key == "body":
                body = value
            elif key == "subject":
                subject = value
            elif key == "lock_waits":
                data_df = value
            elif key == "userdb_tab_size":
                data_df = value
        msg = MIMEMultipart()
        msg['Subject'] = subject
        msg['To'] = receivers
        msg['From'] = sender
        email_body = """\
                    <html>
                    <head></head>
                    <body>
                    %s
                    """ %(body)
        email_body = email_body + """
					<br /> 
                    {0}
                    """.format(data_df.to_html(index=False))
        email_body = email_body + """<br /> <br /> Thanks,<br />YB DBA Team."""
        email_body = email_body + """</body> <html>"""
        email_body_html = MIMEText(email_body, 'html')
        #msg.set_content(body)
        msg.attach(email_body_html)
        try:
            smtpObj = smtplib.SMTP('smtp.zurichna.com',25)
            #smtpObj.send_message(msg.as_string())
            smtpObj.sendmail(msg['From'],msg['To'],msg.as_string())
            print("Successfully sent email")
        except SMTPException:
            print("Error: unable to send email")


# def main():
#     """This class methods should call from other methods by providing the required input parameters"""
#     print("This class should call from other methods by providing input parameter")
#     exit(1)
#
#
# if __name__ == "__main__":
#         main()
