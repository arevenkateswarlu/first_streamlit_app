from DataFrameToFile import DataFrameToFile
from send_email import send_email_alert as send_email
from LogGenerate import LogGenerate
from GetConnection import GetConnection
from SqlToDataFrame import SqlToDataFrame
from get_db_size import Get_DB_Size
from ReadInputParameters import ReadInputParameters
import psycopg2.extras as extras
import pandas as pd
from tabulate import tabulate


class nonprod_region_space_usage:
    def __init__(self, input_parameters):
        self.hostname = input_parameters.host
        self.port = input_parameters.port
        self.username = input_parameters.user
        self.password = input_parameters.password
        if input_parameters.dbname is None:
            print("Please provide the database name")
            exit(1)
        else:
            self.connect_database = input_parameters.dbname
        if input_parameters.table_name is None:
            print("Please provide the history table name")
            exit(1)
        else:
            self.table_name = input_parameters.table_name


    def get_dbsize_info(self,region):
        logging = LogGenerate()
        logger = logging.logger(__name__)
        logger.debug(('Enetered into get dbsize Method'))
        sqlQuery = open(r"sql_queries\db_size_hist.sql", "r+").read()
        hostname = "10.154.24.5"
        if region == "DEV" :
            hostname = "10.154.24.5"
            sqlQuery = open(r"sql_queries\db_size_region_dev.sql", "r+").read()
        elif region == "QA" :
            hostname = "10.154.24.6"
            sqlQuery = open(r"sql_queries\db_size_region_qa.sql", "r+").read()
        else:
            print("Unknown region")
            exit(2)
        connect = GetConnection()
        connection = connect.get_connection(logger, hostname, self.port, self.username, self.password,'sysviews')
        dataFrame = SqlToDataFrame()
        Db_Size_Gb_DF = dataFrame.load_data_frame(logger, connection, sqlQuery)
        #print(Db_Size_Gb_DF)
        return Db_Size_Gb_DF


    def store_db_size(self,dbSizeDF):
        logging = LogGenerate()
        logger = logging.logger(__name__)
        logger.debug(('Enetered into store db size Method'))
        records = [tuple(x) for x in dbSizeDF.to_numpy()]
        columnNames = ','.join(list(dbSizeDF.columns))
        insertQuery = "INSERT INTO %s(%s) VALUES %%s" % (self.table_name, columnNames)
        connect = GetConnection()
        connection = connect.get_connection(logger, self.hostname, self.port, self.username, self.password,
                                                self.connect_database)
        cursor = connection.cursor()
        try:
            extras.execute_values(cursor, insertQuery, records)
            connection.commit()
            #print(dbSizeDF.transpose())
        except (Exception) as error:
            print("Error: %s" % error)
            connection.rollback()
            cursor.close()
            return 1
        print("the dataframe is inserted")
        cursor.close()


    def get_region_size(self):
        logging = LogGenerate()
        logger = logging.logger(__name__)
        logger.debug(('Enetered into get dbsize history Method'))
        #sqlQuery = "select db.server,r.region,sum(db.cmpr_gb) as region_size_gb from db_size_region db,region_table r where db.db_name=r.database and db.trackdate=(select max(trackdate) from db_size_region ) group by db.server,r.region order by  region_size_gb desc "
        sqlQuery = "select db.server,r.region,sum(db.cmpr_gb) as region_size_gb from db_size_region db,region_table r where db.db_name=r.database and db.server=r.server and db.trackdate=(select max(trackdate) from db_size_region ) group by db.server,r.region union all select db.server,'UKNOWN' as region,sum(db.cmpr_gb) as region_size_gb from db_size_region db where db.db_name not in (select database from region_table) and db.db_name not in ('temp space') group by db.server,region order by region_size_gb desc"
        dbSizeSqlQuery = "select db_name,cmpr_gb,server from znaw_term.dbaall.db_size_region where db_name not in ('temp space') and trackdate = (select max(trackdate) from db_size_region ) order by cmpr_gb desc"
        connect = GetConnection()
        connection = connect.get_connection(logger, self.hostname, self.port, self.username, self.password, self.connect_database)
        dataFrame = SqlToDataFrame()
        db_region_size_DF = dataFrame.load_data_frame(logger, connection, sqlQuery)
        dbSizeDF = dataFrame.load_data_frame(logger, connection, dbSizeSqlQuery)
        #print(Db_Size_History_DF.pivot(index ='db_name', columns ='trackdate', values ='cmpr_gb').sort_values('db_name'))
        ##Db_Size_History_DF_Pivot = Db_Size_History_DF.pivot(index ='db_name', columns ='trackdate', values ='cmpr_gb').sort_values('db_name')
        with pd.ExcelWriter("E:\Folder_Share\yb_Automation\yb_db_region_size.xlsx") as writer:
            db_region_size_DF.to_excel(writer,index=False,sheet_name='region_size')
            dbSizeDF.to_excel(writer,index=False,sheet_name='db_size_nonprod')
        email_body = "Hi Team,<br /> <br />Please find the attached non-production regions space usage."
        email_subject = "Non-production regions space usage details"
        #send_email.send_alert(sender="USZ_ZNA_NZ_DBA@zurichna.com",receivers="v.are-c@zurichna.com",body=email_body,subject=email_subject,Attachment='E:\Folder_Share\yb_Automation\yb_db_region_size.xlsx')



def main():
    #print("Header or default or direct run of the script TablesSize")
    getInputParameters = ReadInputParameters()
    inputParameters = getInputParameters.db_size_history_track_parameters()
    dbRegionSizeObj = nonprod_region_space_usage(inputParameters)
    dbRegionSizeObj.store_db_size(dbRegionSizeObj.get_dbsize_info("DEV"))
    dbRegionSizeObj.store_db_size(dbRegionSizeObj.get_dbsize_info("QA"))
    dbRegionSizeObj.get_region_size()


if __name__ == "__main__":
    main()

