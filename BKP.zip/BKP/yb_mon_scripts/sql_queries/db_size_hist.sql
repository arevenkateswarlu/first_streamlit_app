set search_path to public;
select current_date as trackdate,db_name,cmpr_gb from sysviews.public.storage_by_db_p() where db_name not in ('temp space');
