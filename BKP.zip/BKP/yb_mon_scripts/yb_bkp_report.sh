#------------------------------------------------------------------------------
# Initialyzing the Yellowbrick environment
#
#. ${HOME}/.bashrc

. /home/ybmonusr/.bash_profile
export TZ=":US/Central"
DBNAMES="accslndprd codnaardb edw edw_zst envdetaildb lrddimdb lrdprstdb lrdstgdb lrdudidb lrdwrkdb nz_pcaadsdb pmlhvadsdb pmlhvadsqa pmlhvstgdb pmwrkdb rei_stg riaudp42 seekrpt srcsapdb zeacfldb zeadimdb zeadimdb_zst zeaflatdb zeamstdb zeastgdb zeaudidb znaw_term znawadsdb znawadsdb_mm znawadsdb_pm znawbrsnpht znawbusndb znawcdcdb znawfdsdb znawiflnddb znawifprstdb znawirmadb znawprstdb znawsapdb znawsnpsht znawsnpsht_zst znawstgdb znawstgdb_pm znawuserdb znawwrkdb"
log_file_manage()
{
  if [ ! -d "${HOME}/MON_SCRIPTS/LOGS/BKP_REPORT" ]
  then
    mkdir -p ${HOME}/MON_SCRIPTS/LOGS/BKP_REPORT
  fi
  FSTAMP=`date +"%d%m%Y"`
  MAIL_CONTENT_LOG=${HOME}/MON_SCRIPTS/LOGS/BKP_REPORT/bkp_status_${FSTAMP}.html
}

bkp_dly_verify()
{
ybsql -d znawuserdb -tqAc "CREATE TABLE if not EXISTS DB_BKP_WKL(database_name character(40),start_dt varchar(20),state character(30)) DISTRIBUTE ON (database_name)"
ybsql -d znawuserdb -tqAc "CREATE TABLE if not EXISTS BKP_DLY (database_name character(40),type character(20),state character(30),start_time date,backup_point_id character(100)) DISTRIBUTE ON (database_name)"
ybsql -d znawuserdb -tqc "delete from znawuserdb.dbaall.bkp_dly"
for DBNAME in `echo $DBNAMES`
do
BKP_COUNT_DLY=$(ybsql -d znawuserdb -tqAc "select count(1) from sys.log_backup where database_name='${DBNAME}' and state in ('DONE') and start_time >= (select current_timestamp - 1 DAYS ) ")
if [ ${BKP_COUNT_DLY} -ge 1 ]
then
DLY_BKP_STS=$(ybsql -d znawuserdb -tqAc "select database_name,type,state,date(start_time) as start_time,backup_point_id from sys.log_backup where database_name='${DBNAME}' order by session_id desc limit 1")
DLY_BKP_STS=$(echo "${DLY_BKP_STS}"|sed "s/|/','/g")
#ybsql -d znawuserdb -tqc "insert into znawuserdb.dbaall.bkp_dly(select database_name,type,state,date(start_time) as start_time,backup_point_id,chain_id from sys.log_backup where database_name='${DBNAME}' order by start_time desc limit 1)"
ybsql -d znawuserdb -tqc "insert into znawuserdb.dbaall.bkp_dly values ('${DLY_BKP_STS}')"
else 
ybsql -d znawuserdb -tqc "insert into znawuserdb.dbaall.bkp_dly (select '${DBNAME}','ANY','FAILED',current_date,'ERROR') "
fi
done
}

bkp_wkl_verify()
{
ybsql -d znawuserdb -tqc "delete from znawuserdb.dbaall.DB_BKP_WKL"
for DBNAME in `echo $DBNAMES`
do
FULL_BKP_DT=`ybsql -tqAc "select date(max(start_time)) from sys.log_backup where database_name='${DBNAME}' and state in ('DONE') and type='F' and start_time >= (select current_timestamp - 32 DAYS )  "`
BKP_COUNT=$(echo ${FULL_BKP_DT}|sed '/^[[:space:]]*$/d'|wc -l)
if [ ${BKP_COUNT} -ge 1 ]
then
ybsql -d znawuserdb -tqc "insert into znawuserdb.dbaall.DB_BKP_WKL values('${DBNAME}','${FULL_BKP_DT}','SUCCESS')"
else
FULL_BKP_DT=$(ybsql -tqAc "select date(max(start_time)) from sys.log_backup where database_name='${DBNAME}' and state in ('DONE') and type='F' ")
ybsql -d znawuserdb -tqc "insert into znawuserdb.dbaall.DB_BKP_WKL values('${DBNAME}','${FULL_BKP_DT}','FAILED')"
fi
done
}
log_file_manage
bkp_dly_verify
bkp_wkl_verify

echo "<html> "  > ${MAIL_CONTENT_LOG}
echo "<body> " >> ${MAIL_CONTENT_LOG}
echo "Hi ," >> ${MAIL_CONTENT_LOG}
echo "<br> " >> ${MAIL_CONTENT_LOG}
echo " " >> ${MAIL_CONTENT_LOG}
echo "Yellowbrick production databases backup status report: " >> ${MAIL_CONTENT_LOG}
echo " " >> ${MAIL_CONTENT_LOG}

echo '<pre style="font: monospace ">' >> ${MAIL_CONTENT_LOG}

echo "Latest backup status :" >> ${MAIL_CONTENT_LOG}
echo "<table border=2>" >> ${MAIL_CONTENT_LOG}

ybsql -d znawuserdb -qc "select * from znawuserdb.dbaall.bkp_dly"|sed 's/|//g'|sed 's/--//g'|sed 's/-//g'|sed 's/+//g'|grep -iv 'row'|sed '/^$/d'|while read -r line
do
color_count=`echo ${line}|grep -i fail|wc -l`
if [ ${color_count} -eq 0 ]
then
echo "<tr valign=top bgcolor=aad118>" >> ${MAIL_CONTENT_LOG}
else
echo "<tr valign=top bgcolor=f12e4f>" >> ${MAIL_CONTENT_LOG}
fi
for col in `echo ${line}`
do
echo "<td align=left> ${col} </td>" >> ${MAIL_CONTENT_LOG}
done
echo "</tr>" >> ${MAIL_CONTENT_LOG}
done
echo "</table>" >> ${MAIL_CONTENT_LOG}
echo " " >> ${MAIL_CONTENT_LOG}


echo "Monthly backup status :" >> ${MAIL_CONTENT_LOG}
echo "<table border=2>" >> ${MAIL_CONTENT_LOG}

ybsql -d znawuserdb -qc "select * from znawuserdb.dbaall.DB_BKP_WKL"|sed 's/|//g'|sed 's/--//g'|sed 's/-//g'|sed 's/+//g'|grep -iv 'row'|sed '/^$/d'|while read -r line
do
color_count=`echo ${line}|grep -i fail|wc -l`
if [ ${color_count} -eq 0 ]
then
echo "<tr valign=top bgcolor=aad118>" >> ${MAIL_CONTENT_LOG}
else
echo "<tr valign=top bgcolor=f12e4f>" >> ${MAIL_CONTENT_LOG}
fi
for col in `echo ${line}`
do
echo "<td align=left> ${col} </td>" >> ${MAIL_CONTENT_LOG}
done
echo "</tr>" >> ${MAIL_CONTENT_LOG}
done
echo "</table>" >> ${MAIL_CONTENT_LOG}
echo " " >> ${MAIL_CONTENT_LOG}

echo "Thanks," >> ${MAIL_CONTENT_LOG}
echo "Yellowbrick DBA Team." >> ${MAIL_CONTENT_LOG}

echo "</pre> </body> </html>" >> ${MAIL_CONTENT_LOG}



EMAIL_TO="usz_zna_nz_dba@zurichna.com"
##EMAIL_TO="v.are-c@zurichna.com"
SUBJECT="Yellowbrick production databases backup status  `date '+%a %b %d %H:%M:%S %Z %Y'`"
export BODY=`echo ${MAIL_CONTENT_LOG}`

(
 echo "To: ${EMAIL_TO}"
 echo "Subject: $SUBJECT"
 echo "MIME-Version: 1.0"
 echo 'Content-Type: multipart/mixed; boundary="-q1w2e3r4t5"'
 echo '---q1w2e3r4t5'
 echo "Content-Type: text/html"
 echo "Content-Disposition: inline"
 cat ${BODY}
 echo '---q1w2e3r4t5--'
) | /usr/lib/sendmail ${EMAIL_TO}

