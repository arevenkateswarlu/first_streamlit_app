from DataFrameToFile import DataFrameToFile
from send_email import send_email_alert as send_email
from LogGenerate import LogGenerate
from GetConnection import GetConnection
from SqlToDataFrame import SqlToDataFrame
from get_db_size import Get_DB_Size
from ReadInputParameters import ReadInputParameters
from tabulate import tabulate
from GetTablesSize import GetTablesSize
import datetime


class space_usage_monitoring:
    def __init__(self, input_parameters):
        self.hostname = input_parameters.host
        self.port = input_parameters.port
        self.username = input_parameters.user
        self.password = input_parameters.password
        self.email = ["v.are-c@zurichna.com","saisumanth.korada-c@zurichna.com"]
        if input_parameters.avg_threshold is None:
            self.avg_threshold = 85
        else:
            self.avg_threshold = input_parameters.avg_threshold
        if input_parameters.max_threshold is None:
            self.max_threshold = 90
        else:
            self.max_threshold = input_parameters.max_threshold


    def get_avg_space_usage(self):
        logging = LogGenerate()
        logger = logging.logger(__name__)
        logger.debug(('Enetered into get average space usage Method'))
        #sqlQuery = open(r"sql_queries\space_usage.sql", "r+").read()
        sqlQuery = open(r"/home/ybmonusr/PYTHON_SCRIPTS/sql_queries/space_usage.sql", "r+").read()
        connect = GetConnection()
        connection = connect.get_connection(logger, self.hostname, self.port, self.username, self.password,'sysviews')
        dataFrame = SqlToDataFrame()
        SpaceUsage_DF = dataFrame.load_data_frame(logger, connection, sqlQuery)
        if SpaceUsage_DF['used_pct'].values < int(self.avg_threshold):
            print("%s : Average Space usage on server %s is %s which is under threshold(%s) " % (datetime.datetime.now(),self.hostname,SpaceUsage_DF['used_pct'].values[0],self.avg_threshold))
        else:
            #DBSizeQueryFile = open(r"sql_queries\dbSizeQuery.sql", "r+")
            DBSizeQueryFile = open(r"/home/ybmonusr/PYTHON_SCRIPTS/sql_queries/dbSizeQuery.sql", "r+")
            sqlQuery = DBSizeQueryFile.read().replace('filter_condition', ' ')
            dbSizeDataFrame = dataFrame.load_data_frame(logger, connection, sqlQuery)
            self.output="/tmp/table_size_" + self.hostname + ".xlsx"
            self.filter_condition = ""
            self.connect_database="znawuserdb"
            GetTablesSize.tablesSize(self)
            email_body = "Hi Team,<br /> <br /> Average space usage on server %s is crossed %s threshold. Please take necessary action, if usage reaches 95 then databases will go into read-only mode" % (self.hostname,SpaceUsage_DF['used_pct'].values[0])
            email_subject = "Space Usage is crossed %s on %s Server" %  (SpaceUsage_DF['used_pct'].values[0],self.hostname)
            send_email.send_alert(sender="USZ_ZNA_NZ_DBA@zurichna.com", receivers=self.email,body=email_body, subject=email_subject,ContentTable=dbSizeDataFrame,Attachment=self.output)
            exit(1)


    def get_max_space_usage(self):
        logging = LogGenerate()
        logger = logging.logger(__name__)
        logger.debug(('Enetered into get Maximum space usage Method'))
        ##sqlQuery = open(r"sql_queries\max_space_used.sql", "r+").read()
        sqlQuery = open(r"/home/ybmonusr/PYTHON_SCRIPTS/sql_queries/max_space_used.sql", "r+").read()
        connect = GetConnection()
        connection = connect.get_connection(logger, self.hostname, self.port, self.username, self.password,'sysviews')
        dataFrame = SqlToDataFrame()
        SpaceUsage_DF = dataFrame.load_data_frame(logger, connection, sqlQuery)
        if SpaceUsage_DF['max_used'].values < int(self.max_threshold):
            print("%s : Maximum Space usage on server %s is %s which is under threshold(%s) " % (datetime.datetime.now(),self.hostname,SpaceUsage_DF['max_used'].values[0],self.max_threshold))
        else:
            #DBSizeQueryFile = open(r"sql_queries\dbSizeQuery.sql", "r+")
            DBSizeQueryFile = open(r"/home/ybmonusr/PYTHON_SCRIPTS/sql_queries/dbSizeQuery.sql", "r+")
            sqlQuery = DBSizeQueryFile.read().replace('filter_condition', ' ')
            dbSizeDataFrame = dataFrame.load_data_frame(logger, connection, sqlQuery)
            self.output="/tmp/table_size_" + self.hostname + ".xlsx"
            self.filter_condition = ""
            self.connect_database="znawuserdb"
            GetTablesSize.tablesSize(self)
            email_body = "Hi Team,<br /> <br /> Maximum space usage of data node on server %s is crossed %s threshold. Please take necessary action, if usage reaches 95 then databases will go into read-only mode" % (self.hostname, SpaceUsage_DF['max_used'].values[0])
            email_subject = "Maximum data node Space Usage is crossed %s on %s Server" % (SpaceUsage_DF['max_used'].values[0], self.hostname)
            send_email.send_alert(sender="USZ_ZNA_NZ_DBA@zurichna.com", receivers=self.email,body=email_body, subject=email_subject, ContentTable=dbSizeDataFrame,Attachment=self.output)
            exit(1)


def main():
    getInputParameters = ReadInputParameters()
    inputParameters = getInputParameters.space_usage_monitoring_parameters()
    #print(inputParameters)
    dbsize = space_usage_monitoring(inputParameters)
    dbsize.get_avg_space_usage()
    dbsize.get_max_space_usage()


if __name__ == "__main__":
    main()
