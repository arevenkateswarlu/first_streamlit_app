from send_email import send_email_alert as send_email

email_body = "Hi Team,<br /> <br />Please find the attached non-production regions space usage."
email_subject = "Non-production regions space usage details"
EMAIL="v.are-c@zurichna.com;a.nallamothu-c@zurichna.com"
send_email.send_alert(sender="USZ_ZNA_NZ_DBA@zurichna.com",receivers=EMAIL,body=email_body,subject=email_subject,Attachment='/home/ybmonusr/PYTHON_SCRIPTS/yb_db_region_size.xlsx')
##send_email.send_alert(sender="USZ_ZNA_NZ_DBA@zurichna.com",receivers="v.are-c@zurichna.comx,p.potnuru-c@zurichna.com,jaffer.alishaik-c@zurichna.com,a.nallamothu-c@zurichna.com",body=email_body,subject=email_subject,Attachment='/home/ybmonusr/PYTHON_SCRIPTS/yb_db_region_size.xlsx')

