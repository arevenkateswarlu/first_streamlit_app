from DataFrameToFile import DataFrameToFile
from send_email import send_email_alert as send_email
from LogGenerate import LogGenerate
from GetConnection import GetConnection
from SqlToDataFrame import SqlToDataFrame
from get_db_size import Get_DB_Size
from ReadInputParameters import ReadInputParameters
from tabulate import tabulate


class userdb_monitoring:
    def __init__(self,input_parameters):
        self.hostname = input_parameters.host
        self.port = input_parameters.port
        self.username = input_parameters.user
        self.password = input_parameters.password
        self.connect_database = "znawuserdb"
        if input_parameters.size is not None:
            self.monitor_size = int(input_parameters.size)
        else:
            self.monitor_size = 2


    def get_userdb_size(self):
        logging = LogGenerate()
        logger = logging.logger(__name__)
        logger.debug('Enetered into get_userdb_size')
        connect = GetConnection()
        connection = connect.get_connection(logger,self.hostname, self.port, self.username, self.password, self.connect_database)
        dbsize_query = "select round(d.compressed_bytes/pow(1024,4),2) as size_tb from sys.database d  where d.name='znawuserdb' "
        dataFrame = SqlToDataFrame()
        userdb_size_df = dataFrame.load_data_frame(logger,connection,dbsize_query)
        userdb_size = userdb_size_df.values[0][0]
        if userdb_size < self.monitor_size:
            print("znawuserdb database size is consuming less than %d TB ,so exiting the script" %(userdb_size))
            exit(1)
        else:
            userdb_tab_size_query = open(r"/home/ybmonusr/PYTHON_SCRIPTS/sql_queries/UserdbTabSize.sql", "r+")
            #userdb_tab_size_query = open(r"sql_queries\UserdbTabSize.sql", "r+")
            #print(userdb_tab_size_query)
            UserdbTabSizeDF = dataFrame.load_data_frame(logger,connection,userdb_tab_size_query.read())
            global userdb_size_TB
            userdb_size_TB = userdb_size
            #print(tabulate(UserdbTabSizeDF, headers = 'keys', tablefmt = 'psql' , showindex= False))
            dataFramToFile = DataFrameToFile()
            dataFramToFile.write_to_file(logger,UserdbTabSizeDF, "/tmp/userdb_tab_size.xlsx")
        connection.close()
        return UserdbTabSizeDF


def main():
    """
        Enters here when we call this class"""
    getInputParameters = ReadInputParameters()
    inputParameters = getInputParameters.userdb_monitoring_parameters()
    #print(inputParameters)
    userdb_size_monitoring = userdb_monitoring(inputParameters)
    UserdbTabSizeDF = userdb_size_monitoring.get_userdb_size()
    email_body = "Hi Team,<br /> <br />ZNAWUSERDB on server %s is consuming more than %s TB." % (inputParameters.host, userdb_size_TB)
    email_subject = "ZNAWUSERDB on server %s is consuming more than %s TB." % (inputParameters.host, userdb_size_TB)
    receiver = ["v.are-c@zurichna.com"]
    send_email.send_alert(sender="USZ_ZNA_NZ_DBA@zurichna.com",receivers=receiver,body=email_body,subject=email_subject,Attachment="/tmp/userdb_tab_size.xlsx")


if __name__ == "__main__":
    main()
