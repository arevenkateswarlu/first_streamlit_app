from LogGenerate import LogGenerate
from GetConnection import GetConnection
from SqlToDataFrame import SqlToDataFrame
from ReadInputParameters import ReadInputParameters
import os
import psycopg2.extras as extras
from send_email import send_email_alert as send_email
import pandas as pd


class daily_table_ddl_changes:
    def __init__(self, input_parameters):
        self.hostname = input_parameters.host
        self.port = input_parameters.port
        self.username = input_parameters.user
        self.password = input_parameters.password
        self.meta_db = input_parameters.meta_db
        self.meta_table = input_parameters.meta_table
        self.execution_path = os.getcwd()
        self.prod_server = "10.154.24.10"
        self.dev_server = "10.154.24.5"
        self.qa_server = "10.154.24.6"

    def load_column_details(self):
        logging = LogGenerate()
        logger = logging.logger(__name__)
        logger.debug('Enetered into load_column_details Method')
        try:
#            self.meta_db = "znaw_term"
#            self.meta_table = "column_details"
            connect = GetConnection()
            self.meta_connection = connect.get_connection(logger, self.hostname, self.port, self.username, self.password,self.meta_db)
            self.prod_connetion = connect.get_connection(logger, self.prod_server, self.port, self.username, self.password,"sysviews")
            self.qa_connection = connect.get_connection(logger, self.qa_server, self.port, self.username, self.password,"sysviews")
            self.dev_connetion = connect.get_connection(logger, self.dev_server, self.port, self.username, self.password,"sysviews")
            meta_cursor = self.meta_connection.cursor()
            dataFrame = SqlToDataFrame()
            # columnDetailsQuery = "set search_path to public; select db_name,rel_id,rel_kind,rel_schema,rel_name,col_id,col_name,col_type,nullable,encrypted,default_value,current_date as extracted_dt,'QA' as region from sysviews.public.column_p() where rel_schema='dbaall'"
            # qaColumnDetailsDF = dataFrame.load_data_frame(logger, self.qa_connection,columnDetailsQuery)
            # records = [tuple(x) for x in qaColumnDetailsDF.to_numpy()]
            # columnNames = ','.join(list(qaColumnDetailsDF.columns))
            # insertQuery = "INSERT INTO %s(%s) VALUES %%s" % (self.meta_table, columnNames)
            # extras.execute_values(meta_cursor, insertQuery, records)
            # self.meta_connection.commit()
            # columnDetailsQuery = "set search_path to public; select db_name,rel_id,rel_kind,rel_schema,rel_name,col_id,col_name,col_type,nullable,encrypted,default_value,current_date as extracted_dt,'DEV' as region from sysviews.public.column_p() where rel_schema='dbaall'"
            # qaColumnDetailsDF = dataFrame.load_data_frame(logger, self.dev_connetion, columnDetailsQuery)
            # records = [tuple(x) for x in qaColumnDetailsDF.to_numpy()]
            # columnNames = ','.join(list(qaColumnDetailsDF.columns))
            # insertQuery = "INSERT INTO %s(%s) VALUES %%s" % (self.meta_table, columnNames)
            # extras.execute_values(meta_cursor, insertQuery, records)
            # self.meta_connection.commit()
            columnDetailsQuery = "set search_path to public; select db_name,rel_id,rel_type as rel_kind,schema_name as rel_schema,rel_name,col_id,col_name,col_type,nullable,encrypted,default_value,current_date as extracted_dt,'PROD' as region from sysviews.public.column_p() where schema_name='dbaall'"
            qaColumnDetailsDF = dataFrame.load_data_frame(logger, self.prod_connetion, columnDetailsQuery)
            records = [tuple(x) for x in qaColumnDetailsDF.to_numpy()]
            columnNames = ','.join(list(qaColumnDetailsDF.columns))
            insertQuery = "INSERT INTO %s(%s) VALUES %%s" % (self.meta_table, columnNames)
            extras.execute_values(meta_cursor, insertQuery, records)
            self.meta_connection.commit()

        except Exception:
            self.meta_connection.close()
            self.prod_connetion.close()
            self.qa_connection.close()
            self.dev_connetion.close()
            logger.exception("Got exception in load_column_details of daily_table_ddl_changes class")
            print("Caught exception while load_column_details of daily_table_ddl_changes class")
            print(Exception.with_traceback())
            exit(1)


    def load_distr_details(self):
        logging = LogGenerate()
        logger = logging.logger(__name__)
        logger.debug('Enetered into load_distr_details Method')
        try:
            meta_table = "tab_distr_details"
            connect = GetConnection()
            self.meta_connection = connect.get_connection(logger, self.hostname, self.port, self.username, self.password,self.meta_db)
            self.prod_connetion = connect.get_connection(logger, self.prod_server, self.port, self.username, self.password,self.meta_db)
            self.qa_connection = connect.get_connection(logger, self.qa_server, self.port, self.username, self.password,self.meta_db)
            self.dev_connetion = connect.get_connection(logger, self.dev_server, self.port, self.username, self.password,self.meta_db)
            meta_cursor = self.meta_connection.cursor()
            dataFrame = SqlToDataFrame()
            # distrDetailsQuery = "with table_details as (select d.name as table_catalog,s.name as table_schema,t.name as table_name,u.name as owner,t.distribution,t.sort_key,t.distribution_key,t.cluster_keys,t.partition_keys,current_date as extracted_dt,'QA' as region from sys.table t,sys.schema s,sys.database d,sys.user u where t.schema_id=s.schema_id and t.database_id=d.database_id and t.owner_id=u.user_id and s.name='dbaall' and u.name='dbaall' ) select * from table_details"
            # qaDistrDetailsDF = dataFrame.load_data_frame(logger, self.qa_connection,distrDetailsQuery)
            # records = [tuple(x) for x in qaDistrDetailsDF.to_numpy()]
            # columnNames = ','.join(list(qaDistrDetailsDF.columns))
            # insertQuery = "INSERT INTO %s(%s) VALUES %%s" % (meta_table, columnNames)
            # extras.execute_values(meta_cursor, insertQuery, records)
            # self.meta_connection.commit()
            # distrDetailsQuery = "with table_details as (select d.name as table_catalog,s.name as table_schema,t.name as table_name,u.name as owner,t.distribution,t.sort_key,t.distribution_key,t.cluster_keys,t.partition_keys,current_date as extracted_dt,'DEV' as region from sys.table t,sys.schema s,sys.database d,sys.user u where t.schema_id=s.schema_id and t.database_id=d.database_id and t.owner_id=u.user_id and s.name='dbaall' and u.name='dbaall' ) select * from table_details"
            # devDistrDetailsDF = dataFrame.load_data_frame(logger, self.dev_connetion, distrDetailsQuery)
            # records = [tuple(x) for x in devDistrDetailsDF.to_numpy()]
            # columnNames = ','.join(list(devDistrDetailsDF.columns))
            # insertQuery = "INSERT INTO %s(%s) VALUES %%s" % (meta_table, columnNames)
            # extras.execute_values(meta_cursor, insertQuery, records)
            # self.meta_connection.commit()
            distrDetailsQuery = "with table_details as (select d.name as table_catalog,s.name as table_schema,t.name as table_name,u.name as owner,t.distribution,t.sort_key,t.distribution_key,t.cluster_keys,t.partition_keys,current_date as extracted_dt,'PROD' as region from sys.table t,sys.schema s,sys.database d,sys.user u where t.schema_id=s.schema_id and t.database_id=d.database_id and t.owner_id=u.user_id and s.name='dbaall' and u.name='dbaall' ) select * from table_details"
            prodDistrDetailsDF = dataFrame.load_data_frame(logger, self.prod_connetion, distrDetailsQuery)
            records = [tuple(x) for x in prodDistrDetailsDF.to_numpy()]
            columnNames = ','.join(list(prodDistrDetailsDF.columns))
            insertQuery = "INSERT INTO %s(%s) VALUES %%s" % (meta_table, columnNames)
            extras.execute_values(meta_cursor, insertQuery, records)
            self.meta_connection.commit()

        except Exception:
            self.meta_connection.close()
            self.prod_connetion.close()
            self.qa_connection.close()
            self.dev_connetion.close()
            logger.exception("Got exception in load_column_details of daily_table_ddl_changes class")
            print("Caught exception while load_column_details of daily_table_ddl_changes class")
            print(Exception.with_traceback())
            exit(1)


    def daily_ddl_diff(self):
        logging = LogGenerate()
        logger = logging.logger(__name__)
        logger.debug('Enetered into daily_ddl_diff Method')
        try:
            connect = GetConnection()
            self.meta_connection = connect.get_connection(logger, self.hostname, self.port, self.username, self.password,self.meta_db)
            tableDDLChangesQuery = open(r"/home/ybmonusr/PYTHON_SCRIPTS/sql_queries/TableDDLChangesQuery.sql", "r+")
            sqlQuery = tableDDLChangesQuery.read()
            dataFrame = SqlToDataFrame()
            tableDDLChangesDF = dataFrame.load_data_frame(logger, self.meta_connection, sqlQuery)
            tableDistrChangesQuery = open(r"/home/ybmonusr/PYTHON_SCRIPTS/sql_queries/TableDistrChangesQuery.sql", "r+")
            sqlQuery = tableDistrChangesQuery.read()
            dataFrame = SqlToDataFrame()
            tableDistrChangesDF = dataFrame.load_data_frame(logger, self.meta_connection, sqlQuery)
            with pd.ExcelWriter("/home/ybmonusr/PYTHON_SCRIPTS/Prod_table_ddl_changes.xlsx") as writer:
                tableDDLChangesDF.to_excel(writer, index=False, sheet_name='TableColumnChanges')
                tableDistrChangesDF.to_excel(writer, index=False, sheet_name='TableDistrChanges')
            self.meta_connection.commit()
            email_body = "Hi Team,<br /> <br />Please find the production database table DDL Changes from last successful run."
            email_subject = "Production database table DDL changes details"
            email_list = ["v.are-c@zurichna.com","USZ_ZNA_NZ_DBA@zurichna.com","renae.reimel@zurichna.com"]
            # email_list = ["v.are-c@zurichna.com", "jaffer.alishaik-c@zurichna.com", "p.potnuru-c@zurichna.com","a.nallamothu-c@zurichna.com"]
            send_email.send_alert(sender="USZ_ZNA_NZ_DBA@zurichna.com", receivers=email_list, body=email_body,subject=email_subject,Attachment='/home/ybmonusr/PYTHON_SCRIPTS/Prod_table_ddl_changes.xlsx')

        except Exception:
            self.meta_connection.close()
            logger.exception("Got exception in load_column_details of daily_table_ddl_changes class")
            print("Caught exception while load_column_details of daily_table_ddl_changes class")
            print(Exception.with_traceback())
            exit(1)


def main():
    # print("Header or default or direct run of the script TablesSize")
    getInputParameters = ReadInputParameters()
    inputParameters = getInputParameters.get_DailyDDLChanges_parameters()
    classObj = daily_table_ddl_changes(inputParameters)
    classObj.load_column_details()
    classObj.load_distr_details()
    classObj.daily_ddl_diff()


if __name__ == "__main__":
    main()
