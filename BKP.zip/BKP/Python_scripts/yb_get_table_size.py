#!/home/ybloadusr/PYTHON_VENV/scripts/python
from LogGenerate import LogGenerate
from GetConnection import GetConnection
from DataFrameToFile import DataFrameToFile
from SqlToDataFrame import SqlToDataFrame
from ReadInputParameters import ReadInputParameters
from tabulate import tabulate
import os


class GetTablesSize:
    def __init__(self,input_parameters):
        self.hostname = input_parameters.host
        self.port = input_parameters.port
        self.username = input_parameters.user
        self.password = input_parameters.password
        if input_parameters.dbname is None:
            self.connect_database = "znawuserdb"
        else:
            self.connect_database = input_parameters.dbname
            self.database = input_parameters.dbname
        if input_parameters.table_name is not None:
            if input_parameters.dbname is None:
                print("provide the database name along with tablename ", input_parameters.table_name)
                exit(3)
            else:
                self.tablename = input_parameters.table_name
        if input_parameters.dbname is not None:
            self.filter_condition = " and d.name = '" + self.database + "'"
            if input_parameters.table_name is not None:
                self.filter_condition = self.filter_condition + " and t.name = '" + self.tablename + "'"
        else:
            self.filter_condition = ""
        if input_parameters.output is not None:
            if os.path.isabs(input_parameters.output) and os.path.exists(input_parameters.output):
                file_name = "tables_size_" + self.hostname + ".xlsx"
                #print(file_name)
                self.output = os.path.join(input_parameters.output, file_name)
                #print(self.output)
            else:
                print("Provided path "+ input_parameters.output +" is not existed" )
                exit(4)
        else:
            self.output = "CONSOLE"


    def tablesSize(self):
        logging = LogGenerate()
        logger = logging.logger(__name__)
        logger.debug(('Enetered into tablesSize Method'))
        tableSizeQueryFile = open(r"/home/ybloadusr/PYTHON_VENV/python_scripts/sql_queries/TableSizeQuery.sql","r+")
        sqlQuery = tableSizeQueryFile.read().replace('filter_condition',self.filter_condition)
        connect = GetConnection()
        connection = connect.get_connection(logger,self.hostname, self.port, self.username, self.password, self.connect_database)
        dataFrame = SqlToDataFrame()
        tableSizeDataFrame = dataFrame.load_data_frame(logger,connection,sqlQuery)
        if self.output is "CONSOLE":
            print(tabulate(tableSizeDataFrame, headers = 'keys', tablefmt = 'psql' , showindex= False))
        else:
            dataFramToFile = DataFrameToFile()
            dataFramToFile.write_to_file(logger,tableSizeDataFrame, self.output)
        #tableSizeDataFrame.drop()
        connection.close()


def main():
    """log
    GetTableesSize.logger()"""
    #print("Header or default or direct run of the script TablesSize")
    getInputParameters = ReadInputParameters()
    inputParameters = getInputParameters.get_tables_size_parameters()
    #print(inputParameters)
    tables_size = GetTablesSize(inputParameters)
    tables_size.tablesSize()


if __name__ == "__main__":
    main()
