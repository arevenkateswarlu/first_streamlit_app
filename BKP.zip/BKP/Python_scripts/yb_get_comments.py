#!/home/ybloadusr/PYTHON_VENV/scripts/python
from DataFrameToFile import DataFrameToFile
from send_email import send_email_alert as send_email
from LogGenerate import LogGenerate
from GetConnection import GetConnection
from SqlToDataFrame import SqlToDataFrame
from yb_get_db_size import Get_DB_Size
from ReadInputParameters import ReadInputParameters
from tabulate import tabulate
import pandas


class get_comments:
    def __init__(self, input_parameters):
        self.hostname = input_parameters.host
        self.port = input_parameters.port
        self.username = input_parameters.user
        self.password = input_parameters.password
        if input_parameters.dbname is None:
            print("Please provide the database name")
            exit(1)
        else:
            self.connect_database = input_parameters.dbname
            self.database = input_parameters.dbname
        if input_parameters.table_name is not None:
            if input_parameters.dbname is None:
                print("provide the database name along with tablename ", input_parameters.table_name)
                exit(3)
            else:
                self.tablename = input_parameters.table_name
        if input_parameters.dbname is not None:
            self.filter_condition = " and db.name = '" + self.database + "'"
            if input_parameters.table_name is not None:
                self.filter_condition = self.filter_condition + " and tbl.name = '" + self.tablename + "'"
        else:
            self.filter_condition = ""


    def RetrieveComments(self):
        logging = LogGenerate()
        logger = logging.logger(__name__)
        logger.debug(('Enetered into Table COmments Method'))
#        tableCommentQueryFile = open(r"sql_queries\TableComments.sql", "r+")
        tableCommentQueryFile = open(r"/home/ybloadusr/PYTHON_VENV/python_scripts/sql_queries/TableComments.sql","r+")
        sqlQuery = tableCommentQueryFile.read().replace('filter_condition', self.filter_condition)
        connect = GetConnection()
        connection = connect.get_connection(logger, self.hostname, self.port, self.username, self.password,
                                                self.connect_database)
        dataFrame = SqlToDataFrame()
        CommentsList = list()
        TableCommentsDataFrame = dataFrame.load_data_frame(logger, connection, sqlQuery)
        for table_name,comment in TableCommentsDataFrame.itertuples(index=False):
            format_comment=str(comment).replace("'", "''")
            #print("comment on table " + table_name + " is '  " + format_comment + " ' ;")
            TableComment = "comment on table " + table_name + " is '" + comment.replace("'", "''") + "' ;"
            CommentsList.append(TableComment)
            #print(TableComment)
        #ColumnCommentQueryFile = open(r"sql_queries\ColumnComments.sql", "r+")
        ColumnCommentQueryFile = open(r"/home/ybloadusr/PYTHON_VENV/python_scripts/sql_queries/ColumnComments.sql","r+")
        sqlQuery = ColumnCommentQueryFile.read().replace('filter_condition', self.filter_condition)
        ColumnCommentsDataFrame = dataFrame.load_data_frame(logger, connection, sqlQuery)
        for table_name,column_name,comment in ColumnCommentsDataFrame.itertuples(index=False):
            format_comment=str(comment).replace("'", "''")
            #print("comment on column " + table_name + "." + column_name + " is '  " + format_comment + " ' ;")
            column_comment = "comment on column " + table_name + "." + str(column_name) + " is '" + comment.replace("'", "''") + "' ;"
            CommentsList.append(column_comment)
            #print(column_comment)
        if __name__ == "__main__":
            for i in range(0,len(CommentsList)):
                print(CommentsList[i])
        #print(TableCommentsDataFrame)
        else:
            return CommentsList
        connection.close()


def main():
    #print("Header or default or direct run of the script TablesSize")
    getInputParameters = ReadInputParameters()
    inputParameters = getInputParameters.get_comments_parameters()
    object_comments = get_comments(inputParameters)
    object_comments.RetrieveComments()


if __name__ == "__main__":
    main()
