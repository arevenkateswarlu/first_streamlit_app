#!/home/ybloadusr/PYTHON_VENV/scripts/python
from LogGenerate import LogGenerate
from GetConnection import GetConnection
from SqlToDataFrame import SqlToDataFrame
from ReadInputParameters import ReadInputParameters
from yb_get_comments import get_comments
import os


class yb_generate_insert_stmt:
    def __init__(self, input_parameters):
        self.hostname = input_parameters.host
        self.port = input_parameters.port
        self.username = input_parameters.user
        self.password = input_parameters.password
        if input_parameters.src_db is None:
            print("Please provide the Source database name")
            exit(1)
        else:
            self.src_db = input_parameters.src_db
        if input_parameters.src_table is None:
            print("provide the Source Table name from which data to be copied")
            exit(2)
        else:
            self.src_table = input_parameters.src_table
        if input_parameters.tgt_db is None:
            print("Please provide the Target database name")
            exit(3)
        else:
            self.tgt_db = input_parameters.tgt_db
        if input_parameters.tgt_table is None:
            print("Provide us the Target table to which data need to be copied")
            exit(4)
        else:
            self.tgt_table = input_parameters.tgt_table
        if input_parameters.out_path is not None:
            self.out_path = input_parameters.out_path
            if not os.path.isdir(self.out_path):
                print("Provided path " + self.out_path + " is not a directory or not exists")
                exit(6)
        else:
            self.out_path = os.getcwd()
        self.InsertSqlFile = os.path.join(self.out_path, "Insert_" + self.tgt_db + "." + self.tgt_table + ".sql")


    def CheckTableStatus(self,dbname,tableName):
        logging = LogGenerate()
        logger = logging.logger(__name__)
        logger.debug('Enetered into CheckTableStatus Method')
        try:
            ##tableSizeQueryFile = open(r"sql_queries\CheckTableStatus.sql", "r+")
            tableSizeQueryFile = open(r"/home/ybloadusr/PYTHON_VENV/python_scripts/sql_queries/CheckTableStatus.sql", "r+")
            TableFilter = " and table_catalog = '" + dbname + "' and table_name = '" + tableName + "'"
            sqlQuery = tableSizeQueryFile.read().replace('filter_condition', TableFilter)
            connect = GetConnection()
            connection = connect.get_connection(logger, self.hostname, self.port, self.username, self.password,dbname)
            dataFrame = SqlToDataFrame()
            tableSizeDataFrame = dataFrame.load_data_frame(logger, connection, sqlQuery)
            if len(tableSizeDataFrame.index) == 1:
                return True
            else:
                return False
        except Exception:
            logger.exception("Got exception in CheckTableStatus of yb_generate_insert_stmt class")
            print("Caught exception while checking the table exists,so exiting the process")
            print(Exception.with_traceback())
            exit(1)


    def generate_insert_stmt(self):
        logging = LogGenerate()
        logger = logging.logger(__name__)
        logger.debug('Enetered into generate_insert_stmt Method')
        try:
            if not (self.CheckTableStatus(self.src_db,self.src_table)):
                print("Either Source database " + self.src_db + " Or Source table " + self.src_table + " is not existed, so exiting the script")
                exit(7)
            if not self.CheckTableStatus(self.tgt_db,self.tgt_table):
                print("Either Target database " + self.tgt_db + " Or Target table " + self.tgt_table + " is not existed, so exiting the script")
                exit(8)
            TgtFilterCondition = " and table_catalog = '" + self.tgt_db + "' and table_name = '" + self.tgt_table + "'"
            SrcFilterCondition = " and table_catalog = '" + self.src_db + "' and table_name = '" + self.src_table + "'"
            ##TableColumnQueryFile = open(r"sql_queries\ColumnsDetails.sql", "r+")
            TableColumnQueryFile = open(r"/home/ybloadusr/PYTHON_VENV/python_scripts/sql_queries/ColumnsDetails.sql", "r+")
            sqlQuery = TableColumnQueryFile.read().replace('filter_condition', SrcFilterCondition)
            connect = GetConnection()
            connection = connect.get_connection(logger, self.hostname, self.port, self.username, self.password,self.src_db)
            dataFrame = SqlToDataFrame()
            ##TableColumnQueryFile = open(r"sql_queries\ColumnsDetails.sql", "r+")
            TableColumnQueryFile = open(r"/home/ybloadusr/PYTHON_VENV/python_scripts/sql_queries/ColumnsDetails.sql", "r+")
            SrcTableColumnsDataFrame = dataFrame.load_data_frame(logger, connection, sqlQuery)
            sqlQuery = TableColumnQueryFile.read().replace('filter_condition', TgtFilterCondition)
            connect = GetConnection()
            connection = connect.get_connection(logger, self.hostname, self.port, self.username, self.password,self.tgt_db)
            dataFrame = SqlToDataFrame()
            TgtTableColumnsDataFrame = dataFrame.load_data_frame(logger, connection, sqlQuery)
            EarlierColumns = TgtTableColumnsDataFrame[TgtTableColumnsDataFrame["column_name"].isin(SrcTableColumnsDataFrame["column_name"])]
            NewColumns = TgtTableColumnsDataFrame[~TgtTableColumnsDataFrame["column_name"].isin(SrcTableColumnsDataFrame["column_name"])]
            #print(NewColumns)
            #print(NewColumns.query('column_default.isnull()'))
            if len(NewColumns.query('is_nullable=="NO" & column_default.isnull() '))!=0:
                print("Warning: Below columns are defined as Not Null without providing Default Values")
                print(NewColumns.query('is_nullable=="NO" & column_default.isnull()  '))
            InsertSqlFile = open(self.InsertSqlFile, "w")
            InsertSqlFile.writelines("insert into " + self.tgt_db + ".dbaall." + self.tgt_table + " ( \n")
            ExistingColumnCount = 1
            for ExistingColumn in EarlierColumns["column_name"]:
                if ExistingColumnCount == 1:
                    InsertSqlFile.writelines(ExistingColumn + "\n")
                else:
                    InsertSqlFile.writelines(","+ ExistingColumn + "\n")
                ExistingColumnCount = ExistingColumnCount + 1
            if len(NewColumns.query('is_nullable=="NO" & column_default.isnull() ')) != 0:
                for NewColumn in NewColumns.query('is_nullable=="NO" & column_default.isnull() ')["column_name"]:
                    InsertSqlFile.writelines("," + NewColumn + "\n")
            InsertSqlFile.writelines(" ) \n")
            InsertSqlFile.writelines("( \n select \n")
            ExistingColumnCount = 1
            for ExistingColumn in EarlierColumns["column_name"]:
                if ExistingColumnCount == 1:
                    InsertSqlFile.writelines(ExistingColumn + "\n")
                else:
                    InsertSqlFile.writelines("," + ExistingColumn + "\n")
                ExistingColumnCount = ExistingColumnCount + 1
            if len(NewColumns.query('is_nullable=="NO" & column_default.isnull() ')) != 0:
                for NewColumn in NewColumns.query('is_nullable=="NO" & column_default.isnull() ')["column_name"]:
                    InsertSqlFile.writelines(",default_none_" + NewColumn + "\n")
            InsertSqlFile.writelines(" from " + self.src_db + ".dbaall." + self.src_table + "\n")
            InsertSqlFile.writelines(" ) ;\n")
            InsertSqlFile.close()
        except Exception:
            logger.exception("Got exception in generate_insert_stmt of yb_generate_insert_stmt class")
            print("Caught exception while generating the Insert statement ,so exiting the process")
            print(Exception.with_traceback())
            exit(1)


def main():
    # print("Header or default or direct run of the script TablesSize")
    getInputParameters = ReadInputParameters()
    inputParameters = getInputParameters.get_generate_insert_parameters()
    TableStructureObj = yb_generate_insert_stmt(inputParameters)
    TableStructureObj.generate_insert_stmt()


if __name__ == "__main__":
    main()
