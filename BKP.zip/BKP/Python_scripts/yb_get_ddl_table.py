#!/home/ybloadusr/PYTHON_VENV/scripts/python
from LogGenerate import LogGenerate
from GetConnection import GetConnection
from SqlToDataFrame import SqlToDataFrame
from ReadInputParameters import ReadInputParameters
from yb_get_comments import get_comments

class yb_get_ddl_table:
    def __init__(self, input_parameters):
        self.hostname = input_parameters.host
        self.port = input_parameters.port
        self.username = input_parameters.user
        self.password = input_parameters.password
        if input_parameters.dbname is None:
            print("Please provide the database name")
            exit(1)
        else:
            self.connect_database = input_parameters.dbname
            self.database = input_parameters.dbname
        if input_parameters.table_name is None:
            print("provide the Table name along with tablename ", input_parameters.table_name)
            exit(3)
        else:
            self.tablename = input_parameters.table_name
        if input_parameters.dbname is not None:
            self.filter_condition = " and db.name = '" + self.database + "'"
            if input_parameters.table_name is not None:
                self.filter_condition = self.filter_condition + " and tbl.name = '" + self.tablename + "'"
        else:
            self.filter_condition = ""


    def RetrieveTableStructure(self):
        logging = LogGenerate()
        logger = logging.logger(__name__)
        logger.debug(('Enetered into Table Structure retrieval Method'))
        connect = GetConnection()
        connection = connect.get_connection(logger, self.hostname, self.port, self.username, self.password,
                                            self.connect_database)
        dataFrame = SqlToDataFrame()
        sqlQuery = "describe " + self.tablename + " only ddl "
        #TableStructureDataFrame = dataFrame.load_data_frame(logger, connection, sqlQuery)
        cursor=connection.cursor()
        cursor.execute(sqlQuery)
        for each_line in cursor.fetchall():
            print(str(each_line[0]))
        cursor.close()
        connection.close()


def main():
    #print("Header or default or direct run of the script TablesSize")
    getInputParameters = ReadInputParameters()
    inputParameters = getInputParameters.get_Table_Structure_parameters()
    TableStructureObj = yb_get_ddl_table(inputParameters)
    TableStructureObj.RetrieveTableStructure()
    object_comments = get_comments(inputParameters)
    CommentsList = object_comments.RetrieveComments()
    for i in range(0, len(CommentsList)):
        print(CommentsList[i])

if __name__ == "__main__":
    main()
